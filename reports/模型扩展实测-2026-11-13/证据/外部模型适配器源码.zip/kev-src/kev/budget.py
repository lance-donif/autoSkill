"""The resources a Modal trial container asks for and the admission bound on a study's cost: one home for
modal_app.run_trial/admit_study and kev.rounds.validate. Pure Python (no torch, no modal)."""
TRIAL_CPU, TRIAL_MEMORY = 4, (65536, 196608)   # cores, (request, limit) MiB
GPU_HOURLY = {"H100": 3.95, "H200": 4.54, "B200": 6.25, "T4": 0.59}   # USD per GPU hour
# Full-weight trials (kev.train --full_ft, kev.full_ft). One GPU keeps the fp32 masters and AdamW moments in host memory:
# 12 bytes per parameter, ~310 GB for a 27B, plus the staging buffers and the loader; the CPU runs the AdamW step. Several
# GPUs (FSDP2) keep that state on the GPUs; host memory holds the copy of it a resume point is written from in the
# background (~307 GB over the ranks) and the gathered checkpoint rank 0 writes (~51 GB; a snapshot being written holds
# the same, one at a time). Disk: the runs volume stages what a container writes on its local disk, up to two resume
# points (the new one is complete before the old one goes), the final checkpoint and every snapshot (kept, never deleted),
# beyond Modal's default 512 GiB quota. A run may plan at most MAX_SNAPSHOTS snapshots (kev.train and
# kev.experiment.validated_trial refuse more): with a 27B, 2 x 307 + (1 + 8) x 51.2 ≈ 1,075 GB inside the 1 TiB
# (1,099.5 GB), even if the volume keeps committed files staged. A full disk would fail a snapshot, withhold its resume
# point and fail the trial (failed.json, not retried), so the cap is a hard limit, not a guideline.
FULL_FT_SINGLE = 24, (368640, 409600)          # 360 / 400 GiB
FULL_FT_SHARDED = 16, (409600, 471040)         # 400 / 460 GiB
FULL_FT_DISK = 1048576                         # MiB of ephemeral disk (1 TiB); Modal bills disk as memory at 20:1
MAX_SNAPSHOTS = 8                              # snapshots one full-weight run may plan (fractions + every-N steps)
RESUME_POINT_GB, CHECKPOINT_GB = 307, 51.2     # a 27B's resume point (fp32 masters + moments) and bf16 checkpoint, the disk math above
# A study's limits. Full-weight trials may run to Modal's 24 h cap per attempt and are continued after a timeout (each
# continuation is a new call that resumes from the trial's last resume point, kev.experiment.continue_trial), so their
# bound counts every attempt and their budget cap covers one 8 x H200 day (a LoRA study keeps the $250 cap).
MAX_TIMEOUT = {False: 28800, True: 86400}   # a 24 h attempt fits the $1,000 cap on one H200 (3 x 24 h x ~$11/h); on
                                             # H200:8 (~$41/h) the cap allows ~8 h attempts, a day with the continuations
MAX_BUDGET = {False: 250, True: 1000}
# Continuations per full-weight trial: at most 1 + FULL_FT_RETRIES calls, each one attempt. They are spawned by
# `kev.rounds watch` (or modal_app.py::resume --trial), not by Modal: calls go out with Modal's retries off, because Modal
# charges a timed-out attempt twice when the container then outlives the 30 s cancellation grace (a timeout and a killed
# task; a full-weight trial always does, its trainer and volume commits run on), and the retry the kill triggers can start
# while another attempt of the same input is running. Round 22's trial got two 8 h attempts of the three its bound
# counted (scripts/modal_retry_probe.py: Retries(2) and killed attempts -> 2 attempts; retries=0 -> exactly 1).
FULL_FT_RETRIES = 2
# The attempt lease: a running full-weight attempt holds <study>/<trial>/attempt.json on the kev-leases volume
# (modal_app.TrialLease), refreshed every LEASE_HEARTBEAT seconds from a thread of its own and marked ended when the
# attempt exits cleanly. A lease that is not ended and whose heartbeat is younger than LEASE_STALE belongs to a container
# that may still be writing the trial: a new attempt refuses to start and continue_full_trial waits. LEASE_STALE = 900 s:
#   30 s  Modal's cancellation grace after a timeout, during which the old container keeps running (and committing)
# + 523 s the longest resume-point commit of the runs volume seen (round 22: 206-523 s); the heartbeat does not wait for it,
#         but a commit the old container started just before its kill is covered even if a heartbeat had waited behind it
# + 60 s  one heartbeat interval (the last heartbeat can be that old when the container dies)
# = 613 s, rounded up to 15 min for clock skew between the containers and the launcher (seconds, NTP) and a few failed
# heartbeat commits in a row: a live attempt is mistaken for a dead one only after 15 heartbeats fail in a row.
# The cost is a continuation that starts up to ~15 min after a killed attempt, against 8 h attempts.
LEASE_HEARTBEAT, LEASE_STALE = 60, 900
CPU_HOURLY, MEMORY_GIB_HOURLY = 0.04730, 0.008   # USD per core hour and per GiB hour (memory billed at the limit here)
# Checkpoint interpolation (scripts/interpolate_checkpoint.py, modal_app.py::interpolate): CPU only. The base backbone stays
# resident in bf16 (51 GB for Qwen3.8-27B, 25.6B parameters; loading it through transformers also stages the 2.5 GB LM
# head); the SFT side streams tensor by tensor, one output shard (<= 5 GB) is held until written, and the fp32 arithmetic
# runs in 16M-element chunks (~200 MB). Peak ~60 GB; the limit leaves room for the loader's transients.
INTERPOLATE_CPU, INTERPOLATE_MEMORY, INTERPOLATE_TIMEOUT = 8, (81920, 131072), 10800   # cores, 80 / 128 GiB, 3 h


def gpu_count(gpu):
    """Modal's "H200:8" -> 8; a bare type is one GPU."""
    return int(gpu.partition(":")[2] or 1)


def trial_resources(gpu, full_ft=False):
    """(cpu cores, (memory request, limit) MiB) for one trial container."""
    if not full_ft: return TRIAL_CPU, TRIAL_MEMORY
    return FULL_FT_SHARDED if gpu_count(gpu) > 1 else FULL_FT_SINGLE


def trial_disk(full_ft=False):
    """ephemeral_disk (MiB) for one trial container; None keeps Modal's default."""
    return FULL_FT_DISK if full_ft else None


def hourly_rate(gpu, full_ft=False):
    """USD per hour of one trial container of `gpu` ("H200", or "H200:8" for 8 in one container): GPU + CPU + memory at
    the resources trial_resources gives it."""
    kind = gpu.partition(":")[0]
    if kind not in GPU_HOURLY or gpu_count(gpu) < 1: raise ValueError(f"invalid GPU {gpu!r}")
    cpu, memory = trial_resources(gpu, full_ft)
    return GPU_HOURLY[kind] * gpu_count(gpu) + cpu * CPU_HOURLY + (memory[1] + (trial_disk(full_ft) or 0) / 20) / 1024 * MEMORY_GIB_HOURLY


def interpolation_bound(timeout=INTERPOLATE_TIMEOUT, jobs=1):
    """The most `jobs` interpolation containers (INTERPOLATE_CPU, INTERPOLATE_MEMORY; no GPU, no retries) can cost at
    `timeout` seconds each."""
    if timeout <= 0 or jobs < 1: raise ValueError("invalid timeout or job count")
    return (INTERPOLATE_CPU * CPU_HOURLY + INTERPOLATE_MEMORY[1] / 1024 * MEMORY_GIB_HOURLY) * timeout / 3600 * jobs


def compute_bound(gpu, timeout, trials, full_ft=False):
    """The most `trials` containers can cost if each runs to `timeout` seconds, counting a full-weight trial's retries."""
    if timeout <= 0 or trials < 1: raise ValueError("invalid GPU, timeout, or trial count")
    return hourly_rate(gpu, full_ft) * timeout / 3600 * trials * (1 + FULL_FT_RETRIES if full_ft else 1)


def trial_attempts(spawn, label):
    """(attempts used, attempts allowed) for one trial of a spawn record (runs/<study>.spawn.json, modal_app.launch_detached).
    A record written with Modal's retries off ("modal_retries": 0) keeps each trial's attempts in `attempts`, one per entry
    ({"nonce", "call", ...}; a pending entry, written before its spawn, and an abandoned one count too, since their call
    may run), and allows compute_bound's count: 1 + FULL_FT_RETRIES for a full-weight trial, 1 otherwise. An older record
    (Modal retried each call, and nothing local says how many attempts ran) is taken to have used them all."""
    allowed = 1 + FULL_FT_RETRIES if spawn.get("full_ft") else 1
    if spawn.get("modal_retries") != 0: return allowed, allowed
    return max(1, len(spawn.get("attempts", {}).get(label) or [])), allowed


def lease_state(lease, now):
    """'none' (no lease), 'ended' (its attempt exited cleanly), 'fresh' (a heartbeat younger than LEASE_STALE: its container
    may still be writing the trial) or 'stale' (no heartbeat for LEASE_STALE: the container is gone)."""
    if not lease: return "none"
    if lease.get("ended"): return "ended"
    return "fresh" if now - lease["heartbeat"] < LEASE_STALE else "stale"
