"""Check report trace identities, stored verdicts, protocol consistency and credential exclusion."""
import hashlib
import json
import os
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def main():
    files=sorted((ROOT/"results").glob("project-*-episodes.jsonl"))
    files+=sorted((ROOT/"results").glob("hybrid-*-episodes.jsonl"))
    protocol=hashlib.sha256((ROOT/"results/project-protocol.json").read_bytes()).hexdigest()
    source=json.loads((ROOT/"results/project-protocol.json").read_text())
    for name,digest in source["scripts"].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
    identities=set();model_rows=0;control_rows=0;success=0;steps=0
    for path in files:
        rows=[json.loads(x) for x in path.read_text().splitlines()]
        for r in rows:
            ident=(r["model"],r["task"],r["language"],r["seed"])
            assert ident not in identities,ident
            identities.add(ident)
            if r["model"]=="oracle":control_rows+=1
            else:model_rows+=1
            if path.name.startswith("project-"):
                assert r["project_protocol_sha256"]==protocol,ident
            if r.get("e2e_ms") is not None and r.get("inference_ms") is not None:
                assert r["e2e_ms"]+0.001>=r["inference_ms"],ident
            else:
                assert r.get("execution_status")=="Blocked" and r.get("trace_incomplete"),ident
            for step in r["steps"]:
                assert step["decision_correct"]==(step["selected_action"] in step["valid_actions"]),ident
                assert step["response"]["answers"]["next_action"]["choice"] in step["criteria"],ident
                steps+=1
            if r["expected_behavior_satisfied"]:
                receipts=r["extra"].get("kernel_assertions",[])
                assert receipts and all(check["passed"] for check in receipts),ident
                success+=1
    assert model_rows==152,model_rows
    assert control_rows==32,control_rows
    mapping=json.loads((ROOT/"results/report-case-mapping.json").read_text())
    assert len(mapping)==model_rows
    assert len({m["case_id"] for m in mapping})==model_rows
    for m in mapping:
        assert (m['model'],m['task'],m['language'],m['seed']) in identities
    cfg_path=Path('/workspace/.autoskills-evaluation-api.json')
    secrets=[]
    if cfg_path.exists():secrets.append(json.loads(cfg_path.read_text())["api_key"])
    if os.environ.get("GH_TOKEN"):secrets.append(os.environ["GH_TOKEN"])
    text_paths=[*ROOT.glob("*.py"),ROOT/"REPRODUCE.md"]
    for folder in ["results","sources","fixtures","deliverables"]:
        text_paths += [p for p in (ROOT/folder).rglob("*") if p.is_file() and p.suffix not in (".zip",".xlsx")]
    for p in text_paths:
        raw=p.read_bytes()
        assert not any(secret.encode() in raw for secret in secrets),f"Credential found in {p}"
    result={"project_protocol_sha256":protocol,"primary_source_hashes_match":True,
            "model_episodes":model_rows,"control_episodes":control_rows,"stored_steps":steps,
            "successful_episodes_have_kernel_assertions":True,"unique_case_mapping":True,
            "credential_scan_passed":True,"scope":"Structural trace/identity verification, not a substitute for original semantic/browser checks"}
    (ROOT/"results/report-readback-verification.json").write_text(json.dumps(result,indent=2))
    print(json.dumps(result))


if __name__=="__main__":
    main()
