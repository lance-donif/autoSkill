# 模型实验复现说明

这是一次外部宿主实验，不是 autoSkill 内核的模型配置功能。

## 固定输入

- 项目：`https://github.com/lance-donif/autoSkill`，提交 `c11671395ec4424d98fe5628f61350105a5c6e3d`。
- 官方页面及模型版本、SHA-256：`fixtures/SOURCE.json`、`results/model-artifacts.json`。
- 比较协议：`results/protocol.json`、`results/project-protocol.json`、`results/hybrid-protocol.json`。
- 依赖与硬件：`results/environment.json`、`results/requirements-tested.txt`。
- `results/project-*-episodes.jsonl` 为主要逐轮结果；`results/hybrid-*-episodes.jsonl` 为回退实验。
- 不带 project 前缀的 OpenDecider 与 oracle 结果为早期独立探索，未混入项目主表。

## 环境准备

本实验用 Python 3.12、Linux、`/usr/bin/chromium`，本地推理 FP32、2 线程。
先在单独虚拟环境配置依赖，PyTorch 使用 CPU wheel；依赖准备和下载不在运行命令内自动进行。
版本可能依赖执行日期及软件源，严格重现需使用记录的相同版本。

将本目录放在 `/workspace/autoskills-evaluation`，项目检出到 `/workspace/autoSkill`。
路径不同可以调整 `project_benchmark.py` 中的 `PROJECT` 与 API 配置路径；调整后协议 hash 会变化，
应将所有配置重新执行到同一新协议，不把不同协议结果混合。

证据包不含模型权重；准备好依赖后运行 `python download_models.py`。
该脚本只下载固定 SHA 的配置、tokenizer 和 safetensors，不执行远程 Python 文件。
确认 `results/model-artifacts.json` 中的权重 SHA 与原记录一致。
Laya SDK 可能为兼容 tokenizer 配置生成本地修正；模型权重本体不能变化。

在结果目录之外创建 `/workspace/.autoskills-evaluation-api.json`，设置只允许本人读取：

```json
{"base_url":"你的 OpenAI 兼容地址","model":"deepseek-v4.1-flash","api_key":"你自己的密钥"}
```

请勿将该配置放入证据包。原始密钥未包含在本交付件中。

## 执行顺序

依次运行，每条结束再运行下一条，避免竞争 CPU 或浏览器资源：

```text
python project_benchmark.py --model oracle
python project_benchmark.py --model laya
python project_benchmark.py --model laya-typed-decisions
python project_benchmark.py --model opendecider-nano
python project_benchmark.py --model deepseek-v4.1-flash
python hybrid_benchmark.py --local laya
python hybrid_benchmark.py --local laya-typed-decisions
python hybrid_benchmark.py --local opendecider-nano
python make_report.py
python verify_results.py
```

oracle 是评测工具控制，不是被测 AI。真实模型适配器不读取 oracle 标签。
每轮的新上下文、浏览器启动和模型加载属于准备阶段；导航到最终验证是记录的端到端阶段。
本地 SDK 使用离线 Hub 模式，浏览器通过路由读取本地快照并阻止外部资源。
远程主模型仍需网络；本实验不代表整个系统完全离线。

主要比较器直接调用 autoSkill 的 `ui.perform`、`PlaywrightDriver` 原语与 `ui.check`，
没有启动完整 DSH 会话、产品工作流或 Selenium WebDriver。
候选动作、参数、精简观测由宿主提供。弹窗和缺失报告使用宿主辅助方法；
iframe 使用 Playwright 的穿透选择器，不能据此宣称 Selenium 等价支持。

混合策略仅在完整观测状态重复时切换到主模型，不访问正确答案或置信阈值。
每个本地模型的混合策略测试 8 个英文任务；其余主表每配置 32 轮。
混合协议继承的 en_seeds/zh_seeds 是主对照来源范围，实际混合子集按新增的 english_seeds/chinese_seeds 字段及逐轮记录核对。
模型重复排列来自同一模板，不能作为独立业务样本推断统计显著性。

## 结果检查

先确认控制结果 32/32，再检查所有主表协议 SHA 相同且每配置有 32 轮；混合每配置 8 轮。
报告区分正向完成、正确缺失处理、失败、回退成功和未执行项。
原 API 的 reasoning 字段未用于评分，结果只保留必要答案、用量、模型标识和请求标识。
报告使用 API 返回的用量，不将其当作已核对的账单。

Excel 使用仓库的 14 列规范，并保存后读回校验。
完整证据的索引与文件 SHA 在 `results/` 及证据包清单中；不存在模型运行就不能填为通过。

## 本轮保留的执行阻塞

Typed Decisions 混合测试在 iframe 场景遇到主模型空正文，旧适配器抛出异常。原日志保留；该轮未保存完整轨迹与计时，记为执行阻塞。
`continue_hybrids.py` 保留这次阻塞和已执行轮次，只执行未完成的其他场景，不重试覆盖失败。
在本轮原始日志目录执行 `python continue_hybrids.py --local laya-typed-decisions` 可续接原中断；
`--local opendecider-nano` 也使用同一异常记录策略。新异常保存可获得的回包摘要并继续，推理参数和候选协议不变。
混合组中有轨迹缺失时，不计算完整耗时或加速比，调用数仅作下限；这不是小模型语义错误的证据。
