"""Download only pinned inference artifacts; no remote Python is executed."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
MODELS = {
    "opendecider-nano": ("manjunathshiva/opendecider-nano", "1e1f0a7322e446c5ae9bbe840df11680f18a752a"),
    "laya": ("convaiinnovations/laya", "85cc74ddae6109077ebe2853a9b3077fb6606a78"),
    "laya-typed-decisions": ("convaiinnovations/laya-typed-decisions", "e929ae5cf69bc34259cd2f95c9e91145b818b1f0"),
}


def download(item):
    label, (repo, revision) = item
    meta = json.loads((ROOT / "sources" / f"{label}-metadata.json").read_text())
    files = [x["rfilename"] for x in meta["siblings"]]
    if label == "opendecider-nano":
        files = [x for x in files if x.endswith((".json", ".safetensors"))]
    else:
        files = [x for x in files if x in ("rl_agent_config.json", "model.safetensors") or x.startswith(("tokenizer/", "encoder/"))]
    records = []
    for name in files:
        target = ROOT / "models" / label / name
        target.parent.mkdir(parents=True, exist_ok=True)
        start = time.perf_counter()
        if not target.exists():
            with urllib.request.urlopen(f"https://huggingface.co/{repo}/resolve/{revision}/{name}", timeout=90) as src, target.with_suffix(target.suffix + ".part").open("wb") as dst:
                while chunk := src.read(8 * 1024 * 1024):
                    dst.write(chunk)
            target.with_suffix(target.suffix + ".part").rename(target)
        digest = hashlib.file_digest(target.open("rb"), "sha256").hexdigest()
        rec = dict(model=label, repo=repo, revision=revision, file=name, bytes=target.stat().st_size, sha256=digest, download_and_hash_s=time.perf_counter() - start)
        records.append(rec)
        print(json.dumps(rec), flush=True)
    return records


if __name__ == "__main__":
    with concurrent.futures.ThreadPoolExecutor(3) as pool:
        records = sum(pool.map(download, MODELS.items()), [])
    (ROOT / "results" / "model-artifacts.json").write_text(json.dumps(records, indent=2))
