"""Fixed main model + local action selector, escalating on a repeated browser state.

The fallback does not consult gold actions, correctness labels or model confidence.
Earlier local errors remain in the episode; successful fallback is reported separately.
"""
import argparse
import hashlib
import json
from pathlib import Path
import resource
import time

import project_benchmark as project

base = project.base


class Hybrid:
    def __init__(self, local_name):
        self.local = base.Decider(local_name)
        self.main = project.MainModel()
        self.name = "hybrid-" + local_name
        self.load_s = self.local.load_s
        self.reset()

    def reset(self):
        self.seen = set()
        self.escalated = False

    def predict(self, state, ordered, valid):
        repeated = state in self.seen
        self.seen.add(state)
        if repeated:
            self.escalated = True
        provider = self.main if self.escalated else self.local
        action, response, ms, cpu_ms, criteria = provider.predict(state, ordered, valid)
        response["decision_provider"] = provider.name
        response["host_fallback_active"] = self.escalated
        if repeated:
            response["fallback_trigger"] = "repeated_observed_browser_state"
        return action, response, ms, cpu_ms, criteria


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--local", required=True, choices=["opendecider-nano", "laya", "laya-typed-decisions"])
    args = ap.parse_args()
    decider = Hybrid(args.local)
    state = 'Goal: Set Text input to autoskills-42, then submit.\nObserved: Text input is empty; Submit is available.'
    for _ in range(3):
        decider.local.predict(state, ["fill_text", "fill_area", "submit", "missing"], [])
    protocol = json.loads((base.ROOT / "results/project-protocol.json").read_text())
    protocol.update(hybrid_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    fallback="Repeated exact observed state => primary model takes remaining decisions; no gold-action/confidence access",
                    english_seeds=[11], chinese_seeds=[])
    raw = json.dumps(protocol, sort_keys=True, indent=2).encode()
    digest = hashlib.sha256(raw).hexdigest()
    (base.ROOT / "results/hybrid-protocol.json").write_bytes(raw)
    results = []
    with base.sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path="/usr/bin/chromium", headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-background-networking"])
        with (base.ROOT / "results" / (decider.name + "-episodes.jsonl")).open("w") as out:
            for task in base.TASKS:
                decider.reset()
                record = base.run_episode(browser, decider, task, "en", 11)
                record["hybrid_protocol_sha256"] = digest
                record["fallback_used"] = decider.escalated
                record["local_calls"] = sum(s["response"]["decision_provider"] == args.local for s in record["steps"])
                record["main_calls"] = sum(s["response"]["decision_provider"] == decider.main.name for s in record["steps"])
                results.append(record)
                out.write(json.dumps(record, ensure_ascii=False) + "\n"); out.flush()
                print(json.dumps({k:v for k,v in record.items() if k not in ("steps","extra")}),flush=True)
        browser.close()
    meta = dict(model=decider.name, protocol_sha256=digest,
                load_and_import_s=decider.load_s,
                peak_host_rss_mib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,
                episodes=len(results),expected_behavior_satisfied=sum(r["expected_behavior_satisfied"] for r in results),
                fallback_episodes=sum(r["fallback_used"] for r in results))
    (base.ROOT / "results" / (decider.name + "-meta.json")).write_text(json.dumps(meta,indent=2))
    print("DONE",json.dumps(meta),flush=True)


if __name__ == "__main__":
    main()
