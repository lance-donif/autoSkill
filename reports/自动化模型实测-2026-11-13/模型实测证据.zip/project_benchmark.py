"""Run the frozen candidate-action experiment through autoSkill's actual replay primitives.

The primary-model connection belongs to this external host experiment, never the kernel.
Dialog decisions are host helpers because the existing IR has no accept/dismiss action.
"""
import argparse
import hashlib
import json
from pathlib import Path
import resource
import sys
import time
import urllib.error
import urllib.request

import benchmark as base

PROJECT = Path("/workspace/autoSkill")
sys.path.insert(0, str(PROJECT / "skills/autoskill/app"))
base.os.environ.update(AUTOSKILL_HEADED="0", AUTOSKILL_CHROMIUM="/usr/bin/chromium",
                      AUTOSKILL_BROWSER="/usr/bin/chromium",
                      AUTOSKILL_WORKSPACE=str(base.ROOT / "project-data"))
from autoskill.replay import ui
from autoskill.replay.playwright_driver import PlaywrightDriver

ORIGINAL_EXECUTE = base.execute
IR_ACTIONS = {
    "fill_text": {"action":"fill","selector":"[name=my-text]","value":base.PAYLOAD},
    "fill_password": {"action":"fill","selector":"[name=my-password]","value":base.PASSWORD},
    "fill_area": {"action":"fill","selector":"[name=my-textarea]","value":base.AREA},
    "select_two": {"action":"select","selector":"[name=my-select]","value":"2"},
    "check_default": {"action":"check","selector":"#my-check-2"},
    "radio_default": {"action":"check","selector":"#my-radio-2"},
    "uncheck_checked": {"action":"uncheck","selector":"#my-check-1"},
    "submit": {"action":"click","selector":"button[type=submit]"},
    "reveal": {"action":"click","selector":"#reveal"},
    "wait": {"action":"wait_visible","selector":"#revealed","timeout_seconds":2.5},
    "fill_revealed": {"action":"fill","selector":"#revealed","value":"ready"},
    "add_box": {"action":"click","selector":"#adder"},
    # Playwright's iframe traversal selector is passed through the existing CSS locator path.
    # This test does not establish portable Selenium IR semantics for this selector.
    "fill_frame": {"action":"fill","selector":"#iframe1 >> internal:control=enter-frame >> #working","value":base.PAYLOAD},
    "fill_main": {"action":"fill","selector":"#working","value":base.PAYLOAD},
    "fill_email": {"action":"fill","selector":"#iframe1 >> internal:control=enter-frame >> #email","value":"test@example.com"},
    "fill_absent": {"action":"fill","selector":"#customer-id, [name=customer-id]","value":base.PAYLOAD},
    "reload": {"action":"reload"},
}


def project_execute(page, action, extra):
    if action not in IR_ACTIONS:
        extra.setdefault("execution_adapters", []).append("host_helper:" + action)
        return ORIGINAL_EXECUTE(page, action, extra)
    # Binding an existing live page avoids a second Playwright runtime while using the
    # project's unmodified locator, primitive, wait and error implementations.
    driver = PlaywrightDriver.__new__(PlaywrightDriver)
    driver.page, driver.context = page, page.context
    driver.config = {"page_load_seconds":5,"timeout_seconds":1.6}
    driver.load_ms = 5000
    if action == "submit":
        extra["pre_submit"] = base.observe(page, None, extra)
    ui.perform(driver, IR_ACTIONS[action], base.ORIGIN, [], 1.6)
    if action == "reveal": extra["reveal_clicked"] = True
    extra.setdefault("execution_adapters", []).append("autoskill.ui.perform:" + action)


base.execute = project_execute
ORIGINAL_VERDICT = base.verdict


def project_verdict(task_id, page, obs, extra):
    terminal, success, reason = ORIGINAL_VERDICT(task_id, page, obs, extra)
    if success:
        driver = PlaywrightDriver.__new__(PlaywrightDriver)
        driver.page, driver.context = page, page.context
        # Preserve a real kernel assertion receipt independently of the model output.
        checks = []
        if obs["page"] == "submitted-form.html":
            checks = [{"assertion":"text","selector":"#message","expected":"Received!"}]
        elif task_id == "03_checkbox_radio":
            checks = [{"assertion":"checked","selector":s,"expected":True} for s in ["#my-check-1","#my-check-2","#my-radio-2"]]
        elif task_id == "04_dynamic":
            checks = [{"assertion":"value","selector":"#revealed","expected":"ready"}]
        elif task_id == "06_iframe":
            checks = [{"assertion":"value","selector":IR_ACTIONS["fill_frame"]["selector"],"expected":base.PAYLOAD}]
        elif task_id == "07_missing":
            checks = [{"assertion":"count","selector":"#customer-id, [name=customer-id]","expected":0}]
        elif task_id == "05_dialogs":
            checks = [{"assertion":"url_contains","expected":"simpleTest.html"}]
        receipts = [ui.check(driver, check, 0) for check in checks]
        extra["kernel_assertions"] = receipts
        success = all(r["passed"] for r in receipts)
    return terminal, success, reason


base.verdict = project_verdict


class MainModel:
    def __init__(self):
        self.name = "deepseek-v4.1-flash"
        self.cfg = json.loads(Path("/workspace/.autoskills-evaluation-api.json").read_text())
        self.load_s = 0

    def predict(self, state, ordered_actions, valid):
        # 'valid' is evaluation-only and deliberately not read by this model adapter.
        criteria={chr(65+i):base.ACTIONS[a] for i,a in enumerate(ordered_actions)}
        body={"model":self.cfg["model"],"messages":[
            {"role":"system","content":base.INSTRUCTIONS + ' Return only a JSON object {"choice":"A"} with a valid option letter.'},
            {"role":"user","content":state+"\nAvailable actions: "+json.dumps(criteria,ensure_ascii=False)}],
            "temperature":0,"max_tokens":1024,"stream":False,
            "response_format":{"type":"json_object"}}
        start=time.perf_counter();cpu0=time.process_time()
        request=urllib.request.Request(self.cfg["base_url"].rstrip("/")+"/v1/chat/completions",
            data=json.dumps(body).encode(),headers={"Authorization":"Bearer "+self.cfg["api_key"],"Content-Type":"application/json"})
        with urllib.request.urlopen(request,timeout=90) as response:
            raw=json.load(response)
        message=raw["choices"][0]["message"]
        content=message.get("content","").strip()
        if content.startswith("```"):
            content="\n".join(content.splitlines()[1:-1])
        choice=json.loads(content)["choice"]
        if choice not in criteria:
            raise ValueError("Primary model returned an invalid candidate key")
        output={"model":raw.get("model"),"answers":{"next_action":{"choice":choice}},
                "usage":raw.get("usage",{}),"finish_reason":raw["choices"][0].get("finish_reason"),
                "request_id":raw.get("id")}
        return ordered_actions[ord(choice)-65],output,(time.perf_counter()-start)*1000,(time.process_time()-cpu0)*1000,criteria


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--model",required=True,choices=["oracle","deepseek-v4.1-flash","opendecider-nano","laya","laya-typed-decisions"])
    args=ap.parse_args()
    protocol_hash=base.freeze()
    import subprocess
    revision=subprocess.check_output(["git","-C",str(PROJECT),"rev-parse","HEAD"],text=True).strip()
    script_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),base.ROOT/"benchmark.py"]}
    protocol={"candidate_protocol_sha256":protocol_hash,"repository":"https://github.com/lance-donif/autoSkill",
              "revision":revision,"scripts":script_hashes,"adapter":"unmodified ui.perform, PlaywrightDriver primitives and ui.check; host dialog/missing helpers",
              "en_seeds":[11,22,33],"zh_seeds":[11],"main_model":"deepseek-v4.1-flash"}
    raw=json.dumps(protocol,sort_keys=True,indent=2).encode()
    digest=hashlib.sha256(raw).hexdigest()
    (base.ROOT/"results/project-protocol.json").write_bytes(raw)
    decider=MainModel() if args.model=="deepseek-v4.1-flash" else base.Decider(args.model)
    meta={"model":args.model,"protocol_sha256":digest,"project_revision":revision,
          "load_and_import_s":decider.load_s,"threads":2,"cpu_only_local_models":True,
          "peak_memory_scope":"host Python process only; excludes browser and remote API service",
          "utc_started":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())}
    if args.model not in ("oracle","deepseek-v4.1-flash"):
        state='Goal: Set Text input to autoskills-42, then submit.\nObserved: Text input is empty; Submit is available.'
        ordered=["fill_text","fill_area","submit","missing"]
        warm=[];samples=[]
        for _ in range(3):
            _,_,ms,_,_=decider.predict(state,ordered,["fill_text"]);warm.append(ms)
        for _ in range(20):
            action,response,ms,cpu_ms,criteria=decider.predict(state,ordered,["fill_text"])
            samples.append(dict(inference_ms=ms,cpu_ms=cpu_ms,action=action))
        meta["microbenchmark"]={"state":state,"criteria":criteria,"warmup_ms":warm,"samples":samples}
    all_results=[]
    with base.sync_playwright() as pw:
        browser=pw.chromium.launch(executable_path="/usr/bin/chromium",headless=True,
            args=["--no-sandbox","--disable-dev-shm-usage","--disable-background-networking"])
        meta["browser_version"]=browser.version
        with (base.ROOT/"results"/("project-"+args.model+"-episodes.jsonl")).open("w") as out:
            for lang,seeds in [("en",[11,22,33]),("zh",[11])]:
                for seed in seeds:
                    for task in base.TASKS:
                        record=base.run_episode(browser,decider,task,lang,seed)
                        record["project_protocol_sha256"]=digest
                        all_results.append(record)
                        out.write(json.dumps(record,ensure_ascii=False)+"\n");out.flush()
                        print(json.dumps({k:v for k,v in record.items() if k not in ("steps","extra")},ensure_ascii=False),flush=True)
        browser.close()
    meta["peak_host_rss_mib"]=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024
    meta["episodes"]=len(all_results)
    meta["expected_behavior_satisfied"]=sum(r["expected_behavior_satisfied"] for r in all_results)
    (base.ROOT/"results"/("project-"+args.model+"-meta.json")).write_text(json.dumps(meta,indent=2))
    print("DONE",args.model,meta["expected_behavior_satisfied"],len(all_results),flush=True)
    if args.model=="oracle" and not all(r["expected_behavior_satisfied"] for r in all_results):
        raise SystemExit("Project adapter fixture validation failed")


if __name__=="__main__":
    main()
