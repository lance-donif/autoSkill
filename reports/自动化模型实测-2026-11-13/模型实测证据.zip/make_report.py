"""Build reviewable Chinese deliverables directly from frozen experiment records."""
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import statistics
import zipfile

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

import benchmark as bench

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "deliverables"
MODELS = ["deepseek-v4.1-flash", "opendecider-nano", "laya-typed-decisions", "laya"]
LOCALS = MODELS[1:]
LABELS = {"deepseek-v4.1-flash":"DeepSeek 主模型", "opendecider-nano":"OpenDecider Nano",
          "laya-typed-decisions":"Laya Typed Decisions", "laya":"Laya 基础版"}
TITLES = ["文本输入与提交", "密码与下拉框", "复选框与单选框", "动态输入框", "弹窗确认与取消", "iframe 内输入", "缺失元素处理", "完整表单"]
PREFIXES = ["WBSRYTJ", "MMYXLK", "FXKYDXK", "DTSRK", "TCQRYQX", "KJNSR", "QSYSC L".replace(" ",""), "WZBD"]
REASONS = {
    "primary_response_unusable":"主模型响应正文不可用，实验适配器中断；保留为执行阻塞",
    "two_actions_without_state_progress":"连续两次动作未改变观测状态，实验停止",
    "premature_or_wrong_submission":"提前提交或提交数据与目标不符",
    "incorrect_missing_report":"将可执行任务错误报告为缺少元素",
    "accepted_before_cancelled":"尚未按要求取消第一次弹窗就确认跳转",
    "budget_exhausted":"达到实验步数预算仍未满足目标",
    "validated_submission":"提交完成，页面回执与目标字段均已核对",
    "validated_checkbox_radio":"要求的复选框和单选框状态已核对",
    "validated_dynamic_input":"动态输入框已显示且值为 ready",
    "validated_both_dialogs":"先取消、再确认跳转的实际结果均已核对",
    "validated_iframe":"iframe 内输入值正确，email 保持为空",
    "correct_missing_report":"实际元素不存在，正确报告缺失且未修改其他字段",
}


def read_jsonl(name):
    path = ROOT / "results" / name
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def percentile(values, p):
    v = sorted(values)
    k = (len(v)-1)*p
    low = int(k)
    return v[low] + (v[min(low+1,len(v)-1)]-v[low])*(k-low)


def metrics(rows):
    positive=[r for r in rows if r["task"]!="07_missing"]
    steps=[s for r in rows for s in r["steps"]]
    success=[r for r in rows if r["expected_behavior_satisfied"]]
    timed=[r for r in rows if r.get("e2e_ms") is not None]
    return dict(n=len(rows),expected=sum(r["expected_behavior_satisfied"] for r in rows),
        blocked=sum(r.get("execution_status")=="Blocked" for r in rows),
        latency_complete=len(timed)==len(rows) and not any(r.get("trace_incomplete") for r in rows),
        positive_n=len(positive),positive_completed=sum(r["expected_behavior_satisfied"] for r in positive),
        missing_correct=sum(r["expected_behavior_satisfied"] for r in rows if r["task"]=="07_missing"),
        missing_n=sum(r["task"]=="07_missing" for r in rows),
        e2e_median_s=statistics.median(r["e2e_ms"] for r in timed)/1000,
        e2e_total_s=sum(r["e2e_ms"] for r in timed)/1000,
        success_median_s=statistics.median(r["e2e_ms"] for r in success)/1000 if success else None,
        decisions=len(steps),decision_correct=sum(s["decision_correct"] for s in steps),
        inference_p50_ms=statistics.median(s["inference_ms"] for s in steps),
        inference_p95_ms=percentile([s["inference_ms"] for s in steps],.95),
        inference_cpu_percent=100*sum(s["inference_cpu_ms"] for s in steps)/sum(s["inference_ms"] for s in steps),
        truncated_calls=sum(bool(s["response"].get("usage",{}).get("truncated")) or bool(s["response"].get("warnings")) for s in steps),
        api_calls=sum(s["response"].get("model","").startswith("deepseek/") for s in steps),
        api_tokens=sum(s["response"].get("usage",{}).get("total_tokens",0) for s in steps),
        reported_api_cost=sum(s["response"].get("usage",{}).get("cost",0) for s in steps))


def case_text(task):
    index=int(task[:2])-1
    goal=bench.TASKS[task]["zh"]
    page=bench.TASKS[task]["page"]
    steps=f"1. 打开 Selenium 官方页面快照 {page}。\n2. 按选定模型执行本条目标：{goal}\n3. 查看最终页面状态和执行记录。"
    expected=[
        "3. 收到 Received!，提交参数 my-text 为 autoskills-42。",
        "3. 收到 Received!，my-password 为 S3cret-42!、my-select 为 2。",
        "3. Default checkbox、Default radio 和 Checked checkbox 均选中。",
        "3. 动态输入框可见，值为 ready。",
        "3. 第一次确认弹窗取消后仍在原页，第二次确认后到达 simpleTest.html。",
        "3. iframe1 内 working 的值为 autoskills-42，email 为空。",
        "3. customer-id 实际不存在；模型报告缺失，其他输入值保持不变。这是正确失败处理，不是填表成功。",
        "3. 收到 Received!，文本、密码、多行文本、下拉值、复选框与单选框均符合目标。",
    ][index]
    return steps,expected


def build_workbook(all_rows, summary):
    wb=Workbook();ws=wb.active;ws.title="功能测试用例"
    headers=["用例标识","用例名称","功能需求追踪","测试说明","前置条件","测试步骤","预期结果","用例编制人","实际结果","测试结论","测试执行人","验证环境","备注","截图"]
    ws.append(headers)
    colors=["FFD966","A9D18E","F4B183","BFBFBF"]
    def group(name,level):
        row=ws.max_row+1;ws.cell(row,1,name);ws.merge_cells(start_row=row,start_column=1,end_row=row,end_column=12)
        for cells in ws.iter_rows(min_row=row,max_row=row,max_col=14):
            for c in cells:c.fill=PatternFill("solid",fgColor=colors[level-1]);c.font=Font(name="宋体",size=11,bold=True)
        ws.row_dimensions[row].height=23
    group("autoSkill",1);group("浏览器操作",2)
    mapping=[]
    for i,task in enumerate(bench.TASKS):
        group(TITLES[i],3)
        for ordinal,r in enumerate([r for r in all_rows if r["task"]==task],1):
            case_id=f"FT-{PREFIXES[i]}-{ordinal:03}"
            r["report_case_id"]=case_id
            steps,expected=case_text(task)
            language="英文" if r["language"]=="en" else "中文"
            actual=REASONS.get(r["reason"],r["reason"])
            if r.get("trace_incomplete"):
                actual+="；轨迹不完整，不填造丢失的调用次数或耗时。"
            else:
                actual+=f"；{len(r['steps'])} 次决策，端到端 {r['e2e_ms']/1000:.3f} 秒。"
            if r["model"].startswith("hybrid-"):
                calls=str(r['main_calls']) if r['main_calls'] is not None else "未保存"
                actual+=f" 主模型调用次数：{calls}；回退{'已触发' if r['fallback_used'] else '未触发'}。"
            source=("hybrid-"+r["model"].removeprefix("hybrid-") if r["model"].startswith("hybrid-") else "project-"+r["model"])+"-episodes.jsonl"
            note=f"定义 v1；日期 2026-11-13；语言 {language}；候选种子 {r['seed']}；实验步数预算 {bench.TASKS[task]['budget']}（不是产品限制或 SLA）；证据 results/{source}，按 task/language/seed 定位。"
            if task=="07_missing":note+="本例通过表示正确处理缺失，未完成原填写目标。"
            if task=="05_dialogs":note+="弹窗处理由宿主辅助适配器执行；未验证原生 IR 的取消能力。"
            if task=="06_iframe":note+="采用 Playwright 框架穿透选择器；未验证 Selenium 等价性。"
            ws.append([case_id,"autoSkill-浏览器操作-"+TITLES[i],TITLES[i],
                f"验证 {r['model']} 在{language}指令、候选顺序种子 {r['seed']} 下完成本场景。",
                "每轮新建浏览器上下文，加载冻结的官方页面；动作参数由宿主提供。",
                steps,expected,"【待确认：用例编制人】",actual,
                "通过" if r["expected_behavior_satisfied"] else ("阻塞" if r.get("execution_status")=="Blocked" else "失败"),"自动化脚本（本会话执行）",
                "Linux x86_64；Chromium 156；本地模型 CPU FP32 / 2 线程；主模型远程 API。",note,""])
            row=ws.max_row;ws.row_dimensions[row].height=155
            ws.cell(row,10).fill=PatternFill("solid",fgColor="E2F0D9" if r["expected_behavior_satisfied"] else ("FFF2CC" if r.get("execution_status")=="Blocked" else "FCE4D6"))
            mapping.append({"case_id":case_id,"model":r["model"],"task":task,"language":r["language"],"seed":r["seed"],"evidence_file":source})
    widths=[24,42,24,47,40,76,68,25,70,13,26,42,86,16]
    for col,width in enumerate(widths,1):ws.column_dimensions[get_column_letter(col)].width=width
    for row in ws:
        for cell in row:
            if cell.font.name!="宋体":cell.font=Font(name="宋体",size=11,bold=cell.row==1)
            cell.alignment=Alignment(vertical="top",wrap_text=True)
    for c in ws[1]:c.fill=PatternFill("solid",fgColor="BFBFBF")
    ws.freeze_panes="C2";ws.row_dimensions[1].height=27
    metrics_sheet=wb.create_sheet("指标汇总")
    metrics_sheet.append(["配置","期望行为符合数","总实验轮次","正向任务完成数","正向任务轮次","正确缺失处理数","阻塞数","全量耗时中位数/秒","主模型调用数"])
    for name,s in summary.items():
        metrics_sheet.append([name,s['expected'],s['n'],s['positive_completed'],s['positive_n'],s['missing_correct'],s['blocked'],s['e2e_median_s'] if s['latency_complete'] else "不完整，含阻塞",s['api_calls'] if s['latency_complete'] else "仅为已保存轨迹下限"])
    for row in metrics_sheet:
        for c in row:c.font=Font(name="宋体",size=11);c.alignment=Alignment(wrap_text=True,vertical="top")
    for col in range(1,10):metrics_sheet.column_dimensions[get_column_letter(col)].width=29
    metrics_sheet.freeze_panes="A2"
    path=OUT/"自动化模型测试用例.xlsx";wb.save(path)
    check=load_workbook(path);assert check["功能测试用例"].max_column==14
    assert sum(str(row[0].value).startswith("FT-") for row in check["功能测试用例"] if row[0].value)==len(all_rows)
    check.close()
    (ROOT/"results/report-case-mapping.json").write_text(json.dumps(mapping,ensure_ascii=False,indent=2))


def main():
    OUT.mkdir(exist_ok=True)
    primary={m:read_jsonl("project-"+m+"-episodes.jsonl") for m in MODELS}
    hybrids={m:read_jsonl("hybrid-"+m+"-episodes.jsonl") for m in LOCALS}
    for m,rows in primary.items():assert len(rows)==32,(m,len(rows))
    for m,rows in hybrids.items():assert len(rows)==8,(m,len(rows))
    protocols={r["project_protocol_sha256"] for rows in primary.values() for r in rows}
    assert len(protocols)==1,protocols
    rows=sum(primary.values(),[])+sum(hybrids.values(),[])
    summary={m:metrics(r) for m,r in primary.items()}
    summary.update({"hybrid-"+m:metrics(r) for m,r in hybrids.items()})
    metadata={m:json.loads((ROOT/"results"/("project-"+m+"-meta.json")).read_text()) for m in MODELS}
    (ROOT/"results/summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    build_workbook(rows,summary)
    timestamp=datetime.now(timezone.utc).isoformat()
    main_rows=primary[MODELS[0]]
    paired_main=[r for r in main_rows if r["language"]=="en" and r["seed"]==11]
    paired=metrics(paired_main)
    table=[]
    for m in MODELS:
        en=metrics([r for r in primary[m] if r['language']=='en'])
        zh=metrics([r for r in primary[m] if r['language']=='zh'])
        s=summary[m]
        table.append(f"| {LABELS[m]} | {s['expected']}/{s['n']} | {s['positive_completed']}/{s['positive_n']} | {s['missing_correct']}/{s['missing_n']} | {en['expected']}/24 | {zh['expected']}/8 | {s['e2e_median_s']:.2f} |")
    coverage=[]
    for index,task in enumerate(bench.TASKS):
        cells=[]
        for m in MODELS:
            subset=[r for r in primary[m] if r["task"]==task]
            cells.append(str(sum(r["expected_behavior_satisfied"] for r in subset))+"/"+str(len(subset)))
        coverage.append("| "+TITLES[index]+" | "+" | ".join(cells)+" |")
    resource_table=[]
    for m in LOCALS:
        meta=metadata[m];micro=meta['microbenchmark'];v=[r['inference_ms'] for r in micro['samples']]
        s=summary[m]
        resource_table.append(f"| {LABELS[m]} | {statistics.median(v):.0f} / {percentile(v,.95):.0f} ms | {s['inference_p50_ms']:.0f} / {s['inference_p95_ms']:.0f} ms | {s['inference_cpu_percent']:.0f}% | {meta['peak_host_rss_mib']/1024:.2f} GiB | {meta['load_and_import_s']:.1f} s | {s['truncated_calls']}/{s['decisions']} |")
    hybrid_table=[]
    improvements=[]
    for m in LOCALS:
        s=summary['hybrid-'+m];rs=hybrids[m]
        fallback=sum(r['fallback_used'] for r in rs)
        delta=(s['e2e_total_s']/paired['e2e_total_s']-1)*100
        label="样本内更快" if s['latency_complete'] and s['expected']==paired['expected'] and delta<0 else "未见净收益"
        if s['latency_complete'] and s['expected']==paired['expected'] and delta<0:improvements.append(m)
        elapsed=f"{s['e2e_total_s']:.2f}" if s['latency_complete'] else "计时不完整"
        change=f"{delta:+.1f}%" if s['latency_complete'] else "不可比较"
        calls=str(s['api_calls']) if s['latency_complete'] else "≥"+str(s['api_calls'])
        hybrid_table.append(f"| {LABELS[m]} + 主模型 | {s['expected']}/8 | {s['positive_completed']}/7 | {s['blocked']} | {fallback}/8 | {calls} | {elapsed} | {change} | {label} |")
    intro=("本轮在匹配的 8 个英文场景中观察到部分混合配置节省总耗时，但样本很小，尚不能作为默认启用依据。" if improvements
           else "本轮没有找到可推荐默认启用的净提升配置。")
    report=f"""# autoSkill 自动化决策模型实测报告

测试日期：2026-11-13；报告生成：{timestamp}。项目：`lance-donif/autoSkill`，版本 2.2.4，冻结提交 `c11671395ec4424d98fe5628f61350105a5c6e3d`。

## 结论

{intro} 主模型固定为用户指定的 `deepseek-v4.1-flash`，API 实际返回 `deepseek/deepseek-v4.1-flash-1017`。Laya 基础版、Laya Typed Decisions、OpenDecider Nano 均已下载真实权重并在纯 CPU 上推理；结果来自实际页面操作和最终校验。

autoSkill 已有固定用例回放不调用模型。这里评估的是探索/录制阶段的“给定候选动作后选择下一步”，以及页面状态重复时回到主模型的实验性宿主策略。尚未部署为产品功能。项目历史报告中的 Luna 标识为 `gpt-6-luna`；用户 API 的模型列表中没有 Luna，未找到可复现调用入口，本轮未测，不能给出原四款模型的完整排名。

## 对照结果

| 动作选择配置 | 全部期望行为符合 | 正向任务完成 | 正确处理缺失 | 英文期望行为 | 中文期望行为 | 全量耗时中位数/秒 |
|---|---:|---:|---:|---:|---:|---:|
{chr(10).join(table)}

主对照每配置 32 轮：8 种场景 × 英文 3 个候选排列，另加中文 1 个排列。另有 32 轮早期 OpenDecider 独立探索和两组各 32 轮工具控制，保留在证据包，不混入主对照或 152 轮正式模型/混合结果。32 轮包含 28 个可完成任务和 4 个故意缺失元素的任务。“正确处理缺失”不表示原填写任务已完成。候选排列是同一场景的扰动，不是 32 个独立业务样本，不能外推生产成功率或显著性。

全量耗时包含失败或提前结束的轮次；失败更快不代表加速。上表用于展示实际成本，不能把各模型不同成功集合的中位数直接算成提升倍数。逐场景结果、每次动作、最终状态和失败原因见 Excel 与原始 JSONL。

## 各场景表现

| 场景 | DeepSeek 主模型 | OpenDecider Nano | Laya Typed Decisions | Laya 基础版 |
|---|---:|---:|---:|---:|
{chr(10).join(coverage)}

每格包含同一场景的三个英文排列和一个中文排列。重复已完成动作、未按状态进入下一步、错误缺失处理等原始轨迹保留在问题清单和证据包；不能仅凭首步选对就认为任务完成。

## 固定主模型后的混合验证

本轮混合策略仅在观测到完全相同页面状态再次出现时，将余下决策交给 DeepSeek。它不读取评测正确答案、不使用准确率标签、不设置信心阈值。早先的错误动作仍保留；回退后的成功不计作纯小模型首次成功。若模型直接提前提交或错误报告缺失，实验仍保留失败。

为控制 API 成本，混合配置各执行相同的 8 个英文场景、候选种子 11，并与主模型同一子集比较；这是小规模追加验证，未覆盖三个排列和中文。主模型该子集：期望行为 {paired['expected']}/8，正向任务 {paired['positive_completed']}/7，API 调用 {paired['api_calls']} 次，总耗时 {paired['e2e_total_s']:.2f} 秒。

| 混合配置 | 期望行为符合 | 正向完成 | 阻塞 | 触发回退轮次 | API 调用 | 总耗时/秒 | 相对主模型总耗时 | 观察 |
|---|---:|---:|---:|---:|---:|---:|---:|---|
{chr(10).join(hybrid_table)}

负百分比表示样本内节省时间；只有满足同一子集全部判据时才讨论速度收益。API 延迟随网络、服务负载与缓存变化，顺序运行未随机交错，也没有多天复测；即使出现节省，也只是该子集的观察。

Typed Decisions 混合组的 iframe 轮次出现主模型响应正文为空，原实验适配器触发异常并中断；该轮保留为执行阻塞，不归因于小模型选错。原进程未保存该轮完整回包、逐步轨迹和耗时，因此调用量仅为已保存轨迹的下限，总耗时不可比较。继续器保留前五轮与这次阻塞，仅执行剩余场景；没有重跑把阻塞覆盖为通过。后续异常也会明确记录为阻塞，原主对照脚本及推理参数未改动。详情见问题清单和 continuation 协议。

## CPU、内存和输入截断

| 本地模型 | 相同短输入热推理 p50 / p95 | 页面决策 p50 / p95 | 推理期宿主 CPU | 宿主进程峰值 RSS | 导入与加载 | 截断调用 |
|---|---:|---:|---:|---:|---:|---:|
{chr(10).join(resource_table)}

短输入一致：相同目标、4 个相同候选，先预热 3 次，再测 20 次。页面决策耗时是各模型实际走到的不同轨迹，输入长度和候选数不同；不应视作严格等长推理排行。p95 用线性插值计算，小样本尾延迟只供参考。

机器为 Intel Xeon Platinum 8573C、Linux x86_64；可见 3 个 vCPU，但 cgroup 配额为 2 个 CPU，内存上限 8 GiB。本地模型固定 CPU、FP32、2 个推理线程，无 CUDA。CPU 百分比按 Python 进程 CPU 时间 / 推理墙钟时间计算，100% 为一个 CPU，可超过 100%；不包含浏览器/Node 子进程。RSS 为宿主 Python 进程加载至测试结束的高水位，包含框架和加载临时内存，排除浏览器与远程服务，不能当作纯参数内存。导入加载不含下载，也不属于真正清空操作系统缓存后的冷启动。

模型和页面已预下载，模型 SDK 设置离线 Hub 模式；测试时 Chromium 请求由本地快照响应，外部页面资源被阻止。DeepSeek 依赖网络，不能声称整个系统完全离线。未做操作系统级断网验证。

## 测试边界与可复核性

- 页面是 Selenium 官方仓库固定版本 `a393610d6d42bbbf28c30b6bc4212682a58bbb6c` 的 HTML 快照；执行浏览器为 Chromium 156.0.8078.79，执行器为 **Playwright，而非 Selenium WebDriver**。
- 覆盖文本提交、密码/下拉、复选/单选、动态输入框、先取消后确认弹窗、iframe、缺失元素、完整表单。固定脚本控制在 autoSkill 适配器上 32/32 满足判据，用来核实测试工具，不是模型能力或真实项目基线。
- 调用项目未经修改的 `replay/ui.py::perform`、`PlaywrightDriver` 定位/动作原语及 `ui.check`。iframe 使用 Playwright 框架穿透选择器；弹窗确认/取消和缺失报告由实验宿主辅助方法执行，未证明所有操作都能作为原生 IR 在 Selenium 引擎中回放。
- 宿主提供精简页面状态、候选动作、选择器与填写值。模型只返回一个候选，不负责生成参数、截图定位、完整 DOM 搜索或自由规划。等待的一部分由执行器承担；不能把这些结果称作无辅助自主测试能力。
- 页面最终值、提交参数、回执、框架内容与弹窗实际导航决定结果，高概率或模型自报完成不能代替校验。局部决策正确数只作诊断，各模型轨迹不同，不能直接用于公平单步排行。
- 不是完整 DSH 会话验收：本实验用外部宿主适配器连接用户 API，没有启动生产 DSH 工作流，也没有改动内核模型配置。主模型逐步选择的对照不是现有宿主流程的生产性能基线；未比较主模型一次批量规划并编译 IR 的优化方式。也未测试“主模型先拆解原子操作，小模型只匹配 DOM 元素”的粒度，不能据此否定元素候选重排的潜力。
- 79.6%、76.6%、36.2% 和约 17/21 ms 来自公开 typed-decisions 基准及不同加速硬件，不是本次浏览器指标，不能代替本报告实测。来源快照在证据包 `sources/`。
- 未执行的范围：Luna、Laya 浏览器专项微调、多语 checkpoint、ONNX/INT8、BF16、Windows/UOS、真实生产站点，以及大样本留站点验证；不对其排名。

## 对 autoSkill 的建议

保留 DeepSeek 作为主模型和现有确定性回放。不要把通用决策 checkpoint 直接设为每一步默认执行器；本轮暴露的重复动作、状态理解和失败处理问题会增加回退成本。若继续研究，先收集独立浏览器任务的状态与候选标注，评估浏览器专项或多语权重，再以固定主模型、相同留出任务、首次成功率和回退总成本决定是否启用。该建议不代表专项模型已经验证有效。

## 文件和重现

- 现有项目回归：`test_replay_ui.py` 为 8 项通过（6 项真实浏览器、2 项 IR），6 项 Selenium 测试因缺少匹配驱动跳过；`test_locator_fallbacks.py` 为 5/5 通过。这些是执行代码回归，不计入模型准确率；不是项目全量回归。
- [测试用例 Excel](自动化模型测试用例.xlsx)：152 条实测轮次，保存各模型与混合配置的结果；相同模板的排列扰动明确标注。
- [简短汇总](测试汇总.md)；[问题清单](问题清单.md)。问题按实验模型/执行边界分类，不把候选模型失败直接认定为现有产品 Bug。
- [可复现证据包](模型实测证据.zip)：冻结协议、权重 SHA、版本、实际请求/响应摘要、逐步 DOM/URL 结果、源码和官方页面快照。**不含 API/GitHub 密钥、模型权重和项目用户数据。**
- 每次项目对照协议 SHA-256：`{next(iter(protocols))}`；混合策略另有独立协议。项目源码未改动，报告作为本地交付件保存，未推送远端。

复现时先按证据包说明配置本地依赖与权重，以及通过独立私有配置文件提供自己的主模型 API；不要把密钥写入结果目录。运行 `project_benchmark.py --model oracle` 验证工具，再分别执行四种配置；最后运行 `hybrid_benchmark.py --local <模型>`。浏览器启动、模型加载及上下文创建不计入每轮端到端时间，导航、观察、决策、动作、等待和最终校验计入，预热/固定输入微基准单独记录。

Excel 已进行保存后读回与仓库规范校验；未完成 Excel 原生渲染视觉验收。所有数量均来自本轮冻结记录，未以旧报告或公开跑分补充未执行结果。
"""
    (OUT/"模型实测分析报告.md").write_text(report)
    passed=sum(r['expected_behavior_satisfied'] for r in rows)
    blocked=sum(r.get('execution_status')=='Blocked' for r in rows)
    failed=len(rows)-passed-blocked
    brief=f"""# autoSkill 自动化模型测试汇总

- 项目：lance-donif/autoSkill，2.2.4，c11671395ec4424d98fe5628f61350105a5c6e3d。
- 任务：固定 DeepSeek 主模型，对比 OpenDecider Nano、Laya Typed Decisions、Laya 基础版及自动回退。
- 时间：2026-11-13。
- 环境：Linux x86_64；2 CPU 配额 / 8 GiB；Chromium + Playwright；本地模型 FP32；DeepSeek 远程 API。
- 执行：152 轮正式模型对照/混合实验；期望行为符合 {passed}，失败 {failed}，阻塞 {blocked}。包含故意缺失元素场景，不能把这些轮次全部当成成功填表；控制实验另计。
- 主要问题：重复执行已完成动作、多步状态跟踪或缺失处理错误；详见问题清单。{intro}
- [Excel 用例及实际结果](自动化模型测试用例.xlsx)；[完整分析](模型实测分析报告.md)；[问题清单](问题清单.md)。
"""
    (OUT/"测试汇总.md").write_text(brief)
    bug=["# 自动化模型实验问题清单", "", "范围：本轮候选动作实验；用例定义 v1，项目提交 c11671395ec4424d98fe5628f61350105a5c6e3d。下列模型适配问题不等同于现有 autoSkill 固定回放缺陷。所有首次失败与混合复测分别保留。", ""]
    for m in LOCALS:
        failures=[r for r in primary[m] if not r['expected_behavior_satisfied']]
        bug.extend([f"## {LABELS[m]}：{len(failures)}/{len(primary[m])} 轮未满足目标",""])
        for reason in sorted({r['reason'] for r in failures}):
            same=[r for r in failures if r['reason']==reason];sample=same[0]
            actions=" → ".join(s['selected_action'] for s in sample['steps'])
            task=sample['task'];i=int(task[:2])-1
            bug.extend([f"### {REASONS.get(reason,reason)}（{len(same)} 轮）", "",
                f"- 复现用例：`{sample['report_case_id']}`；{task}；语言 {sample['language']}；种子 {sample['seed']}。",
                f"- 原预期：{case_text(task)[1]}",
                f"- 实际动作：`{actions}`；最终状态：{sample['reason']}。",
                f"- 证据：`results/project-{m}-episodes.jsonl`，按 task/language/seed 查找；保留每次模型响应、实际动作和观察。",
                "- 复现：加载同一模型/页面 SHA，运行 project_benchmark.py 对应配置；无需修改原判据。",""])
        h=hybrids[m]
        bug.append(f"混合策略复测另执行 8 个英文场景：期望行为符合 {sum(r['expected_behavior_satisfied'] for r in h)}/8，回退 {sum(r['fallback_used'] for r in h)}/8；不能据此删除上述原始失败。\n")
    bug.extend(["## 混合策略残余失败与执行阻塞", ""])
    for m in LOCALS:
        for sample in hybrids[m]:
            if sample['expected_behavior_satisfied']:
                continue
            actions=" → ".join(s['selected_action'] for s in sample['steps']) or "完整轨迹未保存"
            bug.extend([f"### {sample['report_case_id']} / hybrid-{m}", "",
                f"- 定义：v1；场景 {sample['task']}；英文；种子 11。",
                f"- 原预期：{case_text(sample['task'])[1]}",
                f"- 实际：{REASONS.get(sample['reason'],sample['reason'])}；动作：`{actions}`。",
                f"- 分类：{'执行阻塞，不能判定为业务失败' if sample.get('execution_status')=='Blocked' else '实验模型/回退策略未满足预期'}。",
                f"- 证据：`results/hybrid-{m}-episodes.jsonl`；空响应中断另见 `results/hybrid-laya-typed-decisions.log`。",
                "- 复现：采用原主模型参数、候选协议及 hybrid_benchmark.py；主模型接口的偶发空响应不能保证确定重现，继续器不重试覆盖原阻塞。", ""])
    bug.extend(["## 执行边界与未验证项", "",
        "- Typed Decisions 混合组的 iframe 场景因主模型空正文触发原适配器 AttributeError，中断于 06_iframe。该轮记执行阻塞，完整回包、轨迹和耗时未保存，不能写成业务失败、调用为零或计算完整加速比。原日志 hybrid-laya-typed-decisions.log 保留，继续器仅执行剩余场景，不覆盖阻塞。",
        "- 弹窗确认/取消依赖宿主辅助适配器，当前原生回放驱动默认确认弹窗，本轮没有验证原生 IR 的取消支持；不能将实验辅助能力当作已接入功能。",
        "- iframe 使用 Playwright 框架穿透选择器；Selenium WebDriver 未执行，未验证引擎间等价性。",
        "- 纯 CPU 进程内存排除浏览器，主模型服务硬件未知；本轮不能比较四款模型 CPU 资源成本。",
        "- 项目历史标识的 gpt-6-luna 不在用户 API 的模型列表中，未执行；没有用其他模型或旧数据替代其结果。",
        "- 未完成 Excel 原生渲染视觉检查；工作簿内容、样式字段、数量及规范以读回/校验结果为准。",""])
    (OUT/"问题清单.md").write_text("\n".join(bug))
    print(json.dumps({"deliverables":str(OUT),"model_episodes":len(rows),"passed":passed,"failed":failed,"summary":summary},ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
