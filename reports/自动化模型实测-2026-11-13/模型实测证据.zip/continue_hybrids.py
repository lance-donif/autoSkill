"""Continue after an unusable primary response, preserving the blocked first attempt.

The original comparison scripts and inference settings are unchanged. This runner adds
failure recording; it never retries or substitutes a successful run for an earlier block.
"""
import argparse
import hashlib
import json
from pathlib import Path
import resource
import time
import traceback

import hybrid_benchmark as original

base = original.base


def blocked_record(decider, task, error):
    episode = None
    remote = None
    tb = error.__traceback__
    while tb:
        frame = tb.tb_frame
        if frame.f_code.co_name == "run_episode":
            episode = frame.f_locals
        if frame.f_code.co_name == "predict" and "raw" in frame.f_locals:
            remote = frame.f_locals
        tb = tb.tb_next
    steps = episode.get("steps", []) if episode else []
    partial = {}
    if remote:
        raw = remote["raw"]
        partial = {k:raw.get(k) for k in ("id", "model", "usage")}
        partial["choices"] = [{"finish_reason":c.get("finish_reason"),"content":c.get("message",{}).get("content")}
                              for c in raw.get("choices",[])]
    return dict(model=decider.name,task=task,language="en",seed=11,
                expected_behavior_satisfied=False,execution_status="Blocked",
                reason="primary_response_unusable",e2e_ms=(time.perf_counter()-episode["start"])*1000 if episode else None,
                host_cpu_ms=None,inference_ms=None,final_url=None,
                extra=episode.get("extra",{}) if episode else {},steps=steps,
                fallback_used=True,local_calls=sum(s["response"].get("decision_provider")==decider.local.name for s in steps),
                main_calls=None,trace_incomplete=True,error=f"{type(error).__name__}: {error}",
                unusable_primary_response=partial)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--local",required=True,choices=["laya-typed-decisions","opendecider-nano"])
    args=ap.parse_args()
    path=base.ROOT/"results"/("hybrid-"+args.local+"-episodes.jsonl")
    prior=[json.loads(x) for x in path.read_text().splitlines()] if path.exists() else []
    protocol_digest=hashlib.sha256((base.ROOT/"results/hybrid-protocol.json").read_bytes()).hexdigest()
    continuation={"original_hybrid_protocol_sha256":protocol_digest,
                  "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  "policy":"Preserve unusable API replies as execution blocks; do not retry; continue remaining episodes"}
    (base.ROOT/"results/hybrid-continuation-protocol.json").write_text(json.dumps(continuation,indent=2))
    if args.local=="laya-typed-decisions" and len(prior)==5:
        # The original process exited before writing episode 06. Its stdout traceback is
        # preserved; neither its full packet nor timing were saved, so leave them unknown.
        record=dict(model="hybrid-"+args.local,task="06_iframe",language="en",seed=11,
            expected_behavior_satisfied=False,execution_status="Blocked",reason="primary_response_unusable",
            e2e_ms=None,host_cpu_ms=None,inference_ms=None,final_url=None,extra={},steps=[],
            fallback_used=True,local_calls=None,main_calls=None,trace_incomplete=True,
            error="AttributeError: 'NoneType' object has no attribute 'strip' in primary response content parser",
            evidence="results/hybrid-laya-typed-decisions.log",hybrid_protocol_sha256=protocol_digest)
        prior.append(record)
        with path.open("a") as out:out.write(json.dumps(record)+"\n")
    completed={r["task"] for r in prior}
    decider=original.Hybrid(args.local)
    for _ in range(3):
        decider.local.predict('Goal: Set Text input to autoskills-42, then submit.\nObserved: Text input is empty; Submit is available.',
                             ["fill_text","fill_area","submit","missing"],[])
    with base.sync_playwright() as pw:
        browser=pw.chromium.launch(executable_path="/usr/bin/chromium",headless=True,
            args=["--no-sandbox","--disable-dev-shm-usage","--disable-background-networking"])
        with path.open("a") as out:
            for task in base.TASKS:
                if task in completed:continue
                decider.reset()
                try:
                    r=base.run_episode(browser,decider,task,"en",11)
                    r.update(fallback_used=decider.escalated,
                        local_calls=sum(s["response"]["decision_provider"]==args.local for s in r["steps"]),
                        main_calls=sum(s["response"]["decision_provider"]==decider.main.name for s in r["steps"]))
                except Exception as exc:
                    r=blocked_record(decider,task,exc)
                r.update(hybrid_protocol_sha256=protocol_digest,continuation_protocol=continuation)
                prior.append(r);out.write(json.dumps(r,ensure_ascii=False)+"\n");out.flush()
                print(json.dumps({k:v for k,v in r.items() if k not in ("steps","extra")}),flush=True)
        browser.close()
    meta=dict(model=decider.name,protocol_sha256=protocol_digest,
              episodes=len(prior),expected_behavior_satisfied=sum(r["expected_behavior_satisfied"] for r in prior),
              blocked_episodes=sum(r.get("execution_status")=="Blocked" for r in prior),
              peak_host_rss_mib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,
              memory_scope="Continuation process only; original process peak unavailable if restarted",
              continuation=continuation)
    (base.ROOT/"results"/(decider.name+"-meta.json")).write_text(json.dumps(meta,indent=2))
    print("DONE",json.dumps(meta),flush=True)


if __name__=="__main__":
    main()
