import json
import unittest
from urllib.request import Request, urlopen

class OrderBusinessTest(unittest.TestCase):
    def test_order_completes(self):
        with urlopen(Request('http://127.0.0.1:18783/api/order',method='POST'),timeout=20) as response:
            body=json.load(response)
        self.assertEqual(body['message'],'订单完成','订单业务必须完成')

if __name__ == '__main__': unittest.main(verbosity=2)
