import json
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).parent
claim=json.loads(json.loads((ROOT/sys.argv[1]).read_text())['stdout'])['task']
args=[sys.executable,str(ROOT/'cli.py'),sys.argv[3],'workflow','submit',claim['workflow_id'],claim['item_id'],'--attempt-id',claim['attempt_id'],'--lease-token',claim['lease_token'],'--idempotency-key',sys.argv[3],'--file',sys.argv[2]]
raise SystemExit(subprocess.call(args,cwd=ROOT))
