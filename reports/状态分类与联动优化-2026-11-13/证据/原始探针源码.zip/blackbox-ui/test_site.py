from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
import json
import time

STATE = {"mode": "pass", "delay": 4.0}
PAGE = '''<!doctype html><html lang="zh"><meta charset="utf-8"><title>独立黑盒订单站</title>
<h1>独立黑盒订单站</h1><label>订单备注 <input id="note" aria-label="订单备注"></label>
<button id="start">开始订单</button><p id="status" data-testid="status">尚未开始</p>
<script>document.querySelector('#start').onclick=async()=>{document.querySelector('#status').textContent='处理中';let r=await fetch('/api/order',{method:'POST'});let d=await r.json();document.querySelector('#status').textContent=d.message;};</script></html>'''

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == '/__control':
            params = parse_qs(parsed.query)
            if 'mode' in params: STATE['mode'] = params['mode'][0]
            if 'delay' in params: STATE['delay'] = float(params['delay'][0])
            self.reply(json.dumps(STATE).encode(), 'application/json')
        elif parsed.path == '/api/order':
            self.do_POST()
        elif parsed.path == '/': self.reply(PAGE.encode(), 'text/html;charset=utf-8')
        else: self.reply(b'Not found', 'text/plain', 404)
    def do_POST(self):
        if urlparse(self.path).path != '/api/order': return self.reply(b'Not found','text/plain',404)
        mode, delay = STATE['mode'], STATE['delay']
        time.sleep(delay)
        self.reply(json.dumps({'message': '订单完成' if mode=='pass' else '订单失败', 'business': mode}, ensure_ascii=False).encode(), 'application/json;charset=utf-8')
    def reply(self, data, content_type, status=200):
        self.send_response(status); self.send_header('Content-Type',content_type)
        self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)

ThreadingHTTPServer(('127.0.0.1',18783), Handler).serve_forever()
