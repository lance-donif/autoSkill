import os
import json
import subprocess
import sys
import time
from pathlib import Path
ROOT=Path(__file__).parent
env=os.environ.copy()
env.update(PYTHONPATH='/workspace/autoSkill/skills/autoskill/app',AUTOSKILL_WORKSPACE=os.environ.get('BLACKBOX_UI_DATA',str(ROOT/'data')),AUTOSKILL_HEADED='0')
name=sys.argv[1]
args=[sys.executable,'-m','autoskill','--session',os.environ.get('BLACKBOX_UI_SESSION','blackbox-ui')]+sys.argv[2:]
start=time.time()
result=subprocess.run(args,capture_output=True,text=True,env=env)
record={'command':sys.argv[2:],'started_at':start,'finished_at':time.time(),'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
(ROOT/(name+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2))
print(json.dumps(record,ensure_ascii=False,indent=2))
sys.exit(result.returncode)
