from pathlib import Path
from urllib.request import urlopen
import json
import sys
import time
ROOT=Path(__file__).parent
BASE='http://127.0.0.1:18782'
LABEL=sys.argv[1] if len(sys.argv)>1 else 'optimized-critical-axes'
def get(path):
    with urlopen(BASE+path,timeout=10) as response:return json.load(response)
out={'at':time.time(),'version':get('/api/status'),'checks':[],'details':{}}
expected={
    'run-253f88d022a0':{'phase':'settled','outcome':'fail','business':'pass','performance':'fail','quality':'pass','report':'ready'},
    'run-109d89264273':{'phase':'settled','outcome':'pass','business':'pass','performance':'not_applicable','quality':'not_applicable','report':'ready'},
    'run-7fae166ab28f':{'phase':'settled','outcome':'fail','business':'fail','performance':'not_applicable','quality':'not_applicable','report':'ready'},
}
for run_id,wanted in expected.items():
    detail=get('/api/runs/'+run_id)
    out['details'][run_id]=detail
    state=detail['state']
    actual={**{key:state[key] for key in ['phase','outcome','report']},**state['checks']}
    out['checks'].append({'name':'state_axes_'+run_id,'passed':all(actual.get(key)==value for key,value in wanted.items()),'expected':wanted,'actual':actual})
listing=get('/api/runs?cycle=all&limit=100')
out['list']=listing
for run_id,detail in out['details'].items():
    item=next(item for item in listing['items'] if item['id']==run_id)
    out['checks'].append({'name':'list_detail_state_'+run_id,'passed':item['state']==detail['state']})
out['passed']=all(check['passed'] for check in out['checks'])
(ROOT/(LABEL+'.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps({'passed':out['passed'],'checks':out['checks'],'version':out['version']['ui_revision']},ensure_ascii=False,indent=2))
