from urllib.request import urlopen
from pathlib import Path
import hashlib
import json
import time
import sys
ROOT=Path(__file__).parent
BASE='http://127.0.0.1:18782'
REPORT='run_run-109d89264273'
PREFIX=(sys.argv[1]+'-') if len(sys.argv)>1 else ''
def read_report():
    with urlopen(BASE+'/api/task-reports/'+REPORT) as response: return json.load(response)
before=read_report()
(ROOT/(PREFIX+'report-before-missing.json')).write_text(json.dumps(before,ensure_ascii=False,indent=2))
with urlopen(BASE+'/api/task-reports/'+REPORT+'/excel') as response: data=response.read()
(ROOT/(PREFIX+'original-run-export.xlsx')).write_bytes(data)
target=Path(before['excel']).resolve()
assert target.is_relative_to((ROOT/'data').resolve()) and target.suffix=='.xlsx'
assert hashlib.sha256(target.read_bytes()).hexdigest()==hashlib.sha256(data).hexdigest()
target.unlink()
after=read_report()
(ROOT/(PREFIX+'report-after-missing.json')).write_text(json.dumps(after,ensure_ascii=False,indent=2))
print(json.dumps({'removed_export':str(target),'preserved_copy_sha256':hashlib.sha256(data).hexdigest(),'before_status':before.get('status'),'after':after,'at':time.time()},ensure_ascii=False,indent=2))
