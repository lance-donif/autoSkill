"""Independent normal UI entry for draft preservation; no paint timing gate."""
from pathlib import Path
from urllib.request import urlopen
from playwright.sync_api import sync_playwright
import json
import subprocess
import sys
import time
ROOT=Path(__file__).parent
BASE='http://127.0.0.1:18782'
LABEL=sys.argv[1] if len(sys.argv)>1 else 'optimized-input-only'
def get(path):
    with urlopen(BASE+path,timeout=10) as response:return json.load(response)
out={'started_at':time.time(),'start_public_version':get('/api/status'),'errors':[]}
try:
    with urlopen('http://127.0.0.1:18783/__control?mode=fail&delay=3') as response:response.read()
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1600,'height':1100})
        page.on('pageerror',lambda error:out['errors'].append(str(error)))
        page.goto(BASE+'/#/dashboard',wait_until='domcontentloaded')
        page.wait_for_function('()=>document.body.innerText.includes("下面所有数字、图表和列表")',timeout=30000)
        page.get_by_role('link',name='项目与用例',exact=True).click()
        page.get_by_role('button',name='新建项目',exact=True).first.wait_for(state='visible',timeout=30000)
        page.get_by_role('button',name='新建项目',exact=True).first.click()
        draft={'#np-name':'未提交草稿-不得被自动刷新清空','#np-url':'http://example.invalid/draft','#np-cat':'黑盒输入保留'}
        for selector,value in draft.items():page.locator(selector).fill(value)
        page.locator('#np-cat').evaluate('(el)=>{el.focus();el.setSelectionRange(1,4)}')
        out['before']={'values':{selector:page.locator(selector).input_value() for selector in draft},'focus':page.evaluate('({id:document.activeElement.id,start:document.activeElement.selectionStart,end:document.activeElement.selectionEnd})')}
        page.screenshot(path=str(ROOT/(LABEL+'-before.png')),full_page=True)
        created=subprocess.run([sys.executable,str(ROOT/'cli.py'),LABEL+'-run','native','run','127-0-0-1','asset-864fcbae1cad'],cwd=ROOT,capture_output=True,text=True)
        wrapper=json.loads(created.stdout); assert created.returncode==0,wrapper
        run_id=json.loads(wrapper['stdout'])['id'];out['run_id']=run_id
        end=time.time()+25;data=get('/api/runs/'+run_id)
        while time.time()<end and not (data.get('finished_at') and data.get('state',{}).get('report') in ['ready','failed']):
            page.wait_for_timeout(500);data=get('/api/runs/'+run_id)
        out['terminal_detail']=data
        page.wait_for_timeout(1000)
        out['after']={'values':{selector:page.locator(selector).input_value() if page.locator(selector).count() else None for selector in draft},'focus':page.evaluate('({id:document.activeElement.id,start:document.activeElement.selectionStart,end:document.activeElement.selectionEnd})')}
        out['body']=page.locator('body').inner_text()
        out['document_visibility']=page.evaluate('document.visibilityState')
        page.screenshot(path=str(ROOT/(LABEL+'-after.png')),full_page=True)
        out['passed']=bool(data.get('finished_at')) and out['before']==out['after'] and not out['errors']
        page.get_by_role('button',name='取消',exact=True).click()
        browser.close()
except Exception as exc:out['error']=repr(exc)
finally:
    out['finished_at']=time.time();out['finish_public_version']=get('/api/status')
    (ROOT/(LABEL+'-results.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2))
    print(json.dumps({key:out.get(key) for key in ['run_id','passed','before','after','error','errors']},ensure_ascii=False,indent=2))
