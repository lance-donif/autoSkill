from pathlib import Path
from playwright.sync_api import sync_playwright
import json
import time
from urllib.parse import urlsplit,parse_qs
ROOT=Path(__file__).parent
BASE='http://127.0.0.1:18782'
out={'started_at':time.time(),'requests':[],'snapshots':[]}
def snap(page,name):
    value={'name':name,'at':time.time(),'url':page.url,'values':page.locator('select').evaluate_all('(els)=>els.map(e=>e.value)'),'rows':page.locator('tbody tr').all_inner_texts()}
    out['snapshots'].append(value)
    return value
try:
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1600,'height':1100})
        page.on('request',lambda request:out['requests'].append({'at':time.time(),'url':request.url}) if '/api/runs?' in request.url else None)
        page.goto(BASE+'/#/runs',wait_until='domcontentloaded')
        page.locator('tbody tr').first.wait_for(state='visible',timeout=20000)
        page.wait_for_timeout(1200)
        snap(page,'initial')
        for index,value in [(0,'all'),(3,'fail'),(4,'not_applicable')]:
            key={0:'cycle',3:'business',4:'performance'}[index]
            with page.expect_response(lambda response:urlsplit(response.url).path=='/api/runs' and parse_qs(urlsplit(response.url).query).get(key)==[value],timeout=30000) as response:
                page.locator('select').nth(index).select_option(value)
            returned=response.value.json()
            page.wait_for_function('(count)=>document.querySelectorAll("tbody tr").length===count',arg=len(returned['items']),timeout=30000)
            page.wait_for_timeout(500)
            snap(page,'after-select-'+str(index))
        page.screenshot(path=str(ROOT/'candidate-fixed-combined-filters.png'),full_page=True)
        expected=['all','','','fail','not_applicable','']
        out['passed']=out['snapshots'][-1]['values']==expected
        out['expected']=expected
        browser.close()
except Exception as exc:out['error']=repr(exc)
finally:
    out['finished_at']=time.time()
    (ROOT/'candidate-fixed-filter-combination.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
    print(json.dumps(out,ensure_ascii=False,indent=2))
