from pathlib import Path
from urllib.request import urlopen
import hashlib
import json
import time
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).parent
BASE='http://127.0.0.1:18782'
RUN='run-109d89264273'
REPORT='run_'+RUN
def get(path):
    with urlopen(BASE+path,timeout=10) as response: return json.load(response)
def snapshot(page,name):
    page.screenshot(path=str(ROOT/(name+'.png')),full_page=True)
    (ROOT/(name+'.txt')).write_text(page.locator('body').inner_text())
evidence={'started_at':time.time(),'checks':[]}
try:
    evidence['before_list']=get('/api/runs?cycle=all&limit=100')
    evidence['before_detail']=get('/api/runs/'+RUN)
    evidence['before_report']=get('/api/task-reports/'+REPORT)
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1600,'height':1100})
        page.goto(BASE+'/#/runs/'+RUN,wait_until='domcontentloaded')
        page.get_by_role('button',name='重试导出报告',exact=True).wait_for(state='visible',timeout=20000)
        snapshot(page,'final-report-failed-before-retry')
        body=page.locator('body').inner_text()
        evidence['checks'].append({'name':'failed_report_is_separate_from_business_success','passed':'重试导出报告' in body and '已结束' in body and '业务：通过' in body and '报告：失败' in body,'body':body})
        page.get_by_role('button',name='重试导出报告',exact=True).click()
        page.get_by_text('下载本次用例 Excel',exact=True).wait_for(state='visible',timeout=20000)
        page.wait_for_timeout(300)
        snapshot(page,'final-report-ready-after-retry')
        evidence['after_body']=page.locator('body').inner_text()
        browser.close()
    evidence['after_list']=get('/api/runs?cycle=all&limit=100')
    evidence['after_detail']=get('/api/runs/'+RUN)
    evidence['after_report']=get('/api/task-reports/'+REPORT)
    before=evidence['before_detail']; after=evidence['after_detail']
    compare=['id','status','finished_at','total','done','passed','failed','blocked','input_hash']
    unchanged={key:before.get(key)==after.get(key) for key in compare}
    before_ids=[item['id'] for item in evidence['before_list']['items']]
    after_ids=[item['id'] for item in evidence['after_list']['items']]
    evidence['checks'].append({'name':'manual_report_retry_does_not_rerun_tests','passed':all(unchanged.values()) and before_ids==after_ids,'unchanged':unchanged,'before_run_ids':before_ids,'after_run_ids':after_ids})
    report=evidence['after_report']
    hashes={}
    for kind,key in [('excel','sha256'),('markdown','markdown_sha256'),('bugs','bugs_sha256')]:
        with urlopen(BASE+'/api/task-reports/'+REPORT+'/'+kind) as response: data=response.read()
        hashes[kind]={'expected':report.get(key),'actual':hashlib.sha256(data).hexdigest(),'size':len(data)}
        (ROOT/('retried-report.'+{'excel':'xlsx','markdown':'md','bugs':'bugs.md'}[kind])).write_bytes(data)
    evidence['checks'].append({'name':'manual_report_retry_restores_verified_files_from_same_snapshot','passed':report.get('status')=='ready' and report.get('source_hash')==evidence['before_report'].get('source_hash') and all(value['expected']==value['actual'] for value in hashes.values()),'hashes':hashes})
except Exception as exc: evidence['error']=repr(exc)
finally:
    evidence['finished_at']=time.time()
    (ROOT/'report-retry-ui-results.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2))
    print(json.dumps(evidence,ensure_ascii=False,indent=2))
