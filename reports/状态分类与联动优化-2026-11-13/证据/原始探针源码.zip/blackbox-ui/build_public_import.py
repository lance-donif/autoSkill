from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib
import json
ROOT=Path(__file__).parent
with ZipFile(ROOT/'empty-project.zip') as source:
    files={name:source.read(name) for name in source.namelist()}
case=json.loads((ROOT/'workflow-materialize.json').read_text())['cases'][0]
case['id']='TC-API-STATISTICS'
case['title']='订单业务返回值独立验证'
case['extensions']['test_case_document']={'business_path':['黑盒接口统计','订单业务'],'author':'独立黑盒测试'}
requirements=json.loads((ROOT/'workflow-requirements.json').read_text())['requirements']
def data(value): return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
files['projects/localhost/testcases/api-cases.json']=data([case])
files['projects/localhost/analysis/requirements.json']=data(requirements)
manifest=json.loads(files['autoskill-pack.json'])
manifest['projects'][0]['cases']={'total':1,'ui':0,'api':1}
for name,content in files.items():
    if name=='autoskill-pack.json':continue
    manifest['files'][name]={'sha256':hashlib.sha256(content).hexdigest(),'size':len(content),'mode':384}
files['autoskill-pack.json']=data(manifest)
with ZipFile(ROOT/'own-public-import.zip','w',ZIP_DEFLATED) as target:
    for name,content in files.items(): target.writestr(name,content)
print('Prepared own public share package with one requirement and one independently defined API testcase.')
