from datetime import datetime
from pathlib import Path
from urllib.request import urlopen
from playwright.sync_api import sync_playwright
import json
import os
import re
import subprocess
import sys
import time

ROOT=Path(__file__).parent
BASE='http://127.0.0.1:18782'
LABEL=sys.argv[1] if len(sys.argv)>1 else 'dashboard-revalidation'
def cpu_snapshot():
    try:return {'at':time.time(),'stat':{line.split()[0]:int(line.split()[1]) for line in Path('/sys/fs/cgroup/cpu.stat').read_text().splitlines()},'cpu_max':Path('/sys/fs/cgroup/cpu.max').read_text().strip()}
    except Exception as exc:return {'unavailable':repr(exc)}
def get(path):
    with urlopen(BASE+path,timeout=10) as response:return json.load(response)
result={'label':LABEL,'started_at':time.time(),'start_load_average':os.getloadavg(),'start_cpu':cpu_snapshot(),'start_public_version':get('/api/status'),'requests':[]}
try:
    with urlopen('http://127.0.0.1:18783/__control?mode=pass&delay=5') as response:response.read()
    before_ids={item['id'] for item in get('/api/runs?cycle=current&limit=100')['items']}
    result['before_summary']=get('/api/summary')
    target_failures=result['before_summary']['results']['still_failing']-1
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1600,'height':1100})
        page.bring_to_front()
        page.on('response',lambda response:result['requests'].append({'at':time.time(),'url':response.url,'status':response.status}) if '/api/' in response.url else None)
        page.goto(BASE+'/#/dashboard',wait_until='domcontentloaded')
        page.wait_for_function('()=>document.body.innerText.includes("下面所有数字、图表和列表")',timeout=30000)
        result['before_body']=page.locator('body').inner_text()
        result['document_visibility']=page.evaluate('document.visibilityState')
        page.screenshot(path=str(ROOT/(LABEL+'-before.png')),full_page=True)
        process=subprocess.Popen([sys.executable,str(ROOT/'cli.py'),LABEL+'-run','run','127-0-0-1','--case','TC-API-ORDER','--kind','api'],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        run_id=None; first_ui=None; first_terminal=None; last=None
        try:
            page.wait_for_function('(target)=>{const body=document.body.innerText;const count=body.match(/(\\d+) 条 当前仍失败/);const recent=body.split("最近执行\\n").pop();return count&&Number(count[1])===target&&recent.includes("全部\\n已结束\\n综合：通过\\n业务：通过")}',arg=target_failures,polling='raf',timeout=35000)
            first_ui=page.evaluate('()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve(Date.now()/1000))))')
        except Exception as exc:result['paint_wait_error']=str(exc)
        # Read terminal evidence only after the paint observation.
        new=[item for item in get('/api/runs?cycle=current&limit=100')['items'] if item['id'] not in before_ids]
        if new:
            run_id=new[0]['id']
            data=get('/api/runs/'+run_id)
            if data.get('finished_at'):first_terminal=time.time();last=data
        stdout,stderr=process.communicate(timeout=20)
        result.update(run_id=run_id,process_exit_code=process.returncode,process_stdout=stdout,process_stderr=stderr,first_terminal_observed_at=first_terminal,ui_visible_at=first_ui,terminal_detail=last,after_body=page.locator('body').inner_text())
        page.screenshot(path=str(ROOT/(LABEL+'-after.png')),full_page=True)
        browser.close()
    result['after_summary']=get('/api/summary')
    if last:
        finished=datetime.fromisoformat(last['finished_at']).timestamp()
        result['server_finished_at']=finished
        result['delay_from_finished_ms']=round((first_ui-finished)*1000,1) if first_ui else None
    result['passed']=result.get('delay_from_finished_ms') is not None and result['delay_from_finished_ms']<=1000 and result['process_exit_code']==0 and result['after_summary']['results']['still_failing']==target_failures
except Exception as exc:result['error']=repr(exc)
finally:
    result['finished_at']=time.time(); result['finish_load_average']=os.getloadavg(); result['finish_public_version']=get('/api/status')
    result['finish_cpu']=cpu_snapshot()
    if 'stat' in result['start_cpu'] and 'stat' in result['finish_cpu']:
        result['average_cpu_percent_of_reported_cores']=round(100*(result['finish_cpu']['stat']['usage_usec']-result['start_cpu']['stat']['usage_usec'])/((result['finish_cpu']['at']-result['start_cpu']['at'])*1000000*os.cpu_count()),1)
    (ROOT/(LABEL+'-results.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({key:result.get(key) for key in ['label','run_id','passed','delay_from_finished_ms','error','start_load_average','finish_load_average']},ensure_ascii=False,indent=2))
