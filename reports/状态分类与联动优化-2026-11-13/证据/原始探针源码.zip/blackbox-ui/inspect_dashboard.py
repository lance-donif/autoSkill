from playwright.sync_api import sync_playwright
from pathlib import Path
import json
import time
ROOT=Path(__file__).parent
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1600,'height':1100})
    requests=[]
    page.on('response', lambda response: requests.append({'time':time.time(),'url':response.url,'status':response.status}) if '/api/' in response.url else None)
    page.goto('http://127.0.0.1:18782',wait_until='domcontentloaded')
    page.wait_for_timeout(1800)
    page.screenshot(path=str(ROOT/'baseline-dashboard.png'),full_page=True)
    text=page.locator('body').inner_text()
    links=page.locator('a').evaluate_all('(els)=>els.map(e=>({text:e.innerText,href:e.getAttribute("href")}))')
    (ROOT/'baseline-dashboard.json').write_text(json.dumps({'body':text,'links':links,'requests':requests},ensure_ascii=False,indent=2))
    print(json.dumps({'body':text,'links':links,'requests':requests},ensure_ascii=False,indent=2))
    browser.close()
