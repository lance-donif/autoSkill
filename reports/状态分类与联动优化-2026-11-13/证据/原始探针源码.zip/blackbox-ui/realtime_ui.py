"""Black-box UI checks: only public DOM, observed HTTP endpoints and CLI.

Run after the dashboard process is restarted for the candidate release.
"""
from datetime import datetime
from pathlib import Path
from urllib.request import urlopen
from urllib.parse import urlsplit,parse_qs
import json
import os
import subprocess
import sys
import time
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).parent
BASE='http://127.0.0.1:18782'
ASSET='asset-864fcbae1cad'
LABEL=sys.argv[1] if len(sys.argv)>1 else 'revalidation-concurrent'
def cpu_snapshot():
    try:return {'at':time.time(),'stat':{line.split()[0]:int(line.split()[1]) for line in Path('/sys/fs/cgroup/cpu.stat').read_text().splitlines()},'cpu_max':Path('/sys/fs/cgroup/cpu.max').read_text().strip()}
    except Exception as exc:return {'unavailable':repr(exc)}
evidence={'label':LABEL,'started_at':time.time(),'start_load_average':os.getloadavg(),'cpu_count':os.cpu_count(),'start_cpu':cpu_snapshot(),'checks':[],'http':[],'ui':[]}

def get(path):
    with urlopen(BASE+path,timeout=8) as response: data=json.load(response)
    return data

def native_run(name):
    result=subprocess.run([sys.executable,str(ROOT/'cli.py'),name,'native','run','127-0-0-1',ASSET],capture_output=True,text=True,cwd=ROOT)
    wrapper=json.loads(result.stdout)
    assert result.returncode==0, wrapper
    return json.loads(wrapper['stdout'])['id']

def record_body(page,label):
    text=page.locator('body').inner_text()
    (ROOT/(LABEL+'-'+label+'.txt')).write_text(text)
    page.screenshot(path=str(ROOT/(LABEL+'-'+label+'.png')),full_page=True)
    return text

def result(name,passed,**extra):
    item={'name':name,'passed':passed,**extra}
    evidence['checks'].append(item)
    print(json.dumps({key:value for key,value in item.items() if key in ['name','passed','run_id','delay_from_finished_ms','before','after','actual','expected','url']},ensure_ascii=False),flush=True)

def wait_terminal(page,run_id,condition_js=None,deadline=25):
    end=time.time()+deadline
    first_ui=None
    if condition_js is not None:
        try:
            page.wait_for_function('()=>('+condition_js+')',polling='raf',timeout=deadline*1000)
            first_ui=page.evaluate('()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve(Date.now()/1000))))')
        except Exception as exc:
            evidence['ui'].append({'run_id':run_id,'paint_wait_error':str(exc)})
    # Query the public terminal timestamp after observing paint, so repeated
    # evidence hashing requests do not compete with the UI during measurement.
    data=get('/api/runs/'+run_id)
    while not data.get('finished_at') and time.time()<end:
        page.wait_for_timeout(500)
        data=get('/api/runs/'+run_id)
    terminal_data=data if data.get('finished_at') else None
    first_terminal=time.time() if terminal_data else None
    last_body=page.locator('body').inner_text()
    evidence['http'].append({'run_id':run_id,'terminal_timestamp_read_at':first_terminal,'data':data})
    evidence['ui'].append({'run_id':run_id,'first_painted_at':first_ui,'paint_method':'DOM predicate followed by two requestAnimationFrame callbacks','body':last_body})
    if terminal_data:
        finished=datetime.fromisoformat(terminal_data['finished_at']).timestamp()
        return {'run_id':run_id,'server_finished_at':finished,'first_terminal_observed_at':first_terminal,'ui_visible_at':first_ui,'delay_from_finished_ms':round((first_ui-finished)*1000,1) if first_ui else None,'body':last_body,'api':terminal_data}
    return {'run_id':run_id,'ui_visible_at':first_ui,'body':last_body,'error':'terminal result not observed'}

def choose_filter(page,index,value,key):
    with page.expect_response(lambda response:urlsplit(response.url).path=='/api/runs' and parse_qs(urlsplit(response.url).query).get(key)==[value],timeout=30000) as response:
        page.locator('select').nth(index).select_option(value)
    returned=response.value.json()
    page.wait_for_function('(args)=>document.querySelectorAll("tbody tr").length===args.count&&document.querySelectorAll("select")[args.index].value===args.value',arg={'count':len(returned['items']),'index':index,'value':value},timeout=30000)
    page.evaluate('()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))')

try:
    evidence['start_public_version']=get('/api/status')
    with urlopen('http://127.0.0.1:18783/__control?mode=fail&delay=8') as response: response.read()
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1600,'height':1100})
        page.bring_to_front()
        evidence['document_visibility']=page.evaluate('document.visibilityState')
        page.on('response',lambda response: evidence['http'].append({'at':time.time(),'url':response.url,'status':response.status}) if '/api/' in response.url else None)

        run_id=native_run(LABEL+'-detail-native-run')
        page.goto(BASE+'/#/runs/'+run_id,wait_until='domcontentloaded')
        page.wait_for_function('()=>document.body.innerText.includes("执行引擎 selenium-unittest")',timeout=20000)
        before=record_body(page,'realtime-detail-running')
        result('active_run_does_not_claim_business_pass','业务：通过' not in before and '执行中' in before,body=before)
        observation=wait_terminal(page,run_id,'document.body.innerText.includes("执行记录\\n已结束\\n独立黑盒订单")&&document.body.innerText.includes("业务：失败")')
        result('detail_online_refresh_within_1s',observation.get('delay_from_finished_ms') is not None and 0<=observation['delay_from_finished_ms']<=1000,**observation)
        record_body(page,'realtime-detail-settled')

        page.goto(BASE+'/#/runs',wait_until='domcontentloaded')
        page.locator('tbody tr').first.wait_for(state='visible',timeout=20000)
        choose_filter(page,0,'all','cycle')
        choose_filter(page,3,'fail','business')
        choose_filter(page,4,'not_applicable','performance')
        page.wait_for_function('()=>new URLSearchParams(location.hash.split("?")[1]||"").get("business")==="fail"',timeout=10000)
        selected_before=page.locator('select').evaluate_all('(els)=>els.map(e=>e.value)')
        evidence['filter_url_before']=page.url
        count_before=page.locator('tbody tr').count()
        run_id=native_run(LABEL+'-list-native-run')
        observation=wait_terminal(page,run_id,'document.querySelectorAll("tbody tr").length==='+str(count_before+1)+'&&document.querySelector("tbody tr").innerText.includes("已结束")')
        selected_after=page.locator('select').evaluate_all('(els)=>els.map(e=>e.value)')
        evidence['filter_url_after']=page.url
        result('list_online_refresh_within_1s',observation.get('delay_from_finished_ms') is not None and 0<=observation['delay_from_finished_ms']<=1000,**observation)
        result('filters_survive_auto_refresh',selected_after==selected_before,before=selected_before,after=selected_after)
        record_body(page,'realtime-list-filtered')
        page.locator('tbody tr').first.click()
        result('new_filtered_row_links_to_completed_run',page.url.split('?')[0].endswith('/'+run_id),url=page.url,run_id=run_id)

        page.goto(BASE+'/#/cases',wait_until='domcontentloaded')
        page.get_by_role('button',name='新建项目',exact=True).first.wait_for(state='visible',timeout=20000)
        page.get_by_role('button',name='新建项目',exact=True).first.click()
        draft={'#np-name':'未提交草稿-不得被自动刷新清空','#np-url':'http://example.invalid/draft','#np-cat':'黑盒输入保留'}
        for selector,value in draft.items(): page.locator(selector).fill(value)
        page.locator('#np-cat').evaluate('(el)=>{el.focus();el.setSelectionRange(1,4)}')
        focus_before=page.evaluate('({id:document.activeElement.id,start:document.activeElement.selectionStart,end:document.activeElement.selectionEnd})')
        run_id=native_run(LABEL+'-input-native-run')
        observation=wait_terminal(page,run_id)
        page.wait_for_timeout(1000)
        actual={selector:page.locator(selector).input_value() if page.locator(selector).count() else None for selector in draft}
        result('draft_inputs_survive_background_task_completion',actual==draft,expected=draft,actual=actual,run_id=run_id)
        focus_after=page.evaluate('({id:document.activeElement.id,start:document.activeElement.selectionStart,end:document.activeElement.selectionEnd})')
        result('draft_focus_and_selection_survive_background_task_completion',focus_after==focus_before,before=focus_before,after=focus_after,run_id=run_id)
        record_body(page,'realtime-input-preserved')
        page.get_by_role('button',name='取消',exact=True).click()
        browser.close()
except Exception as exc:
    evidence['error']=repr(exc)
    print(repr(exc),flush=True)
finally:
    evidence['finished_at']=time.time()
    evidence['finish_load_average']=os.getloadavg()
    evidence['finish_cpu']=cpu_snapshot()
    if 'stat' in evidence['start_cpu'] and 'stat' in evidence['finish_cpu']:
        evidence['average_cpu_percent_of_reported_cores']=round(100*(evidence['finish_cpu']['stat']['usage_usec']-evidence['start_cpu']['stat']['usage_usec'])/((evidence['finish_cpu']['at']-evidence['start_cpu']['at'])*1000000*os.cpu_count()),1)
    evidence['finish_public_version']=get('/api/status')
    (ROOT/(LABEL+'-realtime-ui-results.json')).write_text(json.dumps(evidence,ensure_ascii=False,indent=2))
