from pathlib import Path
from urllib.request import urlopen
import json
import time
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).parent
with urlopen('http://127.0.0.1:18783/__control?mode=pass&delay=0.35') as response: control=json.load(response)
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1280,'height':900})
    page.goto('http://127.0.0.1:18783',wait_until='domcontentloaded')
    page.get_by_label('订单备注').fill('独立业务与性能阈值验证')
    started=time.time()
    with page.expect_response(lambda response:response.url.endswith('/api/order')) as info:
        page.get_by_role('button',name='开始订单',exact=True).click()
    body=info.value.json()
    page.get_by_text('订单完成',exact=True).wait_for(state='visible')
    duration=time.time()-started
    page.screenshot(path=str(ROOT/'performance-source-page.png'),full_page=True)
    result={'control':control,'requirement':{'business_message':'订单完成','declared_performance_goal_ms':50},'actual_response':body,'browser_observed_duration_ms':round(duration*1000,1),'at':time.time()}
    (ROOT/'performance-source-observation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False,indent=2))
    browser.close()
