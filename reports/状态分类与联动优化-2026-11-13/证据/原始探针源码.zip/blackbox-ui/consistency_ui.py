from pathlib import Path
from urllib.request import urlopen
import json
import time
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).parent
BASE='http://127.0.0.1:18782'
HISTORICAL='run-e8c9e3e0d741'
def get(path):
    with urlopen(BASE+path,timeout=10) as response: return json.load(response)
evidence={'started_at':time.time(),'checks':[],'responses':[]}
def check(name,passed,**extra): evidence['checks'].append({'name':name,'passed':passed,**extra})
def snapshot(page,name):
    body=page.locator('body').inner_text()
    page.screenshot(path=str(ROOT/(name+'.png')),full_page=True)
    (ROOT/(name+'.txt')).write_text(body)
    return body
try:
    current=get('/api/runs?cycle=current&limit=100')
    all_cycles=get('/api/runs?cycle=all&limit=100')
    evidence.update(current=current,all_cycles=all_cycles)
    current_ids=[item['id'] for item in current['items']]
    all_ids=[item['id'] for item in all_cycles['items']]
    check('current_cycle_excludes_historical_run',HISTORICAL not in current_ids and HISTORICAL in all_ids,current_ids=current_ids,all_ids=all_ids)
    detail_comparisons=[]
    for item in all_cycles['items']:
        detail=get('/api/runs/'+item['id'])
        keys=['status','total','done','passed','failed','blocked','state']
        comparison={key:item.get(key)==detail.get(key) for key in keys}
        detail_comparisons.append({'id':item['id'],'comparison':comparison,'list':item,'detail':detail})
    evidence['comparisons']=detail_comparisons
    check('public_list_and_detail_states_and_counts_match',all(all(item['comparison'].values()) for item in detail_comparisons))
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1600,'height':1100})
        def response(response):
            if '/api/' not in response.url or '/api/state-revision' in response.url:return
            item={'at':time.time(),'url':response.url,'status':response.status}
            try:item['json']=response.json()
            except Exception:pass
            evidence['responses'].append(item)
        page.on('response',response)
        page.goto(BASE+'/#/runs',wait_until='domcontentloaded')
        page.locator('tbody tr').first.wait_for(state='visible',timeout=20000)
        evidence['current_body']=snapshot(page,'final-current-cycle-list')
        count_current=page.locator('tbody tr').count()
        page.locator('select').first.select_option('all')
        page.wait_for_function('(expected)=>document.querySelectorAll("tbody tr").length===expected',arg=len(all_ids),timeout=20000)
        evidence['all_body']=snapshot(page,'final-all-cycles-list')
        count_all=page.locator('tbody tr').count()
        check('ui_current_and_history_counts_match_api',count_current==len(current_ids) and count_all==len(all_ids),ui_current=count_current,ui_all=count_all)
        check('historical_cycle_is_labelled_in_list','历史周期' in page.locator('tbody').inner_text())
        page.goto(BASE+'/#/runs/'+HISTORICAL,wait_until='domcontentloaded')
        page.get_by_role('button',name='下载 HTML 报告',exact=True).wait_for(state='visible',timeout=20000)
        evidence['historical_detail_body']=snapshot(page,'final-historical-run-detail')
        check('historical_cycle_is_labelled_in_detail','历史周期' in evidence['historical_detail_body'])
        page.goto(BASE+'/#/dashboard',wait_until='domcontentloaded')
        page.wait_for_function('()=>document.body.innerText.includes("下面所有数字、图表和列表")',timeout=30000)
        evidence['dashboard_body']=snapshot(page,'final-dashboard-statistics')
        check('dashboard_shows_existing_execution_statistics','还没有项目' not in evidence['dashboard_body'],expected_current_run_count=len(current_ids))
        browser.close()
except Exception as exc:evidence['error']=repr(exc)
finally:
    evidence['finished_at']=time.time()
    (ROOT/'consistency-ui-results.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2))
    print(json.dumps({'checks':evidence['checks'],'error':evidence.get('error'),'dashboard_body':evidence.get('dashboard_body')},ensure_ascii=False,indent=2))
