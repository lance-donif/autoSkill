from pathlib import Path
from urllib.request import urlopen
from playwright.sync_api import sync_playwright
import json
import time
ROOT=Path(__file__).parent
BASE='http://127.0.0.1:18784'
def get(path):
    with urlopen(BASE+path,timeout=10) as response:return json.load(response)
out={'started_at':time.time(),'public_version':get('/api/status'),'projects':get('/api/projects'),'runs':get('/api/runs?cycle=current&limit=100'),'summary':get('/api/summary')}
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1600,'height':1100})
    page.goto(BASE+'/#/dashboard',wait_until='domcontentloaded')
    page.wait_for_function('()=>document.body.innerText.includes("下面所有数字、图表和列表")',timeout=30000)
    out['body']=page.locator('body').inner_text()
    page.screenshot(path=str(ROOT/'candidate-fixed-native-only-dashboard.png'),full_page=True)
    browser.close()
out['passed']=all(project['cases']['total']==0 for project in out['projects']) and out['runs']['total']==1 and '还没有项目' not in out['body'] and '执行次数\n1' in out['body']
out['finished_at']=time.time()
(ROOT/'candidate-fixed-native-only-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps(out,ensure_ascii=False,indent=2))
