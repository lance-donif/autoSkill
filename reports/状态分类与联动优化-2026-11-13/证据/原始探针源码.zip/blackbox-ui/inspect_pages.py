from playwright.sync_api import sync_playwright
from pathlib import Path
import json
import os
import sys
ROOT=Path(__file__).parent
prefix=sys.argv[1] if len(sys.argv)>1 else 'inspection'
routes=sys.argv[2:] or ['dashboard','runs','schedules','cases']
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1600,'height':1100})
    errors=[]
    page.on('pageerror',lambda e: errors.append(str(e)))
    for route in routes:
        page.goto(os.environ.get('BLACKBOX_DASHBOARD_URL','http://127.0.0.1:18782')+'/#/'+route,wait_until='domcontentloaded')
        if route.startswith('runs/'):
            page.get_by_role('button',name='下载 HTML 报告',exact=True).wait_for(state='visible',timeout=30000)
        elif route=='runs':
            page.locator('tbody tr').first.wait_for(state='visible',timeout=30000)
        elif route=='dashboard':
            page.wait_for_function('()=>document.body.innerText.includes("下面所有数字、图表和列表")',timeout=30000)
        else:
            page.wait_for_timeout(1400)
        record={'body':page.locator('body').inner_text(),'fields':page.locator('input,select,textarea').evaluate_all('(els)=>els.map(e=>({tag:e.tagName,id:e.id,name:e.name,value:e.value,placeholder:e.placeholder,options:e.options?Array.from(e.options).map(x=>({text:x.text,value:x.value})):undefined}))'),'buttons':page.get_by_role('button').all_text_contents(),'links':page.locator('a').evaluate_all('(els)=>els.map(e=>({text:e.innerText,href:e.getAttribute("href")}))'),'errors':errors.copy()}
        (ROOT/(prefix+'-'+route.replace('/','_')+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2))
        page.screenshot(path=str(ROOT/(prefix+'-'+route.replace('/','_')+'.png')),full_page=True)
        print(json.dumps({'route':route,**record},ensure_ascii=False,indent=2))
    browser.close()
