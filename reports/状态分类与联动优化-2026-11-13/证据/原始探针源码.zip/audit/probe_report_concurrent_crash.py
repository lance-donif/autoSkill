"""Two real rendering processes: a waiting exporter must not retry a crashed one."""
import json
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path
from unittest.mock import patch

sys.dont_write_bytecode = True
AUDIT = Path(__file__).resolve().parent
ROOT = Path('/workspace/autoSkill')
DATA = AUDIT / ('report-concurrent-data-' + uuid.uuid4().hex[:8])
os.environ.update(AUTOSKILL_WORKSPACE=str(DATA), AUTOSKILL_CASE_SKILL=str(DATA / 'case-sheet'),
                  AUTOSKILL_HEADED='0', AUTOSKILL_BRIDGE='off', AUTOSKILL_SESSION='',
                  AUTOSKILL_WORKFLOW_BINDING='', PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(ROOT / 'skills/autoskill/app'))
sys.path.insert(0, str(ROOT / 'skills/autoskill/app'))
from autoskill import projects, task_reports, workflow
from autoskill.server import jobs

CHILD = """
import os,sys,time
from pathlib import Path
from unittest.mock import patch
from autoskill import reporting,task_reports
root=Path(os.environ['AUTOSKILL_WORKSPACE'])
original=reporting.write_task
def observed(*args,**kwargs):
    with (root/'actual-export-attempts.txt').open('a',encoding='utf-8') as stream:
        stream.write(sys.argv[2]+'\\n')
    if sys.argv[2]=='crash':
        (root/'first-started').write_text('1')
        deadline=time.monotonic()+10
        while not (root/'allow-crash').exists() and time.monotonic()<deadline:
            time.sleep(.01)
        os._exit(37)
    return original(*args,**kwargs)
with patch.object(reporting,'write_task',side_effect=observed):
    task_reports.finish_workflow_report(sys.argv[1])
"""

with patch.object(jobs, 'ensure_worker', return_value={'status': 'running', 'pid': None}):
    project = projects.create('并发导出崩溃审计', 'http://127.0.0.1:9', project_id='audit-report-race')['id']
    flow = workflow.create(project, {'title': '两个导出协调器', 'sources': [{'id': 's1', 'text': '并发导出'}]}, idempotency_key='create')['workflow_id']
    completed = workflow.cancel(flow, idempotency_key='cancel')
report_id = completed['test_report']['report_id']
first = subprocess.Popen([sys.executable, '-c', CHILD, report_id, 'crash'])
second = None
try:
    deadline = time.monotonic() + 10
    while not (DATA / 'first-started').exists() and time.monotonic() < deadline:
        time.sleep(.01)
    second = subprocess.Popen([sys.executable, '-c', CHILD, report_id, 'waiting'])
    time.sleep(.2)
    (DATA / 'allow-crash').write_text('1')
    first_code = first.wait(timeout=10)
    second_code = second.wait(timeout=15)
    receipt = task_reports.peek(report_id)
    result = {'data_root': str(DATA), 'report_id': report_id, 'first_exit_code': first_code,
              'waiting_exporter_exit_code': second_code, 'final_status': receipt['status'],
              'actual_export_attempts_without_manual_retry': (DATA / 'actual-export-attempts.txt').read_text().splitlines()}
    output = AUDIT / 'report-concurrent-crash-result.json'
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    (DATA / 'audit-result.json').write_text(output.read_text(), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
finally:
    for child in (first, second):
        if child and child.poll() is None:
            child.kill()
            child.wait(timeout=5)
