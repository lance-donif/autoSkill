"""A real run exporter dies after Excel publication while building its brief."""
import json
import os
import subprocess
import sys
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
DATA = BASE / ('run-report-crash-data-' + uuid.uuid4().hex[:8])
os.environ.update(AUTOSKILL_WORKSPACE=str(DATA), AUTOSKILL_CASE_SKILL=str(DATA / 'sheet'), AUTOSKILL_HEADED='0',
                  AUTOSKILL_BRIDGE='off', AUTOSKILL_SESSION='', AUTOSKILL_WORKFLOW_BINDING='', PYTHONDONTWRITEBYTECODE='1',
                  PYTHONPATH='/workspace/autoSkill/skills/autoskill/app')
sys.path.insert(0, '/workspace/autoSkill/skills/autoskill/app')
from autoskill import builder, db, projects, runner, task_reports, task_state
from autoskill.server import jobs


class Fixture(BaseHTTPRequestHandler):
    calls = 0

    def log_message(self, *args):
        return

    def do_GET(self):
        type(self).calls += 1
        body = b'{"ok":true}'
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)


CHILD = """
import json,os,sys
from pathlib import Path
from unittest.mock import patch
from autoskill import runner,task_markdown,task_reports
with patch.object(task_markdown,'write_task',side_effect=lambda *args,**kwargs:os._exit(37)):
    if len(sys.argv)>2 and sys.argv[2]=='recording':
        request=json.loads(Path(sys.argv[1]).read_text())
        task_reports.for_recording(request['project_id'],request['recording'],request['cases'])
    else:
        runner.execute(sys.argv[1])
"""
server = ThreadingHTTPServer(('127.0.0.1', 0), Fixture)
thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': .01}, daemon=True)
thread.start()
try:
    project = projects.create('单次运行导出中断审计', f'http://127.0.0.1:{server.server_port}', project_id='audit-run-report')['id']
    case = builder.api_case('TC-API-001', '接口真实通过', 'GET', '/', {'status': 200, 'json_equals': {'/ok': True}})
    projects.save_cases(project, [case])
    run_id = runner.create(project, [case['id']])['id']
    child = subprocess.Popen([sys.executable, '-c', CHILD, run_id])
    code = child.wait(timeout=15)
    run = db.one('SELECT * FROM runs WHERE id=?', (run_id,))
    report_id = 'run_' + run_id
    initial = task_state.report(report_id)
    jobs.sweep()
    jobs.reconcile_workflows()
    after = task_state.report(report_id)
    before_calls = Fixture.calls
    retried = task_reports.retry(report_id)
    result = {'data_root': str(DATA), 'run_id': run_id, 'renderer_exit_code': code, 'run_status': run['status'], 'http_calls': Fixture.calls,
              'initial_report': initial, 'after_background_recovery': after, 'manual_retry_status': retried['status'],
              'manual_retry_extra_http_calls': Fixture.calls - before_calls}
    request_file = DATA / 'recording-export-request.json'
    request_file.write_text(json.dumps({'project_id': project, 'recording': {'started_at': db.now(), 'session_id': 'audit-recording', 'rand': 'audit'},
                                        'cases': [projects.case(project, case['id'])]}), encoding='utf-8')
    recording_child = subprocess.Popen([sys.executable, '-c', CHILD, str(request_file), 'recording'])
    recording_code = recording_child.wait(timeout=15)
    recording_folder = next((DATA / '.local/task-reports').glob('recording_*'))
    recording_id = recording_folder.name
    initial_recording = task_state.report(recording_id)
    jobs.sweep()
    jobs.reconcile_workflows()
    recovered_recording = task_state.report(recording_id)
    recording_calls = Fixture.calls
    recording_retried = task_reports.retry(recording_id)
    result['recording'] = {'renderer_exit_code': recording_code, 'report_id': recording_id, 'initial_report_status': initial_recording['status'],
                           'after_background_status': recovered_recording['status'], 'manual_retry_status': recording_retried['status'],
                           'manual_retry_extra_http_calls': Fixture.calls - recording_calls}
    output = BASE / 'run-report-crash-result.json'
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    (DATA / 'audit-result.json').write_text(output.read_text(), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
finally:
    server.shutdown()
    server.server_close()
    thread.join(timeout=2)
