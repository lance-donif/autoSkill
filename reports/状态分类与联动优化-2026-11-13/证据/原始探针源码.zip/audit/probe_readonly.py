"""Read-only HTTP/status/context checks compare all durable rows and artifact bytes."""
import hashlib
import json
import os
import sqlite3
import sys
from pathlib import Path
from unittest.mock import patch

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
facts = json.loads((BASE / 'workflow-state-result.json').read_text())
DATA = Path(facts['data_root'])
os.environ.update(AUTOSKILL_WORKSPACE=str(DATA), AUTOSKILL_CASE_SKILL=str(DATA / 'case-sheet'),
                  AUTOSKILL_HEADED='0', AUTOSKILL_BRIDGE='off', AUTOSKILL_SESSION='', AUTOSKILL_WORKFLOW_BINDING='')
sys.path.insert(0, '/workspace/autoSkill/skills/autoskill/app')
from fastapi.testclient import TestClient
from autoskill import db, host_bindings, reporting, runner, workflow
from autoskill.server.app import create_app

flow = facts['manual_retry_policy']['before']['task_id']
binding = host_bindings.upsert({'host': 'dsh', 'host_session_id': 'audit-pure-read', 'task_session_id': 'audit-pure-task',
                               'workflow_id': flow, 'idempotency_key': 'pure-bind'})['binding']
run = db.one('SELECT * FROM runs WHERE id IN (SELECT run_id FROM workflow_items WHERE workflow_id=?)', (flow,))
client = TestClient(create_app(start_worker=False), base_url='http://127.0.0.1')


def durable_rows():
    with sqlite3.connect(DATA / '.local/autoskill.db') as connection:
        names = [row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        return {name: connection.execute('SELECT * FROM "' + name.replace('"', '""') + '" ORDER BY rowid').fetchall() for name in names}


def evidence_files():
    return {str(file.relative_to(DATA)): hashlib.sha256(file.read_bytes()).hexdigest() for folder in (DATA / '.local/task-reports', DATA / '.local/runs')
            for file in folder.rglob('*') if file.is_file()}


before_rows = durable_rows()
before_files = evidence_files()
paths = [f'/api/workflows/{flow}', f'/api/runs/{run["id"]}',
         f'/api/host/context?host=dsh&host_session_id=audit-pure-read&binding_id={binding["id"]}',
         '/api/host/context?host=dsh&host_session_id=audit-pure-read&revision_only=true', '/api/state-revision', '/api/projects']
responses = []
project_read_versions = []
project_read_facts = []
revision_before = db.one('SELECT revision FROM state_revision WHERE id=1')['revision']
with (patch.object(reporting, 'write_task', side_effect=AssertionError('A state read attempted an export')) as render,
      patch.object(runner, 'spawn', side_effect=AssertionError('A state read attempted execution')) as spawn):
    for _ in range(2):
        for path in paths:
            response = client.get(path)
            responses.append({'path': path, 'status': response.status_code})
    for _ in range(3):
        response = client.get('/api/projects')
        project_read_facts.append(hashlib.sha256(json.dumps(response.json(), sort_keys=True).encode()).hexdigest())
        project_read_versions.append(client.get('/api/state-revision').json()['revision'])
    workflow.status(flow)
result = {'data_root': str(DATA), 'responses': responses, 'durable_rows_unchanged': before_rows == durable_rows(),
          'artifact_bytes_unchanged': before_files == evidence_files(), 'render_calls': render.call_count, 'spawn_calls': spawn.call_count,
          'revision_before': revision_before, 'revision_after': db.one('SELECT revision FROM state_revision WHERE id=1')['revision'],
          'repeated_projects_revision_stable': len(set(project_read_versions)) == 1,
          'repeated_projects_facts_stable': len(set(project_read_facts)) == 1}
(BASE / 'readonly-result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
