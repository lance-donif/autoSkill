"""Independent workflow/read/report/lease audit against real local HTTP execution."""
from __future__ import annotations

import json
import os
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

sys.dont_write_bytecode = True
AUDIT = Path(__file__).resolve().parent
ROOT = Path('/workspace/autoSkill')
DATA = AUDIT / ('workflow-data-' + uuid.uuid4().hex[:8])
os.environ.update(AUTOSKILL_WORKSPACE=str(DATA), AUTOSKILL_CASE_SKILL=str(DATA / 'case-sheet'),
                  AUTOSKILL_HEADED='0', AUTOSKILL_BRIDGE='off', AUTOSKILL_SESSION='',
                  AUTOSKILL_WORKFLOW_BINDING='', PYTHONDONTWRITEBYTECODE='1')
sys.path.insert(0, str(ROOT / 'skills/autoskill/app'))

from autoskill import builder, data_refs, db, host_context, projects, reporting, runner, task_reports, task_state, workflow
from autoskill import workflow_state


class Fixture(BaseHTTPRequestHandler):
    calls = 0
    cancel_run = None

    def log_message(self, *args):
        return

    def do_GET(self):
        type(self).calls += 1
        time.sleep(0.02)
        if type(self).cancel_run:
            db.execute("UPDATE runs SET cancel=1 WHERE id=? AND status='Running'", (type(self).cancel_run,))
            type(self).cancel_run = None
        payload = b'{"value":"actual"}'
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


def key():
    return uuid.uuid4().hex


def claim(flow):
    return workflow.next_task(flow, idempotency_key=key())['task']


def submit(flow, task, payload):
    return workflow.submit(flow, task['id'], lease_token=task['lease_token'], attempt_id=task['attempt_id'],
                           idempotency_key=key(), payload=payload)


def execute_flow(project, *, latency=False, cancel_last=False):
    flow = workflow.create(project, {'title': '独立审计工作流', 'sources': [{'id': 's1', 'text': 'value=actual；响应时间目标需要单独判断'}]}, idempotency_key=key())['workflow_id']
    submit(flow, claim(flow), {'requirements': [{'id': 'r1', 'text': 'value=actual', 'source_ids': ['s1']}]})
    rules = {'status': 200, 'json_equals': {'/value': 'actual'}}
    if latency:
        rules['max_ms'] = 1
    submit(flow, claim(flow), {'scenarios': [{'id': 'sc1', 'title': '验证返回值', 'requirement_ids': ['r1'], 'oracle_ids': ['o1']}],
                               'oracles': [{'id': 'o1', 'kind': 'api', 'requirement_ids': ['r1'], 'checks': rules}]})
    task = claim(flow)
    case = builder.api_case('TC-API-001', '审计响应', 'GET', '/', rules)
    submit(flow, task, {'cases': [case], 'bindings': {'sc1': [case['id']]}})
    workflow.reconcile_pending()
    run_id = db.one("SELECT run_id FROM workflow_items WHERE workflow_id=? AND phase='execute'", (flow,))['run_id']
    if cancel_last:
        Fixture.cancel_run = run_id
    runner.execute(run_id)
    workflow.reconcile_pending()
    return flow, run_id


server = ThreadingHTTPServer(('127.0.0.1', 0), Fixture)
thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': 0.01}, daemon=True)
thread.start()
try:
    with patch.object(runner, 'spawn', return_value=None), patch('autoskill.server.jobs.ensure_worker', return_value={'status': 'running', 'pid': None}):
        project = projects.create('审计工作流状态', f'http://127.0.0.1:{server.server_port}', project_id='audit-flow')['id']
        perf_flow, perf_run = execute_flow(project, latency=True)
        summary = workflow.status(perf_flow)
        perf_row = db.one('SELECT * FROM results WHERE run_id=?', (perf_run,))
        performance = {'workflow_id': perf_flow, 'actual_result_detail': json.loads(perf_row['detail']),
                       'workflow_summary': summary, 'workflow_state': task_state.workflow(summary),
                       'run_state': task_state.run(db.one('SELECT * FROM runs WHERE id=?', (perf_run,)))}
        submit(perf_flow, claim(perf_flow), {'disposition': 'business_defect', 'reason': '业务通过但声明性能目标失败，保留原始断言'})
        submit(perf_flow, claim(perf_flow), {'entries': [{'id': 'k1', 'text': '保留性能失败'}]})
        with patch.object(reporting, 'write_task', wraps=reporting.write_task) as write:
            polled = workflow.status(perf_flow)
        pure_status = {'render_calls_from_status_read': write.call_count, 'returned_test_report': polled.get('test_report')}
        report_id = 'workflow_' + task_state.paging.revision([perf_flow, polled['cycle_id']])
        valid_receipt = task_reports.finish_workflow_report(report_id)
        Path(valid_receipt['bugs']).unlink()
        report_consistency = {'canonical': task_reports.get(report_id), 'host_summary': host_context._report(report_id)}

        passed_flow, passed_run = execute_flow(project)
        last = submit(passed_flow, claim(passed_flow), {'entries': [{'id': 'k2', 'text': '真实HTTP业务已验证'}]})
        with patch.object(reporting, 'write_task', side_effect=OSError('audit forced export failure')):
            failed_report = task_reports.finish_workflow_report(last['test_report']['report_id'])
        with patch.object(reporting, 'write_task', wraps=reporting.write_task) as write:
            resumed = workflow.resume(passed_flow, idempotency_key=key())
        retry_policy = {'before': failed_report, 'render_calls_from_resume': write.call_count, 'after': resumed.get('test_report')}
        calls_before_retry = Fixture.calls
        runs_before_retry = db.one('SELECT COUNT(*) n FROM runs')['n']
        retried = task_reports.retry(failed_report['report_id'])
        retry_policy.update(manual_retry_status=retried['status'],
                            manual_retry_http_calls=Fixture.calls - calls_before_retry,
                            manual_retry_extra_runs=db.one('SELECT COUNT(*) n FROM runs')['n'] - runs_before_retry)
        row = db.one('SELECT * FROM results WHERE run_id=?', (passed_run,))
        ref = json.loads(row['detail'])['attempts'][0]
        data_refs.resolve(ref['path']).unlink()
        invalid_summary = workflow.status(passed_flow)
        evidence_invalidation = {'workflow_state': task_state.workflow(invalid_summary),
                                 'run_state': task_state.run(db.one('SELECT * FROM runs WHERE id=?', (passed_run,)))}

        cancelled_flow, cancelled_run = execute_flow(project, cancel_last=True)
        cancelled_summary = workflow.status(cancelled_flow)
        cancelled = {'workflow': cancelled_summary,
                     'run': db.one('SELECT status,cancel,total,done FROM runs WHERE id=?', (cancelled_run,)),
                     'execute_context': json.loads(db.one("SELECT context FROM workflow_items WHERE workflow_id=? AND phase='execute'", (cancelled_flow,))['context'])}

        before_cycle = workflow.status(perf_flow)
        workflow.revise(perf_flow, {'sources': [{'id': 's1', 'text': '来源已改变，保留旧周期失败'}]},
                        expected_hash=before_cycle['definition_hash'], idempotency_key=key())
        current_cycle = workflow.status(perf_flow)
        all_cycles = workflow.status(perf_flow, cycle='all')
        cycle_scope = {'current_cycle_id': current_cycle['cycle_id'], 'default_item_cycle_ids': sorted({item['cycle_id'] for item in current_cycle['items']}),
                       'current_total': current_cycle['total'], 'all_total': all_cycles['total'],
                       'all_item_cycle_ids': sorted({item['cycle_id'] for item in all_cycles['items']})}

        unknown_flow = workflow.create(project, {'title': '租约未知动作', 'sources': [{'id': 's1', 'text': '审计租约'}]}, idempotency_key=key())['workflow_id']
        leased = claim(unknown_flow)
        binding = {'workflow_id': unknown_flow, 'item_id': leased['id'], 'attempt_id': leased['attempt_id'], 'lease_token': leased['lease_token']}
        intent = workflow.operation_intent('click', {'target': 'submit'}, binding=binding, idempotency_key='audit-intent')
        workflow.operation_receipt(intent, {'error': '真实动作结果未知的模拟收据'}, status='unknown')
        db.execute("UPDATE workflow_attempts SET lease_until='2000-01-01' WHERE id=?", (leased['attempt_id'],))
        workflow.reconcile_pending()
        stale_error = None
        try:
            workflow.heartbeat(unknown_flow, leased['id'], lease_token=leased['lease_token'], attempt_id=leased['attempt_id'], idempotency_key=key())
        except workflow_state.WorkflowError as error:
            stale_error = error.code
        leases = {'stale_heartbeat_error': stale_error, 'items': workflow.status(unknown_flow)['items'],
                  'operations': db.rows('SELECT kind,state FROM workflow_operations WHERE workflow_id=?', (unknown_flow,))}
        result = {'data_root': str(DATA), 'http_calls': Fixture.calls, 'performance_separation': performance,
                  'status_read': pure_status, 'report_consistency': report_consistency, 'manual_retry_policy': retry_policy,
                  'execution_evidence_invalidation': evidence_invalidation, 'lease_unknown_effect': leases,
                  'last_case_cancellation': cancelled, 'cycle_scope': cycle_scope}
        output = AUDIT / 'workflow-state-result.json'
        output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        (DATA / 'audit-result.json').write_text(output.read_text(), encoding='utf-8')
        print(json.dumps(result, ensure_ascii=False, indent=2))
finally:
    server.shutdown()
    server.server_close()
    thread.join(timeout=2)
