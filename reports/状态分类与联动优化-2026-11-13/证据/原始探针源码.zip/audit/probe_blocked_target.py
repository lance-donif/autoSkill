"""Distinguish an unevaluated declared SLA from an absent performance target."""
import json
import os
import socket
import sys
import uuid
from pathlib import Path

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
DATA = BASE / ('blocked-target-data-' + uuid.uuid4().hex[:8])
os.environ.update(AUTOSKILL_WORKSPACE=str(DATA), AUTOSKILL_CASE_SKILL=str(DATA / 'sheet'),
                  AUTOSKILL_HEADED='0', AUTOSKILL_BRIDGE='off', AUTOSKILL_SESSION='', AUTOSKILL_WORKFLOW_BINDING='')
sys.path.insert(0, '/workspace/autoSkill/skills/autoskill/app')
from autoskill import builder, db, projects, runner, task_state

with socket.socket() as reserved:
    reserved.bind(('127.0.0.1', 0))
    project = projects.create('未执行性能目标审计', f'http://127.0.0.1:{reserved.getsockname()[1]}', project_id='audit-target')['id']
    cases = [builder.api_case('TC-API-001', '声明性能目标', 'GET', '/', {'status': 200, 'json_equals': {'/ok': True}, 'max_ms': 100}),
             builder.api_case('TC-API-002', '没有性能目标', 'GET', '/', {'status': 200, 'json_equals': {'/ok': True}})]
    projects.save_cases(project, cases)
    finished = runner.execute(runner.create(project, [case['id'] for case in cases])['id'])
    rows = db.rows('SELECT * FROM results WHERE run_id=? ORDER BY id', (finished['id'],))
    result = {'data_root': str(DATA), 'run_status': finished['status'],
              'results': [{'case_id': row['case_id'], 'stored_performance': json.loads(row['detail'])['performance_status'],
                           'state': task_state.result(row)} for row in rows]}
    output = BASE / 'blocked-target-result.json'
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    (DATA / 'audit-result.json').write_text(output.read_text(), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
