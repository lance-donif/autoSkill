"""Independent real exporter-process crash probe: verify only manual export retries."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import uuid
from pathlib import Path
from unittest.mock import patch

sys.dont_write_bytecode = True
AUDIT = Path(__file__).resolve().parent
ROOT = Path('/workspace/autoSkill')
DATA = AUDIT / ('report-crash-data-' + uuid.uuid4().hex[:8])
os.environ.update(AUTOSKILL_WORKSPACE=str(DATA), AUTOSKILL_CASE_SKILL=str(DATA / 'case-sheet'),
                  AUTOSKILL_HEADED='0', AUTOSKILL_BRIDGE='off', AUTOSKILL_SESSION='',
                  AUTOSKILL_WORKFLOW_BINDING='', PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(ROOT / 'skills/autoskill/app'))
sys.path.insert(0, str(ROOT / 'skills/autoskill/app'))

from autoskill import projects, task_reports, workflow
from autoskill.server import jobs

children = []
original_popen = subprocess.Popen
CHILD = """
import os, sys
from pathlib import Path
from unittest.mock import patch
from autoskill import reporting, task_reports
def crash(*args, **kwargs):
    marker = Path(os.environ['AUTOSKILL_WORKSPACE']) / 'actual-export-attempts.txt'
    with marker.open('a', encoding='utf-8') as stream:
        stream.write('export-started\\n')
        stream.flush()
    os._exit(37)
with patch.object(reporting, 'write_task', side_effect=crash):
    task_reports.finish_workflow_report(sys.argv[1])
"""


def crashing_exporter(command, **kwargs):
    if '--workflow-report' not in command:
        raise AssertionError('Unexpected child command')
    child = original_popen([sys.executable, '-c', CHILD, command[-1]], **kwargs)
    children.append(child)
    return child


with patch.object(jobs, 'ensure_worker', return_value={'status': 'running', 'pid': None}):
    project = projects.create('导出崩溃审计', 'http://127.0.0.1:9', project_id='audit-report-crash')['id']
    flow = workflow.create(project, {'title': '导出进程崩溃', 'sources': [{'id': 's1', 'text': '先终止周期，只检验报告导出'}]}, idempotency_key='create')['workflow_id']
    completed = workflow.cancel(flow, idempotency_key='cancel')
    report_id = completed['test_report']['report_id']
with patch.object(jobs.subprocess, 'Popen', side_effect=crashing_exporter):
    jobs._start_workflow_report()
    first_code = children[-1].wait(timeout=10)
    after_first = task_reports.peek(report_id)
    jobs._start_workflow_report()
    second_spawned = len(children) > 1
    second_code = children[-1].wait(timeout=10) if second_spawned else None
    after_second = task_reports.peek(report_id)
jobs._report_children.clear()
marker = DATA / 'actual-export-attempts.txt'
result = {'data_root': str(DATA), 'report_id': report_id, 'first_exit_code': first_code,
          'after_first_status': after_first['status'], 'auto_spawned_again': second_spawned,
          'second_exit_code': second_code, 'after_second_status': after_second['status'],
          'actual_export_attempts_without_manual_retry': len(marker.read_text().splitlines()) if marker.exists() else 0}
with patch.object(jobs, 'ensure_worker', return_value={'status': 'running', 'pid': None}):
    restarted_flow = workflow.create(project, {'title': '协调器与导出同时退出', 'sources': [{'id': 's1', 'text': '验证重启后的导出失败处理'}]}, idempotency_key='restart-create')['workflow_id']
    restarted = workflow.cancel(restarted_flow, idempotency_key='restart-cancel')
    restarted_report_id = restarted['test_report']['report_id']
start_count = len(children)
with patch.object(jobs.subprocess, 'Popen', side_effect=crashing_exporter):
    jobs._start_workflow_report()
    children[-1].wait(timeout=10)
    # Simulate all process-local coordination state being lost in a coordinator restart.
    jobs._report_children.clear()
    jobs.reconcile_workflows()
    respawned_after_restart = len(children) - start_count > 1
    if respawned_after_restart:
        children[-1].wait(timeout=10)
    result['coordinator_restart'] = {'report_id': restarted_report_id, 'auto_spawned_again': respawned_after_restart,
                                     'actual_export_attempts': len(children) - start_count,
                                     'receipt_status': task_reports.peek(restarted_report_id)['status']}
jobs._reports_running()
jobs._report_children.clear()
(AUDIT / 'report-crash-result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
(DATA / 'audit-result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
