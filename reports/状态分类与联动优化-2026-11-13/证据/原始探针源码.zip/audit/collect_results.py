"""Collect independent audit observations without importing or mutating product code."""
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent


def read(name):
    return json.loads((BASE / (name + '-result.json')).read_text())


checks = {}
r = read('receipt-binding')
checks['receipt_metadata_cannot_override_actual_failure'] = r['receipt_unchanged'] and not r['evidence_valid_after_edit'] and r['report_case_verdict_after_edit'] == 'Unverified'
r = read('native-state')
checks['native_manifest_tamper_invalidates_evidence'] = r['native_input_integrity']['after']['evidence'] == 'invalid' and r['native_input_integrity']['after']['outcome'] == 'unverified'
checks['ai_performance_and_quality_are_separate'] = r['ai_performance']['run_state']['checks'] == {'business': 'pass', 'performance': 'fail', 'quality': 'pass'}
r = read('workflow-state')
checks['status_does_not_render'] = r['status_read']['render_calls_from_status_read'] == 0
checks['failed_export_only_manual_retry_no_tests'] = r['manual_retry_policy']['render_calls_from_resume'] == 0 and r['manual_retry_policy']['manual_retry_status'] == 'ready' and r['manual_retry_policy']['manual_retry_http_calls'] == 0 and r['manual_retry_policy']['manual_retry_extra_runs'] == 0
checks['trio_failure_shared_by_host'] = r['report_consistency']['canonical']['status'] == r['report_consistency']['host_summary']['receipt_status'] == 'failed'
checks['execution_evidence_invalidates_aggregate'] = all(value['outcome'] == 'unverified' for value in r['execution_evidence_invalidation'].values())
checks['current_cycle_default_history_available'] = r['cycle_scope']['default_item_cycle_ids'] == [r['cycle_scope']['current_cycle_id']] and r['cycle_scope']['all_total'] > r['cycle_scope']['current_total']
checks['stale_lease_fenced_unknown_effect_not_replayed'] = r['lease_unknown_effect']['stale_heartbeat_error'] == 'stale_lease' and r['lease_unknown_effect']['operations'] == [{'kind': 'click', 'state': 'unknown'}]
checks['last_case_cancellation_stops_publication'] = r['last_case_cancellation']['execute_context']['publication'] == 'interrupted'
r = read('report-crash')
checks['workflow_export_crash_and_restart_require_manual_retry'] = r['after_second_status'] == 'failed' and r['actual_export_attempts_without_manual_retry'] == 1 and not r['coordinator_restart']['auto_spawned_again'] and r['coordinator_restart']['receipt_status'] == 'failed'
r = read('report-concurrent-crash')
checks['waiting_exporter_does_not_retry_crashed_exporter'] = r['final_status'] == 'failed' and r['actual_export_attempts_without_manual_retry'] == ['crash']
r = read('run-report-crash')
checks['run_and_recording_interrupted_exports_fail_without_replay'] = r['after_background_recovery']['status'] == 'failed' and r['manual_retry_status'] == 'ready' and r['manual_retry_extra_http_calls'] == 0 and r['recording']['after_background_status'] == 'failed' and r['recording']['manual_retry_status'] == 'ready' and r['recording']['manual_retry_extra_http_calls'] == 0
r = read('auth-revision')
checks['current_input_change_preserves_history_and_changes_revision'] = r['before']['current'] and not r['after']['current'] and r['after']['outcome'] == 'unverified' and r['after']['historical_outcome'] == 'pass' and r['revision_changed_after_auth_service']
r = read('blocked-target')
checks['declared_unmeasured_target_differs_from_absent_target'] = [row['state']['checks']['performance'] for row in r['results']] == ['unverified', 'not_applicable']
r = read('readonly')
checks['successful_http_reads_leave_durable_state_and_artifacts_unchanged'] = {row['status'] for row in r['responses']} == {200} and r['durable_rows_unchanged'] and r['artifact_bytes_unchanged'] and r['render_calls'] == r['spawn_calls'] == 0
checks['repeated_projects_reads_keep_revision_and_facts_stable'] = r['revision_before'] == r['revision_after'] and r['repeated_projects_revision_stable'] and r['repeated_projects_facts_stable']
r = read('host-state-consistency')
checks['host_and_workflow_cancellation_agree'] = r['same_lifecycle_phase_outcome']
r = read('host-prestep-state')
checks['host_prestep_keeps_all_state_axes'] = r['workflow_has_state'] and r['run_has_state']
r = read('browser-sync')
checks['real_foreground_sync_within_one_second'] = r['all_terminal_updates_under_one_second'] and r['missing_bug_to_dom_ms'] <= 1000 and r['focused_refresh']['terminal_to_dom_ms'] <= 1000 and not r['page_errors']
checks['focus_draft_selection_and_retry_count_preserved'] = r['focused_refresh']['editor_identity_draft_and_selection_preserved'] and r['unverified_retry']['found_correct_count']
checks['idle_page_does_not_enter_revision_render_feedback_loop'] = r.get('idle_history_dom_mutations') == 0
r = read('report-generation')
checks['resume_gets_new_report_and_keeps_old_bytes'] = r['old_id'] != r['new_id'] == r['host_interim_report_id'] == r['final_report_id'] and r['final_report_status'] == 'ready' and r['final_cases'] == 2 and r['old_artifact_bytes_unchanged'] and r['old_snapshot_bytes_unchanged']
checks['published_cases_retain_current_input_validity'] = all(row['state']['current'] and row['state']['outcome'] == 'pass' for row in r['current_case_states'])
r = read('cache-race')
checks['native_evidence_race_cannot_poison_later_proof_cache'] = not r['direct_current_evidence_valid'] and all(row['evidence'] == 'invalid' and row['outcome'] == 'unverified' for row in r['later_independent_reads'])
r = read('trio-readback')
checks['trio_independent_readback_hashes_and_snapshot_match'] = r['source_hash_retained'] and all(value['exists'] and value['sha256_matches'] and value['size_matches'] and value['readable'] for value in r['artifacts'].values()) and r['artifacts']['excel']['functional_sheet_columns'] == 14
output = {'checks': checks, 'passed': sum(checks.values()), 'total': len(checks), 'not_passed': [key for key, passed in checks.items() if not passed]}
(BASE / 'final-checks.json').write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(output, ensure_ascii=False, indent=2))
