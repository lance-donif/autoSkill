"""Independent evidence integrity probe; writes only to its own audit data root."""
from __future__ import annotations

import hashlib
import json
import os
import sys
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.dont_write_bytecode = True
AUDIT = Path(__file__).resolve().parent
ROOT = Path('/workspace/autoSkill')
DATA = AUDIT / ('receipt-data-' + uuid.uuid4().hex[:8])
os.environ.update(AUTOSKILL_WORKSPACE=str(DATA), AUTOSKILL_CASE_SKILL=str(DATA / 'case-sheet'),
                  AUTOSKILL_HEADED='0', AUTOSKILL_BRIDGE='off', AUTOSKILL_SESSION='',
                  AUTOSKILL_WORKFLOW_BINDING='', PYTHONDONTWRITEBYTECODE='1')
sys.path.insert(0, str(ROOT / 'skills/autoskill/app'))

from autoskill import builder, data_refs, db, execution_inputs, projects, runner, task_report_data


class Fixture(BaseHTTPRequestHandler):
    calls = 0

    def log_message(self, *args):
        return

    def do_GET(self):
        type(self).calls += 1
        payload = b'{"value":"actual"}'
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


server = ThreadingHTTPServer(('127.0.0.1', 0), Fixture)
thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': 0.01}, daemon=True)
thread.start()
try:
    project = projects.create('审计收据绑定', f'http://127.0.0.1:{server.server_port}', project_id='audit-receipt')['id']
    case = builder.api_case('TC-API-001', '真实失败不可变成通过', 'GET', '/', {'status': 200, 'json_equals': {'/value': 'expected'}})
    projects.save_cases(project, [case])
    run_id = runner.create(project, [case['id']])['id']
    finished = runner.execute(run_id)
    run = db.one('SELECT * FROM runs WHERE id=?', (run_id,))
    original = db.one('SELECT * FROM results WHERE run_id=?', (run_id,))
    original_detail = json.loads(original['detail'])
    reference = original_detail['attempts'][0]
    attempt_file = data_refs.resolve(reference['path'])
    before = hashlib.sha256(attempt_file.read_bytes()).hexdigest()
    original_receipt = json.loads(attempt_file.read_bytes())
    changed = dict(original_detail)
    changed.update(business_status='Pass', business_verified=True, verification='verified')
    changed['assertions'] = [{**row, 'passed': True} for row in changed.get('assertions', [])]
    # Simulate inconsistent durable result metadata, without editing the frozen receipt.
    db.execute("UPDATE results SET status='Pass',category='',reason='',detail=? WHERE id=?", (json.dumps(changed), original['id']))
    edited = db.one('SELECT * FROM results WHERE id=?', (original['id'],))
    snapshot = task_report_data.run_snapshot(run)
    result = {
        'source_files_sha256': {name: hashlib.sha256((ROOT / 'skills/autoskill/app/autoskill' / name).read_bytes()).hexdigest()
                                for name in ('execution_inputs.py', 'task_report_data.py', 'runner.py')},
        'data_root': str(DATA), 'run_id': run_id, 'http_calls': Fixture.calls,
        'original_run_status': finished['status'], 'original_result_status': original['status'],
        'actual_receipt_status': original_receipt['outcome']['status'],
        'actual_receipt_business': original_receipt['outcome']['business_status'],
        'receipt_unchanged': before == hashlib.sha256(attempt_file.read_bytes()).hexdigest(),
        'edited_result_status': edited['status'], 'edited_business': changed['business_status'],
        'evidence_valid_after_edit': execution_inputs.result_evidence(run, edited),
        'report_case_verdict_after_edit': task_report_data.case_verdict(snapshot['cases'][0]),
    }
    output = AUDIT / 'receipt-binding-result.json'
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    (DATA / 'audit-result.json').write_text(output.read_text(), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
finally:
    server.shutdown()
    server.server_close()
    thread.join(timeout=2)
