"""Lightweight real TCP checks of the incremental dashboard bundle only."""
import contextlib
import hashlib
import json
import os
import socket
import sqlite3
import sys
import threading
import time
from pathlib import Path
from unittest.mock import patch

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
facts = json.loads((BASE / 'workflow-state-result.json').read_text())
DATA = Path(facts['data_root'])
os.environ.update(AUTOSKILL_WORKSPACE=str(DATA), AUTOSKILL_CASE_SKILL=str(DATA / 'case-sheet'),
                  AUTOSKILL_HEADED='0', AUTOSKILL_BRIDGE='off', AUTOSKILL_SESSION='', AUTOSKILL_WORKFLOW_BINDING='')
sys.path.insert(0, '/workspace/autoSkill/skills/autoskill/app')
import httpx
import uvicorn
from autoskill import data_refs, db, reporting, runner
from autoskill.server import metrics
from autoskill.server.app import create_app


def rows():
    with sqlite3.connect(DATA / '.local/autoskill.db') as connection:
        tables = [row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        return {name: connection.execute('SELECT * FROM "' + name.replace('"', '""') + '" ORDER BY rowid').fetchall() for name in tables}


def files():
    return {str(file.relative_to(DATA)): hashlib.sha256(file.read_bytes()).hexdigest() for folder in (DATA / '.local/runs', DATA / '.local/task-reports')
            for file in folder.rglob('*') if file.is_file()}


with socket.socket() as binding:
    binding.bind(('127.0.0.1', 0))
    port = binding.getsockname()[1]
server = uvicorn.Server(uvicorn.Config(create_app(port=port, start_worker=False), host='127.0.0.1', port=port, log_level='error'))
thread = threading.Thread(target=server.run, daemon=True)
thread.start()
deadline = time.monotonic() + 5
while not server.started and time.monotonic() < deadline:
    time.sleep(.01)
before_rows, before_files = rows(), files()
connections, snapshots = [], []
original_connection = metrics._connection


@contextlib.contextmanager
def traced_connection(scope):
    with original_connection(scope) as connection:
        connections.append(id(connection))
        snapshots.append(id(scope._snapshot))
        yield connection


project = facts['performance_separation']['workflow_state']['scope']['project_id']
query = f'?cycle=all&projects={project}&limit=20'
original_attempt = None
attempt_file = None
try:
    with httpx.Client(base_url=f'http://127.0.0.1:{port}', timeout=10) as client:
        with patch.object(reporting, 'write_task', side_effect=AssertionError('GET attempted export')) as render, \
             patch.object(runner, 'spawn', side_effect=AssertionError('GET attempted execution')) as spawn:
            with patch.object(metrics, '_connection', side_effect=traced_connection):
                response = client.get('/api/dashboard' + query)
                packet = response.json()
            summary = client.get('/api/summary' + query).json()
            recent = client.get('/api/runs' + query).json()
            result_page = client.get('/api/results' + query).json()
            current = client.get('/api/dashboard' + query + '&current=true').json()
            limited = client.get('/api/dashboard' + query.replace('limit=20', 'limit=1')).json()
            excluded = client.get('/api/dashboard?projects=no-such-project&cycle=all').json()
            pure_rows, pure_files = rows(), files()
            candidate = next(row for row in result_page['items'] if row['state']['outcome'] == 'pass')
            actual = db.one('SELECT * FROM results WHERE id=?', (candidate['id'],))
            reference = json.loads(actual['detail'])['attempts'][0]
            attempt_file = data_refs.resolve(reference['path'])
            original_attempt = attempt_file.read_bytes()
            attempt_file.write_bytes(b'invalid audit receipt')
            damaged = client.get('/api/dashboard' + query).json()
            attempt_file.write_bytes(original_attempt)
            restored = client.get('/api/dashboard' + query).json()
            expected_failures = [row['id'] for row in result_page['items'] if row['state']['outcome'] in ('fail', 'blocked')]
            checks = {
                'tcp_status_ok': response.status_code == 200,
                'scope_sql_connection_and_snapshot_shared': len(set(connections)) == len(set(snapshots)) == 1,
                'summary_matches_existing_endpoint': packet['summary'] == summary,
                'recent_matches_existing_endpoint': packet['recent'] == recent,
                'totals_agree': packet['summary']['runs']['total'] == packet['recent']['total'] and packet['summary']['results']['executions'] == result_page['total'],
                'failure_membership_agrees': [row['id'] for row in packet['failures']['items']] == expected_failures and packet['failures']['total'] == len(expected_failures),
                'current_toggle_uses_latest_case_outcome': current['failures']['total'] == packet['summary']['results']['still_failing'] and current['failures']['total'] < packet['failures']['total'],
                'limit_preserves_totals': limited['recent']['total'] == recent['total'] and len(limited['recent']['items']) == 1 and limited['failures']['total'] == packet['failures']['total'] and len(limited['failures']['items']) == 1,
                'project_scope_excludes_other_data': excluded['summary']['runs']['total'] == excluded['recent']['total'] == excluded['failures']['total'] == 0,
                'pure_get_has_no_durable_effects': before_rows == pure_rows and before_files == pure_files and render.call_count == spawn.call_count == 0,
                'damage_invalidates_next_response': damaged['summary']['results']['passed'] == packet['summary']['results']['passed'] - 1 and damaged['summary']['results']['unverified'] == packet['summary']['results']['unverified'] + 1,
                'restoration_revalidates_next_response': restored['summary'] == packet['summary'] and restored['recent'] == packet['recent'],
                'all_reads_leave_rows_and_restored_bytes_unchanged': before_rows == rows() and before_files == files(),
            }
    result = {'data_root': str(DATA), 'transport': 'real loopback TCP, existing independently executed evidence, no new cases or native/browser runs',
              'checks': checks, 'passed': sum(checks.values()), 'total': len(checks), 'not_passed': [name for name, value in checks.items() if not value],
              'observed': {'runs': recent['total'], 'results': result_page['total'], 'failures_all': packet['failures']['total'],
                           'failures_current': current['failures']['total'], 'scope_query_calls': len(connections),
                           'passed_before_damage': packet['summary']['results']['passed'], 'passed_after_damage': damaged['summary']['results']['passed']}}
    (BASE / 'dashboard-bundle-result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
finally:
    if original_attempt is not None and attempt_file is not None:
        attempt_file.write_bytes(original_attempt)
    server.should_exit = True
    thread.join(timeout=5)
