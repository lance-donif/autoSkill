"""Compare the public workflow and host projections of the same cancelled cycle."""
import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
facts = json.loads((BASE / 'workflow-state-result.json').read_text())
os.environ.update(AUTOSKILL_WORKSPACE=facts['data_root'], AUTOSKILL_CASE_SKILL=facts['data_root'] + '/case-sheet',
                  AUTOSKILL_HEADED='0', AUTOSKILL_BRIDGE='off', AUTOSKILL_SESSION='', AUTOSKILL_WORKFLOW_BINDING='')
sys.path.insert(0, '/workspace/autoSkill/skills/autoskill/app')
from autoskill import host_bindings, host_context, workflow

identity = facts['manual_retry_policy']['before']['task_id']
with patch('autoskill.server.jobs.ensure_worker', return_value={'status': 'running', 'pid': None}):
    workflow.cancel(identity, idempotency_key='audit-cancel-completed')
binding = host_bindings.upsert({'host': 'dsh', 'host_session_id': 'audit-host', 'task_session_id': 'audit-task',
                               'workflow_id': identity, 'idempotency_key': 'audit-binding'})['binding']
direct = workflow.status(identity)
context = host_context.read('dsh', 'audit-host', binding_id=binding['id'])
result = {'data_root': facts['data_root'], 'workflow_status': direct['state'], 'host_workflow_state': context['workflow']['state'],
          'host_workflow_lifecycle': context['workflow']['lifecycle'], 'counts': context['workflow']['counts'],
          'same_lifecycle_phase_outcome': all(direct['state'][key] == context['workflow']['state'][key] for key in ('lifecycle', 'phase', 'outcome'))}
(BASE / 'host-state-consistency-result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
