"""Concurrent native outcome edits must not poison the proof cache across reads."""
import json
import os
import sys
import uuid
from pathlib import Path
from unittest.mock import patch

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
DATA = BASE / ('cache-race-data-' + uuid.uuid4().hex[:8])
DATA.mkdir(parents=True)
os.environ.update(AUTOSKILL_WORKSPACE=str(DATA), AUTOSKILL_CASE_SKILL=str(DATA / 'sheet'), AUTOSKILL_HEADED='0',
                  AUTOSKILL_BRIDGE='off', AUTOSKILL_SESSION='', AUTOSKILL_WORKFLOW_BINDING='', PYTHONDONTWRITEBYTECODE='1')
sys.path.insert(0, '/workspace/autoSkill/skills/autoskill/app')
from autoskill import db, native_assets, native_run, projects, task_report_data, task_state

project = projects.create('证据缓存并发审计', 'http://127.0.0.1:9', project_id='audit-cache')['id']
source = DATA / 'original'
source.mkdir()
(source / 'test_fixture.py').write_text('import unittest\nclass Fixture(unittest.TestCase):\n def test_ok(self): self.assertEqual(2 + 2, 4)\n')
asset = native_assets.import_asset(project, str(source), 'selenium-unittest')
run_id = native_run.enqueue(project, asset['id'])['id']
native_run.execute(run_id)
run = db.one('SELECT * FROM runs WHERE id=?', (run_id,))
row = db.one('SELECT * FROM results WHERE run_id=?', (run_id,))
before = task_state.result(row)
outcome_file = DATA / '.local/runs' / run_id / 'native/outcome.json'
original_watch_json = task_state.watch_json
calls = []


def racing_read(file):
    value = original_watch_json(file)
    if Path(file) == outcome_file:
        calls.append(True)
        if len(calls) == 1:
            changed = json.loads(outcome_file.read_bytes())
            changed['cases'][0]['status'] = 'Fail'
            outcome_file.write_text(json.dumps(changed), encoding='utf-8')
    return value


with patch.object(task_state, 'watch_json', side_effect=racing_read):
    raced = task_state.result(row)
later = [task_state.result(row) for _ in range(3)]
actual = json.loads(outcome_file.read_bytes())
direct = task_report_data._native_evidence(run, native_run._frozen(run), actual, [{**row, 'detail': json.loads(row['detail'])}])
result = {'data_root': str(DATA), 'run_id': run_id, 'before_evidence': before['evidence'], 'outcome_read_calls': len(calls),
          'direct_current_evidence_valid': direct, 'after_race_evidence': raced['evidence'],
          'later_independent_reads': [{'evidence': state['evidence'], 'outcome': state['outcome']} for state in later],
          'stored_result_status': row['status'], 'current_outcome_case_status': actual['cases'][0]['status']}
output = BASE / 'cache-race-result.json'
output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
(DATA / 'audit-result.json').write_text(output.read_text(), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
