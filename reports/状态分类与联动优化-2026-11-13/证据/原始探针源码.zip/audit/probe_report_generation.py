"""Cancel/resume report heads preserve old bytes and publish a distinct real 2-case report."""
import hashlib
import json
import os
import sys
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
DATA = BASE / ('generation-data-' + uuid.uuid4().hex[:8])
os.environ.update(AUTOSKILL_WORKSPACE=str(DATA), AUTOSKILL_CASE_SKILL=str(DATA / 'sheet'), AUTOSKILL_HEADED='0',
                  AUTOSKILL_BRIDGE='off', AUTOSKILL_SESSION='', AUTOSKILL_WORKFLOW_BINDING='')
sys.path.insert(0, '/workspace/autoSkill/skills/autoskill/app')
from autoskill import builder, db, host_bindings, host_context, projects, runner, task_reports, workflow
from autoskill.server import metrics


class Fixture(BaseHTTPRequestHandler):
    calls = 0

    def log_message(self, *args):
        return

    def do_GET(self):
        type(self).calls += 1
        body = b'{"ok":true}'
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def key():
    return uuid.uuid4().hex


def claim(identity):
    return workflow.next_task(identity, idempotency_key=key())['task']


def submit(identity, task, payload):
    return workflow.submit(identity, task['id'], lease_token=task['lease_token'], attempt_id=task['attempt_id'], idempotency_key=key(), payload=payload)


server = ThreadingHTTPServer(('127.0.0.1', 0), Fixture)
thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': .01}, daemon=True)
thread.start()
try:
    with patch.object(runner, 'spawn', return_value=None), patch('autoskill.server.jobs.ensure_worker', return_value={'status': 'running', 'pid': None}):
        project = projects.create('报告代次独立审计', f'http://127.0.0.1:{server.server_port}', project_id='audit-generation')['id']
        identity = workflow.create(project, {'title': '早期取消后完成两用例', 'sources': [{'id': 's1', 'text': '两个接口场景都应返回ok=true'}]}, idempotency_key=key())['workflow_id']
        cancelled = workflow.cancel(identity, idempotency_key=key())
        old_id = cancelled['test_report']['report_id']
        old = task_reports.finish_workflow_report(old_id)
        old_files = {name: hashlib.sha256(Path(old[name]).read_bytes()).hexdigest() for name in ('excel', 'markdown', 'bugs')}
        old_snapshot = (task_reports._folder(old_id) / 'snapshot.json').read_bytes()
        resumed = workflow.resume(identity, idempotency_key=key())
        interim = workflow.status(identity)
        new_id = interim['test_report']['report_id']
        binding = host_bindings.upsert({'host': 'dsh', 'host_session_id': 'audit-generation-host', 'task_session_id': 'audit-task',
                                       'workflow_id': identity, 'idempotency_key': 'bind'})['binding']
        host_interim = host_context.read('dsh', 'audit-generation-host', binding_id=binding['id'])
        reqs = [{'id': 'r1', 'text': '第一场景ok=true', 'source_ids': ['s1']}, {'id': 'r2', 'text': '第二场景ok=true', 'source_ids': ['s1']}]
        submit(identity, claim(identity), {'requirements': reqs})
        rules = {'status': 200, 'json_equals': {'/ok': True}}
        submit(identity, claim(identity), {'scenarios': [{'id': 'sc1', 'title': '第一场景', 'requirement_ids': ['r1'], 'oracle_ids': ['o1']},
                                                       {'id': 'sc2', 'title': '第二场景', 'requirement_ids': ['r2'], 'oracle_ids': ['o2']}],
                                          'oracles': [{'id': 'o1', 'kind': 'api', 'requirement_ids': ['r1'], 'checks': rules},
                                                      {'id': 'o2', 'kind': 'api', 'requirement_ids': ['r2'], 'checks': rules}]})
        cases = [builder.api_case('TC-API-001', '第一场景', 'GET', '/', rules), builder.api_case('TC-API-002', '第二场景', 'GET', '/', rules)]
        for index, case in enumerate(cases, 1):
            case['requirement_ids'] = ['r' + str(index)]
        submit(identity, claim(identity), {'cases': cases, 'bindings': {'sc1': ['TC-API-001'], 'sc2': ['TC-API-002']}})
        workflow.reconcile_pending()
        run_id = db.one("SELECT run_id FROM workflow_items WHERE workflow_id=? AND phase='execute'", (identity,))['run_id']
        runner.execute(run_id)
        workflow.reconcile_pending()
        submit(identity, claim(identity), {'entries': [{'id': 'k1', 'text': '两用例真实HTTP通过'}]})
        final = workflow.status(identity)
        current = task_reports.finish_workflow_report(final['test_report']['report_id'])
        frozen = json.loads((task_reports._folder(current['report_id']) / 'snapshot.json').read_bytes())
        case_states = metrics.cases(metrics.Scope([project]))['items']
        result = {'data_root': str(DATA), 'http_calls': Fixture.calls, 'old_id': old_id, 'new_id': new_id,
                  'resume_report_generation': resumed['workflow']['report_generation'], 'interim_report_status': interim['test_report']['status'],
                  'host_interim_report_id': host_interim['reports'][0]['report_id'],
                  'final_report_id': current['report_id'], 'final_report_status': current['status'], 'final_cases': current['cases'],
                  'snapshot_report_generation': frozen['report_generation'], 'snapshot_case_generations': [item['report_generation'] for item in frozen['cases']],
                  'old_artifact_bytes_unchanged': all(hashlib.sha256(Path(old[name]).read_bytes()).hexdigest() == value for name, value in old_files.items()),
                  'old_snapshot_bytes_unchanged': (task_reports._folder(old_id) / 'snapshot.json').read_bytes() == old_snapshot,
                  'workflow_state': final['state'], 'current_case_states': [{'case_id': row['case_id'], 'state': row['state']} for row in case_states]}
        output = BASE / 'report-generation-result.json'
        output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        (DATA / 'audit-result.json').write_text(output.read_text(), encoding='utf-8')
        print(json.dumps(result, ensure_ascii=False, indent=2))
finally:
    server.shutdown()
    server.server_close()
    thread.join(timeout=2)
