"""Independent real native/AI state projections and frozen-input integrity checks."""
from __future__ import annotations

import hashlib
import json
import os
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.dont_write_bytecode = True
AUDIT = Path(__file__).resolve().parent
ROOT = Path('/workspace/autoSkill')
DATA = AUDIT / ('native-data-' + uuid.uuid4().hex[:8])
DATA.mkdir(parents=True)
os.environ.update(AUTOSKILL_WORKSPACE=str(DATA), AUTOSKILL_CASE_SKILL=str(DATA / 'case-sheet'),
                  AUTOSKILL_HEADED='0', AUTOSKILL_BRIDGE='off', AUTOSKILL_SESSION='',
                  AUTOSKILL_WORKFLOW_BINDING='', PYTHONDONTWRITEBYTECODE='1')
sys.path.insert(0, str(ROOT / 'skills/autoskill/app'))

from autoskill import data_refs, db, native_assets, native_run, projects, task_state


class Fixture(BaseHTTPRequestHandler):
    calls = 0

    def log_message(self, *args):
        return

    def do_POST(self):
        self.rfile.read(int(self.headers.get('Content-Length', 0)))
        type(self).calls += 1
        time.sleep(0.03)
        payload = b'{"answer":"ok"}'
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


server = ThreadingHTTPServer(('127.0.0.1', 0), Fixture)
thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': 0.01}, daemon=True)
thread.start()
try:
    project = projects.create('审计原生状态', f'http://127.0.0.1:{server.server_port}', project_id='audit-native')['id']
    source = DATA / 'unit-fixture'
    source.mkdir()
    (source / 'test_fixture.py').write_text('import unittest\nclass Fixture(unittest.TestCase):\n def test_pass(self): self.assertEqual(2 + 2, 4)\n', encoding='utf-8')
    asset = native_assets.import_asset(project, str(source), 'selenium-unittest', asset_id='native-unit')
    run_id = native_run.enqueue(project, asset['id'])['id']
    finished = native_run.execute(run_id)
    run = db.one('SELECT * FROM runs WHERE id=?', (run_id,))
    row = db.one('SELECT * FROM results WHERE run_id=?', (run_id,))
    original = task_state.result(row)
    manifest_file = data_refs.resolve(run['input_manifest'])
    manifest = json.loads(manifest_file.read_bytes())
    manifest['parameters']['audit_changed_after_execution'] = True
    manifest_file.write_text(json.dumps(manifest, ensure_ascii=False), encoding='utf-8')
    try:
        native_run._frozen(run)
    except ValueError as error:
        canonical_rejected = str(error)
    else:
        canonical_rejected = None
    changed = task_state.result(row)

    spec = DATA / 'conversation.json'
    spec.write_text(json.dumps({'endpoint': {'url': f'http://127.0.0.1:{server.server_port}/chat'},
                                'samples': [{'id': 'single', 'question': 'please answer', 'expected': 'ok'}],
                                'performance': {'total_ms': 1}}), encoding='utf-8')
    ai_asset = native_assets.import_asset(project, str(spec), 'ai-eval', asset_id='native-ai')
    ai_id = native_run.enqueue(project, ai_asset['id'])['id']
    ai_finished = native_run.execute(ai_id)
    ai_run = db.one('SELECT * FROM runs WHERE id=?', (ai_id,))
    ai_row = db.one('SELECT * FROM results WHERE run_id=?', (ai_id,))
    ai_detail = json.loads(ai_row['detail'])
    result = {
        'source_files_sha256': {name: hashlib.sha256((ROOT / 'skills/autoskill/app/autoskill' / name).read_bytes()).hexdigest()
                                for name in ('task_state.py', 'native_run.py', 'engines/ai_eval.py')},
        'data_root': str(DATA),
        'native_input_integrity': {'run_id': run_id, 'execution_status': finished['status'], 'before': original,
                                   'canonical_frozen_rejected': canonical_rejected, 'after': changed},
        'ai_performance': {'run_id': ai_id, 'http_calls': Fixture.calls, 'execution_status': ai_finished['status'],
                           'actual_performance_assertions': [check for turn in ai_detail.get('turns', []) for check in turn.get('performance_assertions', [])],
                           'result_state': task_state.result(ai_row), 'run_state': task_state.run(ai_run)},
    }
    output = AUDIT / 'native-state-result.json'
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    (DATA / 'audit-result.json').write_text(output.read_text(), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
finally:
    server.shutdown()
    server.server_close()
    thread.join(timeout=2)
