"""An actual auth-service update must invalidate the foreground state revision."""
import json
import os
import sys
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
DATA = BASE / ('auth-data-' + uuid.uuid4().hex[:8])
os.environ.update(AUTOSKILL_WORKSPACE=str(DATA), AUTOSKILL_CASE_SKILL=str(DATA / 'sheet'),
                  AUTOSKILL_HEADED='0', AUTOSKILL_BRIDGE='off', AUTOSKILL_SESSION='', AUTOSKILL_WORKFLOW_BINDING='')
sys.path.insert(0, '/workspace/autoSkill/skills/autoskill/app')
from autoskill import builder, db, projects, runner, task_state


class Fixture(BaseHTTPRequestHandler):
    def log_message(self, *args):
        return

    def do_GET(self):
        body = b'{"ok":true}'
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)


server = ThreadingHTTPServer(('127.0.0.1', 0), Fixture)
thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': .01}, daemon=True)
thread.start()
try:
    project = projects.create('认证变更同步审计', f'http://127.0.0.1:{server.server_port}', project_id='audit-auth')['id']
    case = builder.api_case('TC-API-001', '验证接口', 'GET', '/', {'status': 200, 'json_equals': {'/ok': True}})
    projects.save_cases(project, [case])
    case = projects.case(project, case['id'])
    finished = runner.execute(runner.create(project, [case['id']])['id'])
    row = db.one('SELECT * FROM results WHERE run_id=?', (finished['id'],))
    before = task_state.current_result(project, case, row)
    previous_revision = task_state.revision()
    projects.set_auth(project, {'api_case': case['id']})
    revised_revision = task_state.revision()
    after = task_state.current_result(project, case, row)
    result = {'data_root': str(DATA), 'before': before, 'after': after,
              'revision_changed_after_auth_service': previous_revision != revised_revision,
              'previous_revision': previous_revision, 'revised_revision': revised_revision}
    output = BASE / 'auth-revision-result.json'
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    (DATA / 'audit-result.json').write_text(output.read_text(), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
finally:
    server.shutdown()
    server.server_close()
    thread.join(timeout=2)
