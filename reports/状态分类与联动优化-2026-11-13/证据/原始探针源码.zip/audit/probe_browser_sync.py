"""Independent real Chromium + live API synchronization, without fixture API responses."""
from __future__ import annotations

import concurrent.futures
import datetime
import json
import os
import socket
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.dont_write_bytecode = True
AUDIT = Path(__file__).resolve().parent
ROOT = Path('/workspace/autoSkill')
DATA = AUDIT / ('browser-data-' + uuid.uuid4().hex[:8])
os.environ.update(AUTOSKILL_WORKSPACE=str(DATA), AUTOSKILL_CASE_SKILL=str(DATA / 'case-sheet'),
                  AUTOSKILL_HEADED='0', AUTOSKILL_BRIDGE='off', AUTOSKILL_SESSION='',
                  AUTOSKILL_WORKFLOW_BINDING='', PYTHONDONTWRITEBYTECODE='1')
sys.path.insert(0, str(ROOT / 'skills/autoskill/app'))

import uvicorn
from playwright.sync_api import TimeoutError as BrowserTimeout
from playwright.sync_api import sync_playwright

from autoskill import builder, db, projects, runner
from autoskill.server.app import create_app


class Fixture(BaseHTTPRequestHandler):
    calls = 0

    def log_message(self, *args):
        return

    def do_GET(self):
        type(self).calls += 1
        payload = b'{"ok":true}'
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


fixture = ThreadingHTTPServer(('127.0.0.1', 0), Fixture)
fixture_thread = threading.Thread(target=fixture.serve_forever, kwargs={'poll_interval': 0.01}, daemon=True)
fixture_thread.start()
web_server = None
web_thread = None
try:
    project = projects.create('独立浏览器同步', f'http://127.0.0.1:{fixture.server_port}', project_id='audit-browser')['id']
    case = builder.api_case('TC-API-001', '外部短任务', 'GET', '/', {'status': 200, 'json_equals': {'/ok': True}})
    projects.save_cases(project, [case])
    with socket.socket() as binding:
        binding.bind(('127.0.0.1', 0))
        port = binding.getsockname()[1]
    web_server = uvicorn.Server(uvicorn.Config(create_app(port=port, start_worker=False), host='127.0.0.1', port=port, log_level='error'))
    web_thread = threading.Thread(target=web_server.run, daemon=True)
    web_thread.start()
    deadline = time.monotonic() + 5
    while not web_server.started and time.monotonic() < deadline:
        time.sleep(0.01)
    observations = []
    with sync_playwright() as playwright, concurrent.futures.ThreadPoolExecutor(1) as pool:
        browser = playwright.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
        page = browser.new_page()
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.goto(f'http://127.0.0.1:{port}/#/runs?range=all')
        page.wait_for_selector('#view h1')
        page.wait_for_timeout(900)
        page.evaluate("""() => {
            window.auditIdleChanges = 0;
            window.auditIdleObserver = new MutationObserver(() => { window.auditIdleChanges += 1; });
            window.auditIdleObserver.observe(document.getElementById('view'), { childList: true, subtree: true });
        }""")
        page.wait_for_timeout(700)
        idle_changes = page.evaluate('() => { window.auditIdleObserver.disconnect(); return window.auditIdleChanges; }')
        for number in range(3):
            queued = runner.create(project, [case['id']])
            future = pool.submit(runner.execute, queued['id'])
            deadline = time.monotonic() + 10
            while time.monotonic() < deadline:
                terminal = db.one('SELECT status FROM runs WHERE id=?', (queued['id'],))
                if terminal['status'] in db.FINISHED:
                    break
                page.wait_for_timeout(10)
            finished_at = time.monotonic()
            page.wait_for_function("""(runId) => {
                const checkbox = [...document.querySelectorAll('input[aria-label]')].find((node) => node.getAttribute('aria-label') === '选择运行 ' + runId);
                const text = checkbox?.closest('tr')?.textContent || '';
                return text.includes('已结束') && text.includes('综合：通过');
            }""", arg=queued['id'], timeout=3000)
            elapsed = time.monotonic() - finished_at
            finished = future.result(timeout=10)
            observations.append({'run_id': queued['id'], 'status': finished['status'], 'terminal_to_dom_ms': round(elapsed * 1000, 3)})
            page.wait_for_timeout(300)
        last = finished
        Path(last['test_report']['bugs']).unlink()
        invalidated_at = time.monotonic()
        page.wait_for_function("""(runId) => {
            const checkbox = [...document.querySelectorAll('input[aria-label]')].find((node) => node.getAttribute('aria-label') === '选择运行 ' + runId);
            return (checkbox?.closest('tr')?.textContent || '').includes('报告：失败');
        }""", arg=last['id'], timeout=3000)
        report_elapsed = time.monotonic() - invalidated_at
        page.goto(f'http://127.0.0.1:{port}/#/cases?range=all')
        search = page.get_by_role('searchbox', name='搜索用例')
        search.wait_for()
        search.fill('TC-API')
        search.focus()
        search.evaluate("""(editor) => {
            editor.setSelectionRange(1, 4);
            window.auditEditor = editor;
            window.auditMutations = [];
            new MutationObserver(() => window.auditMutations.push({ at: Date.now(),
                identity: document.activeElement === editor, value: editor.value,
                start: editor.selectionStart, end: editor.selectionEnd }))
                .observe(document.getElementById('view'), { childList: true, subtree: true });
        }""")
        focused_run = runner.create(project, [case['id']])
        future = pool.submit(runner.execute, focused_run['id'])
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            focused_terminal = db.one('SELECT status,finished_at FROM runs WHERE id=?', (focused_run['id'],))
            if focused_terminal['status'] in db.FINISHED:
                break
            page.wait_for_timeout(10)
        finished_ms = datetime.datetime.fromisoformat(focused_terminal['finished_at']).timestamp() * 1000
        page.wait_for_function("""(finished) => window.auditMutations.some((event) =>
            event.at >= finished && event.identity && event.value === 'TC-API' && event.start === 1 && event.end === 4)""",
                              arg=finished_ms, timeout=3000)
        focused_event = page.evaluate('(finished) => window.auditMutations.find((event) => event.at >= finished)', finished_ms)
        focused_elapsed = focused_event['at'] - finished_ms
        focused_result = future.result(timeout=10)
        observed_case = projects.case(project, case['id'])
        observed_case['extensions']['oracle'] = {'source': 'observation'}
        projects.save_cases(project, [observed_case])
        observed_result = runner.execute(runner.create(project, [case['id']])['id'])
        page.goto(f'http://127.0.0.1:{port}/#/runs/{observed_result["id"]}?range=all')
        retry_unverified = page.get_by_role('button', name='只重跑未通过的 1 条', exact=True)
        try:
            retry_unverified.wait_for(timeout=2000)
            unverified_retry_found = True
            unverified_retry_label = retry_unverified.inner_text()
        except BrowserTimeout:
            unverified_retry_found = False
            unverified_retry_label = page.locator('#view button').all_inner_texts()
        page.screenshot(path=str(AUDIT / 'browser-sync.png'), full_page=True)
        browser.close()
    result = {'data_root': str(DATA), 'http_calls': Fixture.calls, 'observations': observations,
              'idle_history_dom_mutations': idle_changes,
              'all_terminal_updates_under_one_second': all(row['terminal_to_dom_ms'] <= 1000 for row in observations),
              'missing_bug_to_dom_ms': round(report_elapsed * 1000, 3),
              'focused_refresh': {'status': focused_result['status'], 'terminal_to_dom_ms': round(focused_elapsed, 3),
                                  'editor_identity_draft_and_selection_preserved': bool(focused_event['identity'] and focused_event['value'] == 'TC-API'
                                                                                     and focused_event['start'] == 1 and focused_event['end'] == 4)},
              'unverified_retry': {'raw_status': observed_result['status'], 'outcome': observed_result['state']['outcome'],
                                   'found_correct_count': unverified_retry_found, 'label': unverified_retry_label},
              'page_errors': errors}
    output = AUDIT / 'browser-sync-result.json'
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    (DATA / 'audit-result.json').write_text(output.read_text(), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
finally:
    if web_server:
        web_server.should_exit = True
    if web_thread:
        web_thread.join(timeout=5)
    fixture.shutdown()
    fixture.server_close()
    fixture_thread.join(timeout=2)
