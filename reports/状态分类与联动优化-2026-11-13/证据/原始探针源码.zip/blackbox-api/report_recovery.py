#!/usr/bin/env python3
"""Remove one of our own published artifacts, then use the public retry flow."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('--round',default='baseline')
p.add_argument('--receipt-label',default='018-native-ready-status')
p.add_argument('--label',default='036-report-recovery')
a=p.parse_args()
out=ROOT/'evidence'/a.round
before=json.loads((out/(a.receipt_label+'.json')).read_text())['response']
report=before['test_report']
artifact=Path(report['excel'])
backup=out/(a.label+'-original.xlsx')
shutil.copy2(artifact,backup)
def request_count():
    path=ROOT/'evidence'/'fixture-requests.jsonl'
    return len(path.read_text().splitlines()) if path.exists() else 0
def request_paths():
    path=ROOT/'evidence'/'fixture-requests.jsonl'
    counts={}
    for line in path.read_text().splitlines() if path.exists() else []:
        value=json.loads(line)['path']
        counts[value]=counts.get(value,0)+1
    return counts
def call(suffix,args):
    label=a.label+'-'+suffix
    subprocess.run([sys.executable,str(ROOT/'bb.py'),'--round',a.round,'--label',label,'cli','--']+args,capture_output=True,check=True)
    return json.loads((out/(label+'.json')).read_text())
count_before=request_count()
paths_before=request_paths()
artifact.unlink()
try:
    missing=call('missing',['task-report',report['report_id']])
    retry=call('retry',['task-report',report['report_id'],'--retry'])
    after=call('status-after',['native','status',before['id']])
    info={'artifact_path':str(artifact),'backup_path':str(backup),'before_sha256':report['sha256'],'artifact_restored':artifact.is_file(),'missing_returncode':missing['returncode'],'missing_response':missing.get('response'),'retry_returncode':retry['returncode'],'retry_response':retry.get('response'),'fixture_requests_before':count_before,'fixture_requests_after':request_count(),'fixture_paths_before':paths_before,'fixture_paths_after':request_paths(),'run_finished_at_before':before.get('finished_at'),'run_finished_at_after':after.get('response',{}).get('finished_at'),'input_hash_before':before.get('input_hash'),'input_hash_after':after.get('response',{}).get('input_hash'),'outcome_hash_before':before.get('report',{}).get('sha256'),'outcome_hash_after':after.get('response',{}).get('report',{}).get('sha256')}
    if artifact.is_file():
        info['after_sha256']=hashlib.sha256(artifact.read_bytes()).hexdigest()
    (out/(a.label+'-summary.json')).write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(info,ensure_ascii=False))
finally:
    if not artifact.is_file():
        shutil.copy2(backup,artifact)
