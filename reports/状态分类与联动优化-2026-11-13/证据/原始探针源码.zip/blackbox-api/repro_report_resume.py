#!/usr/bin/env python3
"""Minimal public reproduction of a resumed cycle retaining its empty report."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time
import zipfile

ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('--round',required=True)
a=p.parse_args()
workspace=ROOT/('workspace-'+a.round)
out=ROOT/'evidence'/a.round
if workspace.exists():
    raise SystemExit('Refusing to overwrite '+str(workspace))
out.mkdir(parents=True,exist_ok=True)
def cli(label,*args):
    subprocess.run([sys.executable,str(ROOT/'bb.py'),'--round',a.round,'--label',label,'cli','--',*args],capture_output=True,check=True)
    rec=json.loads((out/(label+'.json')).read_text())
    if rec['returncode']:
        raise RuntimeError(json.dumps(rec,ensure_ascii=False))
    return rec['response']
def report_files(report,label,copy=True):
    items=[]
    for kind,hfield,sfield in [('excel','sha256','size'),('markdown','markdown_sha256','markdown_size'),('bugs','bugs_sha256','bugs_size')]:
        value=report.get(kind)
        item={'kind':kind,'path':value,'exists':False}
        if value:
            path=Path(value)
            if not path.resolve().is_relative_to(workspace.resolve()):
                item['error']='Returned output path is outside this isolated workspace; not read.'
            elif path.is_file():
                data=path.read_bytes()
                item.update(exists=True,size=len(data),sha256=hashlib.sha256(data).hexdigest(),hash_matches=hashlib.sha256(data).hexdigest()==report.get(hfield),size_matches=len(data)==report.get(sfield))
                if copy:
                    target=out/(label+'-'+kind+path.suffix)
                    shutil.copy2(path,target)
                    item['snapshot']=str(target)
        items.append(item)
    (out/(label+'.json')).write_text(json.dumps(items,ensure_ascii=False,indent=2)+'\n')
    return items
cli('001-project','project','create','--id','bb-api','--name','Blackbox report resume','--url','http://127.0.0.1:18882')
wf=cli('002-start','workflow','start','bb-api','--file',str(ROOT/'inputs'/'workflow-v1.json'),'--idempotency-key','report-repro-start')['workflow_id']
cli('003-cancel','workflow','cancel',wf,'--idempotency-key','report-repro-cancel')
for i in range(60):
    cancelled=cli('004-cancelled-status-'+str(i).zfill(2),'workflow','status',wf,'--all')
    if cancelled.get('test_report',{}).get('status') in ('ready','failed'):
        break
    time.sleep(.25)
cancelled_files=report_files(cancelled.get('test_report',{}),'004-cancelled-files')
cli('005-resume','workflow','resume',wf,'--idempotency-key','report-repro-resume')
payload=json.loads((ROOT/'inputs'/'materialize-v2.json').read_text())
for case in payload['cases']:
    case['source_ref']='spec-v1'
    case['source']='Independent local fixture requirement spec-v1'
mat=out/'006-materialize.json'
mat.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
subprocess.run([sys.executable,str(ROOT/'workflow_cycle.py'),'--round',a.round,'--workflow',wf,'--label','007-complete','--requirements',str(ROOT/'inputs'/'requirements-v1.json'),'--materialize',str(mat)],capture_output=True,check=True)
cycle=json.loads((out/'007-complete-summary.json').read_text())
report=cycle.get('final',{}).get('test_report',{})
correct=report.get('cases')==2 and report.get('summary_counts',{}).get('Pass')==1 and report.get('summary_counts',{}).get('Fail')==1 and report.get('run_ids')==[cycle.get('execution',{}).get('run_id')]
completed_files=report_files(report,'009-completed-files')
old_files_after=report_files(cancelled.get('test_report',{}),'010-cancelled-files-after',copy=False)
unchanged=all(before.get('exists') and after.get('exists') and before.get('sha256')==after.get('sha256') and before.get('size')==after.get('size') for before,after in zip(cancelled_files,old_files_after))
content={}
if report.get('excel') and Path(report['excel']).is_file():
    with zipfile.ZipFile(report['excel']) as archive:
        xml='\n'.join(archive.read(name).decode(errors='replace') for name in archive.namelist() if name.endswith('.xml'))
    content['excel_has_actual_run']=cycle.get('execution',{}).get('run_id','MISSING-RUN') in xml
    content['excel_has_both_original_cases']=all(case in xml for case in ['TC-API-BB-READY','TC-API-BB-WRONG'])
    content['excel_preserves_ready_wrong']=all(value in xml for value in ['ready','wrong'])
if report.get('markdown') and Path(report['markdown']).is_file():
    text=Path(report['markdown']).read_text()
    content['markdown_has_two_case_summary']='逻辑用例 2 条' in text
if report.get('bugs') and Path(report['bugs']).is_file():
    text=Path(report['bugs']).read_text()
    content['bugs_preserves_failure']=all(value in text for value in ['TC-API-BB-WRONG','ready','wrong'])
file_checks=all(item.get('hash_matches') and item.get('size_matches') for item in completed_files)
result={'round':a.round,'workflow_id':wf,'before_resume_report':cancelled.get('test_report'),'cancelled_files_before':cancelled_files,'cancelled_files_after':old_files_after,'cancelled_files_unchanged':unchanged,'completed_state':cycle.get('final',{}).get('state'),'actual_execution':cycle.get('execution'),'completed_report':report,'completed_file_checks_pass':file_checks,'completed_file_content_checks':content,'report_matches_completed_execution':correct,'error':cycle.get('error')}
(out/'008-report-comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'round':a.round,'workflow_id':wf,'report_matches_completed_execution':correct,'cancelled_files_unchanged':unchanged,'completed_file_checks_pass':file_checks,'completed_file_content_checks':content,'before_resume_cases':cancelled.get('test_report',{}).get('cases'),'completed_cases':report.get('cases'),'actual_execution':cycle.get('execution'),'error':cycle.get('error')},ensure_ascii=False))
