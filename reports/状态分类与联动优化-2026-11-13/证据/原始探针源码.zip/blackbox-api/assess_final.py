#!/usr/bin/env python3
"""Assess fixed acceptance criteria using only our captured public responses."""
import datetime as dt
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'evidence'/'final-retest'
def read(label):
    return json.loads((OUT/(label+'.json')).read_text())
def response(label):
    return read(label)['response']
def native(prefix):
    paths=list(OUT.glob(prefix+'-status-*.json'))+list(OUT.glob(prefix+'-report-wait-*.json'))
    values=[json.loads(p.read_text()) for p in paths]
    return max(values,key=lambda r:r['ended_at'])['response']
items=[]
def check(id,title,passed,actual,evidence):
    items.append({'id':id,'title':title,'verdict':'Pass' if passed else 'Fail','actual':actual,'evidence':evidence})

ready=native('008-native-ready')
failure=native('009-native-fail')
retry=native('010-native-fail-retry')
old=response('011-native-old-fail')
cancel=response('013-native-cancel-stable')
state_contract=json.loads((OUT/'public-documents.json').read_text())[0]
workspace=str(ROOT/'workspace-final-retest')
initial=response('002-data-status')
check('BB01','公开入口和隔离workspace',initial['root']==workspace and not initial['initialized'],{'workspace':initial['root'],'initialized_before_create':initial['initialized'],'python_cli_help_returncode':read('001-cli-help')['returncode']},['001-cli-help','002-data-status'])
context=response('004-context-initial')
check('BB02','创建项目并读回空上下文',context['project']['id']=='bb-api' and context['page']['cases']['total']==0,{'project_id':context['project']['id'],'initial_cases':context['page']['cases']['total']},['003-project-create','004-context-initial'])
cases=response('029-cases-after-execute')
ids={c['id'] for c in cases['cases']}
check('BB03','保存独立通过与失败用例',ids=={'TC-API-BB-READY','TC-API-BB-WRONG'} and all(c['replayable'] for c in cases['cases']),{'ids':sorted(ids),'count':cases['page']['total'],'independent_expected':'JSON /status must equal ready for both controls'},['021-submit-materialize','029-cases-after-execute','materialize-v1'])
s=ready['state']
check('BB04','通过用例的执行阶段与结果分项',s['lifecycle']=='completed' and s['checks']['business']=='pass' and s['checks']['performance']=='not_applicable' and s['evidence']=='valid' and s['report']=='ready' and s['delivery']=='not_applicable',{'state':s,'legacy_status':ready['status'],'authority':'public state-contract.md defines state as canonical projection'},['008-native-ready-summary','008-native-ready-report-wait-0','public-state-contract.md'])
s=failure['state']; outcome=failure['outcome']
check('BB05','业务失败不等于工具执行失败',s['lifecycle']=='completed' and s['checks']['business']=='fail' and outcome['execution_status']=='completed' and outcome['process']['state']=='completed' and failure['test_report']['bugs_counts']['business']==1 and failure['test_report']['bugs_counts']['execution']==0,{'state':s,'execution_status':outcome['execution_status'],'process_state':outcome['process']['state'],'bugs_counts':failure['test_report']['bugs_counts']},['009-native-fail-summary','028-workflow-diagnose-next'])
api=read('046-api-assessment')
check('BB06','在线API变化1秒内和取消终态',cancel['state']['lifecycle']=='cancelled' and cancel['state']['checks']['business']=='unverified' and api['earliest_running_api_delay_seconds']<1 and api['terminal_api_delay_seconds']<1,{'cancel_state':cancel['state'],'running_api_delay_seconds':api['earliest_running_api_delay_seconds'],'terminal_api_delay_seconds':api['terminal_api_delay_seconds'],'revision_http_samples':api['revision_http_samples'],'revision_http_max_seconds':api['revision_http_max_seconds'],'scope':'HTTP observation only; browser paint/focus/scroll not measured'},['012-native-cancel-summary','013-native-cancel-stable','044-api-observe-summary','046-api-assessment'])
keys=['input_hash','finished_at']
same=all(failure[k]==old[k] for k in keys) and failure['report']['sha256']==old['report']['sha256'] and failure['test_report']['source_hash']==old['test_report']['source_hash']
check('BB07','重试与旧失败运行隔离',retry['id']!=failure['id'] and same and old['state']['checks']['business']=='fail',{'first_run':failure['id'],'retry_run':retry['id'],'old_input_hash_unchanged':failure['input_hash']==old['input_hash'],'old_finished_at_unchanged':failure['finished_at']==old['finished_at'],'old_outcome_hash_unchanged':failure['report']['sha256']==old['report']['sha256']},['009-native-fail-summary','010-native-fail-retry-summary','011-native-old-fail'])
final=response('039-workflow-complete-status')
execution=response('034-workflow-diagnose-next-resumed')['task']['context']['execution']
check('BB08','工作流真实执行与闭环',final['complete'] and final['conclusion']=='violated' and final['state']['lifecycle']=='completed' and {r['business_status'] for r in execution['results']}=={'Pass','Fail'}, {'complete':final['complete'],'conclusion':final['conclusion'],'state':final['state'],'actual_execution':execution},['022-workflow-execute-next','028-workflow-diagnose-next','035-workflow-submit-diagnosis','037-workflow-submit-knowledge','039-workflow-complete-status'])
cancelled=response('031-workflow-cancel-after-failure')['workflow']
resumed=response('033-workflow-resume-after-failure')['workflow']
before_exec=response('028-workflow-diagnose-next')['task']['context']['execution']
begin=dt.datetime.fromisoformat(read('031-workflow-cancel-after-failure')['started_at'])
end=dt.datetime.fromisoformat(read('034-workflow-diagnose-next-resumed')['ended_at'])
fixture=[json.loads(line) for line in (ROOT/'evidence'/'fixture-requests.jsonl').read_text().splitlines()]
during=[r for r in fixture if begin<=dt.datetime.fromisoformat(r['at'])<=end]
check('BB09','已有真实失败后的取消和恢复',cancelled['state']['lifecycle']=='cancelled' and cancelled['state']['checks']['business']=='fail' and resumed['state']['checks']['business']=='fail' and before_exec==execution and not during,{'cancel_state':cancelled['state'],'resumed_state':resumed['state'],'same_execution_receipt':before_exec==execution,'new_fixture_completions_during_cancel_resume':during},['028-workflow-diagnose-next','031-workflow-cancel-after-failure','032-workflow-status-cancelled','033-workflow-resume-after-failure','034-workflow-diagnose-next-resumed'])
new=response('041-workflow-current-cycle')
cycle2=read('047-cycle2-summary')
old_report=response('048-old-report-after-new-cycle-complete')
filters=api['cycle_filters']
isolated=filters['runs-current']['old_workflow_run_entries']==0 and filters['runs-all']['old_workflow_run_entries']==1 and filters['results-current']['old_workflow_run_entries']==0 and filters['results-all']['old_workflow_run_entries']==2
check('BB10','新周期不借用旧验证并保留历史',new['state']['outcome']=='pending' and new['state']['checks']['business']=='unverified' and new['state']['report']=='not_generated' and new['total']==1 and isolated and cycle2['execution']['run_id']!=execution['run_id'] and cycle2['final']['test_report']['run_ids']==[cycle2['execution']['run_id']] and old_report['sha256']==final['test_report']['sha256'],{'prior_cycle':final['cycle_id'],'new_cycle':new['cycle_id'],'new_cycle_initial_state':new['state'],'new_cycle_actual_run':cycle2['execution']['run_id'],'cycle_filter_counts':filters,'old_report_hash_unchanged':old_report['sha256']==final['test_report']['sha256']},['040-workflow-revise-cycle2','041-workflow-current-cycle','042-workflow-all-cycles','046-api-assessment','047-cycle2-summary','048-old-report-after-new-cycle-complete'])
native_files=read('014-report-files')
cycle_files=read('050-cycle2-report-files')[:3]
http_meta=response('016-http-metadata')
http_ok=all(read('016-http-'+k)['http_status']==200 and read('016-http-'+k)['response_artifact']['sha256']==http_meta[h] for k,h in [('excel','sha256'),('markdown','markdown_sha256'),('bugs','bugs_sha256')])
first_report=final['test_report']
correct_report=first_report['summary_cases']==2 and first_report['summary_counts']['Pass']==1 and first_report['summary_counts']['Fail']==1 and first_report['run_ids']==[execution['run_id']]
check('BB11','任务报告与当前真实周期一致且三文件有效',all(f['hash_matches'] and f['size_matches'] for f in native_files+cycle_files) and http_ok and correct_report,{'native_three_files_valid':all(f['hash_matches'] and f['size_matches'] for f in native_files),'http_download_hashes_match':http_ok,'second_cycle_three_files_valid':all(f['hash_matches'] and f['size_matches'] for f in cycle_files),'first_cycle_actual_results':{'Pass':1,'Fail':1,'run_id':execution['run_id']},'first_cycle_returned_report':{'status':first_report['status'],'generation':first_report['generation'],'cases':first_report['cases'],'run_ids':first_report['run_ids'],'summary_counts':first_report['summary_counts']},'failure':'Early cancelled empty snapshot remains the completed first cycle ready report.' if not correct_report else None},['014-report-files','016-http-metadata','016-http-excel','016-http-markdown','016-http-bugs','018-workflow-cancel','019-workflow-resume','039-workflow-complete-status','045-stale-workflow-files','050-cycle2-report-files'])
recovery=read('015-report-recovery-summary')
paths_before=recovery['fixture_paths_before']; paths_after=recovery['fixture_paths_after']
no_probe_replay=all(paths_before.get(p,0)==paths_after.get(p,0) for p in ['/api/value?value=ready','/api/value?value=wrong'])
same_frozen=all(recovery[k+'_before']==recovery[k+'_after'] for k in ['run_finished_at','input_hash','outcome_hash'])
check('BB12','报告失败需手动重试且不重跑',recovery['missing_returncode']==2 and recovery['missing_response']['status']=='failed' and recovery['retry_response']['status']=='ready' and recovery['artifact_restored'] and no_probe_replay and same_frozen,{'missing_status':recovery['missing_response']['status'],'retry_status':recovery['retry_response']['status'],'same_frozen_run':same_frozen,'ready_wrong_request_counts_unchanged':no_probe_replay,'all_paths_before':paths_before,'all_paths_after':paths_after,'late_slow_completion':'Previously cancelled fixture request completed its server sleep during export recovery; ready/wrong request counts and frozen run remain unchanged.'},['015-report-recovery-missing','015-report-recovery-retry','015-report-recovery-status-after','015-report-recovery-summary'])
counts={k:sum(item['verdict']==k for item in items) for k in ['Pass','Fail','Blocked']}
cli_lags={prefix:read(prefix+'-summary')['terminal_observation_delay_seconds'] for prefix in ['008-native-ready','009-native-fail','010-native-fail-retry','012-native-cancel']}
result={'round':'final-retest','scope':'Independent public CLI and HTTP API blackbox','workspace':workspace,'session':'blackbox-api-final-retest','counts':counts,'items':items,'timing':{'cli_terminal_observation_seconds':cli_lags,'http_running_observation_seconds':api['earliest_running_api_delay_seconds'],'http_terminal_observation_seconds':api['terminal_api_delay_seconds'],'revision_http_max_seconds':api['revision_http_max_seconds'],'concurrency_note':'Parent reported full Python regression running concurrently; no other Agent outputs were read.'},'boundaries':['Browser recording remains unavailable because bundled agent-browser is missing; canonical cases were saved and executed through the public workflow schema.','Frontend paint, focus and scroll were outside this CLI/API test scope.','No implementation, internal tests, other Agent results, credentials or model configuration were read.'],'state_contract':state_contract}
(OUT/'051-acceptance-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'counts':counts,'verdicts':[{k:i[k] for k in ['id','title','verdict']} for i in items],'timing':result['timing']},ensure_ascii=False,indent=2))
