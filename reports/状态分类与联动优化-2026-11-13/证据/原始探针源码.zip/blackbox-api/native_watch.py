#!/usr/bin/env python3
"""Observe public native status at < 1s query intervals and optionally cancel."""
import argparse
import datetime as dt
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('--round',default='baseline')
p.add_argument('--label',required=True)
p.add_argument('--asset',required=True)
p.add_argument('--cancel',action='store_true')
a=p.parse_args()
out=ROOT/'evidence'/a.round
def call(suffix,args):
    label=a.label+'-'+suffix
    subprocess.run([sys.executable,str(ROOT/'bb.py'),'--round',a.round,'--label',label,'cli','--']+args,capture_output=True,check=True)
    return json.loads((out/(label+'.json')).read_text())
start=time.monotonic()
initial=call('run',['native','run','bb-api',a.asset])
run=initial['response']['id']
observations=[]
cancelled=False
for i in range(120):
    rec=call('status-'+str(i).zfill(3),['native','status',run])
    r=rec.get('response',{})
    observations.append({'observed_at':rec['ended_at'],'elapsed_seconds':time.monotonic()-start,'command_seconds':rec['elapsed_seconds'],'status':r.get('status'),'started_at':r.get('started_at'),'finished_at':r.get('finished_at'),'outcome_execution_status':r.get('outcome',{}).get('execution_status'),'test_report_status':r.get('test_report',{}).get('status')})
    if a.cancel and not cancelled and r.get('status') in ('Running','running'):
        cancellation=call('cancel',['native','cancel',run])
        cancelled=True
        observations.append({'operation':'cancel','observed_at':cancellation['ended_at'],'elapsed_seconds':time.monotonic()-start,'response':cancellation.get('response')})
    if r.get('finished_at') or r.get('status') in ('Pass','Fail','Blocked','Cancelled','Completed','completed','cancelled'):
        final=r
        break
    time.sleep(.1)
else:
    final=r
summary={'run_id':run,'initial_status':initial['response'].get('status'),'cancel_requested':cancelled,'observations':observations,'final_status':final.get('status'),'final_outcome':final.get('outcome'),'test_report':final.get('test_report')}
if final.get('finished_at'):
    summary['terminal_observation_delay_seconds']=(dt.datetime.fromisoformat(observations[-1]['observed_at'])-dt.datetime.fromisoformat(final['finished_at'])).total_seconds()
(out/(a.label+'-summary.json')).write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('final_outcome','test_report')},ensure_ascii=False))
