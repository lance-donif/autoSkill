import json
import unittest
import urllib.request

BASE = 'http://127.0.0.1:18882'

def status(path):
    with urllib.request.urlopen(BASE + path, timeout=30) as response:
        return json.load(response)['status']

class Ready(unittest.TestCase):
    def test_ready(self):
        self.assertEqual(status('/api/value?value=ready'), 'ready')

class BusinessFailure(unittest.TestCase):
    def test_wrong_value(self):
        self.assertEqual(status('/api/value?value=wrong'), 'ready')

class Slow(unittest.TestCase):
    def test_slow(self):
        self.assertEqual(status('/api/slow?ms=12000'), 'ready')

if __name__ == '__main__':
    unittest.main()
