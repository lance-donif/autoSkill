#!/usr/bin/env python3
"""Repeat the fixed public blackbox tasks in a fresh workspace.

Stops at the next host workflow task so its public payload_schema can be
reviewed before any business diagnosis is submitted. Never imports product
modules, edits result records, or reads another workspace.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import urllib.request

ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('--round',default='retest')
p.add_argument('--port',type=int,default=18883)
a=p.parse_args()
workspace=ROOT/('workspace-'+a.round)
out=ROOT/'evidence'/a.round
if workspace.exists():
    raise SystemExit('Refusing to reuse an existing round workspace: '+str(workspace))
out.mkdir(parents=True,exist_ok=True)
steps=[]

def cli(label,*args):
    subprocess.run([sys.executable,str(ROOT/'bb.py'),'--round',a.round,'--label',label,'cli','--',*args],capture_output=True,check=True)
    rec=json.loads((out/(label+'.json')).read_text())
    r=rec.get('response',{})
    steps.append({'label':label,'returncode':rec.get('returncode'),'status':r.get('status'),'state':r.get('state'),'error':r.get('error')})
    print(json.dumps(steps[-1],ensure_ascii=False),flush=True)
    return rec

def submit(task,label,payload):
    return cli(label,'workflow','submit',task['workflow_id'],task['item_id'],'--lease-token',task['lease_token'],'--attempt-id',task['attempt_id'],'--idempotency-key',label,'--file',str(payload))

def native(label,asset,cancel=False):
    subprocess.run([sys.executable,str(ROOT/'native_watch.py'),'--round',a.round,'--label',label,'--asset',asset]+(['--cancel'] if cancel else []),capture_output=True,check=True)
    summary=json.loads((out/(label+'-summary.json')).read_text())
    status_labels=sorted(out.glob(label+'-status-*.json'))
    rec=json.loads(status_labels[-1].read_text())
    r=rec['response']
    for i in range(15):
        if r.get('test_report',{}).get('status')=='ready':
            break
        rec=cli(label+'-report-wait-'+str(i),'native','status',r['id'])
        r=rec['response']
        time.sleep(.1)
    steps.append({'label':label,'run_id':r['id'],'state':r.get('state'),'status':r.get('status'),'terminal_observation_delay_seconds':summary.get('terminal_observation_delay_seconds')})
    print(json.dumps(steps[-1],ensure_ascii=False),flush=True)
    return rec, rec['label']

cli('001-cli-help','--help')
cli('002-data-status','data','status')
cli('003-project-create','project','create','--id','bb-api','--name','Blackbox API state','--url','http://127.0.0.1:18882')
cli('004-context-initial','context','bb-api')
cli('005-record-start','record','start','bb-api','--headless')
cli('006-engine-probe','engine','probe','selenium-unittest')
for asset in ('ready','fail','slow'):
    cli('007-import-'+asset,'asset','import','bb-api','--file',str(ROOT/'inputs'/('asset-'+asset+'.json')))
ready,ready_label=native('008-native-ready','bb-ready')
failure,_=native('009-native-fail','bb-fail')
retry,_=native('010-native-fail-retry','bb-fail')
old=cli('011-native-old-fail','native','status',failure['response']['id'])
cancel,_=native('012-native-cancel','bb-slow',True)
stable=cli('013-native-cancel-stable','native','status',cancel['response']['id'])

files=[]
for field,hashfield,sizefield in (('excel','sha256','size'),('markdown','markdown_sha256','markdown_size'),('bugs','bugs_sha256','bugs_size')):
    tr=ready['response']['test_report']
    path=Path(tr[field]); data=path.read_bytes()
    files.append({'field':field,'path':str(path),'exists':True,'size':len(data),'size_matches':len(data)==tr[sizefield],'sha256':hashlib.sha256(data).hexdigest(),'hash_matches':hashlib.sha256(data).hexdigest()==tr[hashfield]})
(out/'014-report-files.json').write_text(json.dumps(files,ensure_ascii=False,indent=2)+'\n')
subprocess.run([sys.executable,str(ROOT/'report_recovery.py'),'--round',a.round,'--receipt-label',ready_label,'--label','015-report-recovery'],capture_output=True,check=True)

env=os.environ.copy()
env.update(PYTHONPATH='/workspace/autoSkill/skills/autoskill/app',AUTOSKILL_WORKSPACE=str(workspace),AUTOSKILL_HEADED='0',AUTOSKILL_SESSION='blackbox-api-'+a.round)
dashboard_log=(out/'dashboard.log').open('w')
dashboard=subprocess.Popen([sys.executable,'-m','autoskill','dashboard','--port',str(a.port),'--headless'],env=env,stdout=dashboard_log,stderr=subprocess.STDOUT)
try:
    for i in range(40):
        try:
            with urllib.request.urlopen('http://127.0.0.1:'+str(a.port)+'/api/task-reports/'+ready['response']['test_report']['report_id'],timeout=1):
                break
        except Exception:
            time.sleep(.1)
    for suffix in ('','/excel','/markdown','/bugs'):
        name='metadata' if not suffix else suffix[1:]
        subprocess.run([sys.executable,str(ROOT/'bb.py'),'--round',a.round,'--label','016-http-'+name,'http','http://127.0.0.1:'+str(a.port)+'/api/task-reports/'+ready['response']['test_report']['report_id']+suffix],capture_output=True,check=True)
finally:
    dashboard.terminate()
    dashboard.wait(timeout=15)
    dashboard_log.close()

wf=cli('017-workflow-start','workflow','start','bb-api','--file',str(ROOT/'inputs'/'workflow-v1.json'),'--idempotency-key','bb-workflow-v1')['response']['workflow_id']
cli('018-workflow-cancel','workflow','cancel',wf,'--idempotency-key','bb-cancel-v1')
cli('019-workflow-resume','workflow','resume',wf,'--idempotency-key','bb-resume-v1')
mat=json.loads((ROOT/'inputs'/'materialize-v2.json').read_text())
for case in mat['cases']:
    case['source_ref']='spec-v1'
    case['source']='Independent local fixture requirement spec-v1'
matpath=out/'materialize-v1.json'
matpath.write_text(json.dumps(mat,ensure_ascii=False,indent=2)+'\n')
for i,(phase,payload) in enumerate((('requirements',ROOT/'inputs'/'requirements-v1.json'),('design',ROOT/'inputs'/'design-v1.json'),('materialize',matpath))):
    claim=cli('020-workflow-next-'+str(i),'workflow','next',wf,'--idempotency-key','bb-next-v1-'+str(i))
    task=claim.get('response',{}).get('task')
    if not task or task.get('phase')!=phase:
        break
    submitted=submit(task,'021-submit-'+phase,payload)
    if submitted['returncode']:
        break
else:
    cli('022-workflow-execute-next','workflow','next',wf,'--idempotency-key','bb-next-v1-execute')
cli('023-cases','cases','bb-api','--all')
cli('024-workflow-requirements','workflow','read',wf,'--kind','requirements')
cli('025-workflow-materialization','workflow','read',wf,'--kind','materialization')
cli('026-workflow-status','workflow','status',wf,'--all')
(out/'suite-summary.json').write_text(json.dumps({'round':a.round,'workspace':str(workspace),'workflow_id':wf,'ready_run_id':ready['response']['id'],'fail_run_id':failure['response']['id'],'retry_run_id':retry['response']['id'],'cancel_run_id':cancel['response']['id'],'steps':steps},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'round':a.round,'workflow_id':wf,'next':'Inspect the public next/status receipt and continue diagnosis or recovery using that payload_schema.'}),flush=True)
