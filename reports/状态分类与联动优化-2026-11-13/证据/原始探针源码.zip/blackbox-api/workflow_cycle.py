#!/usr/bin/env python3
"""Continue a public workflow cycle from requirements to factual diagnosis."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('--round',default='final-retest')
p.add_argument('--workflow',required=True)
p.add_argument('--label',default='047-cycle2')
p.add_argument('--requirements',required=True)
p.add_argument('--materialize',required=True)
a=p.parse_args()
out=ROOT/'evidence'/a.round
receipts=[]
def call(suffix,*args):
    label=a.label+'-'+suffix
    subprocess.run([sys.executable,str(ROOT/'bb.py'),'--round',a.round,'--label',label,'cli','--',*args],capture_output=True,check=True)
    value=json.loads((out/(label+'.json')).read_text())
    receipts.append(label)
    if value.get('returncode'):
        raise RuntimeError(json.dumps({'label':label,'response':value.get('response')},ensure_ascii=False))
    return value['response']
def claim(suffix):
    return call(suffix,'workflow','next',a.workflow,'--idempotency-key',a.label+'-'+suffix)
def submit(task,suffix,file):
    return call(suffix,'workflow','submit',a.workflow,task['item_id'],'--lease-token',task['lease_token'],'--attempt-id',task['attempt_id'],'--idempotency-key',a.label+'-'+suffix,'--file',str(file))

summary={'workflow_id':a.workflow,'label':a.label,'receipts':receipts}
try:
    for phase,file in [('requirements',Path(a.requirements)),('design',ROOT/'inputs'/'design-v1.json'),('materialize',Path(a.materialize))]:
        response=claim('next-'+phase)
        task=response.get('task')
        if not task or task['phase']!=phase:
            raise RuntimeError('Unexpected public task: '+json.dumps(response,ensure_ascii=False))
        submit(task,'submit-'+phase,file)
    response=claim('next-execute')
    for i in range(60):
        status=call('execution-status-'+str(i).zfill(2),'workflow','status',a.workflow,'--all')
        if status.get('counts',{}).get('ready',0):
            break
        if status.get('complete'):
            break
        time.sleep(.25)
    response=claim('next-diagnose')
    task=response.get('task')
    if not task or task['phase']!='diagnose':
        raise RuntimeError('Expected factual diagnosis task: '+json.dumps(response,ensure_ascii=False))
    execution=task.get('context',{}).get('execution',{})
    results=execution.get('results',[])
    failures=[r for r in results if r.get('case_id')=='TC-API-BB-WRONG' and r.get('business_status')=='Fail']
    passes=[r for r in results if r.get('case_id')=='TC-API-BB-READY' and r.get('business_status')=='Pass']
    if not failures or not passes or '实际 wrong' not in failures[0].get('reason',''):
        raise RuntimeError('Actual fixture results do not match independent expected control; preserving response for review: '+json.dumps(execution,ensure_ascii=False))
    refs=[execution['run_id']]+['result:'+str(r['result_id']) for r in results]
    diagnosis={'disposition':'business_defect','reason':'Actual ready probe passed. Deliberate wrong probe completed but returned wrong against independent expected ready. Preserve requirement BB-READY and this controlled fixture business failure; do not classify it as an autoSkill execution crash.','evidence_refs':refs}
    diagnosis_path=out/(a.label+'-diagnosis-payload.json')
    diagnosis_path.write_text(json.dumps(diagnosis,ensure_ascii=False,indent=2)+'\n')
    submit(task,'submit-diagnosis',diagnosis_path)
    response=claim('next-knowledge')
    task=response.get('task')
    if not task or task['phase']!='knowledge':
        raise RuntimeError('Expected knowledge task: '+json.dumps(response,ensure_ascii=False))
    knowledge={'entries':[{'id':a.label+'-verified-facts','text':'This cycle actually executed '+execution['run_id']+' with unchanged independent ready oracle. Ready probe passed and deliberate wrong probe failed. Previous cycle evidence cannot replace this new run.','evidence_refs':refs}]}
    knowledge_path=out/(a.label+'-knowledge-payload.json')
    knowledge_path.write_text(json.dumps(knowledge,ensure_ascii=False,indent=2)+'\n')
    submit(task,'submit-knowledge',knowledge_path)
    response=claim('next-finish')
    for i in range(80):
        final=call('final-status-'+str(i).zfill(2),'workflow','status',a.workflow,'--all')
        if final.get('test_report',{}).get('status') in ('ready','failed'):
            break
        time.sleep(.25)
    summary.update(cycle_id=final.get('cycle_id'),execution=execution,final=final)
except Exception as e:
    summary['error']=str(e)
finally:
    (out/(a.label+'-summary.json')).write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'label':a.label,'cycle_id':summary.get('cycle_id'),'execution':summary.get('execution'),'error':summary.get('error'),'final_state':summary.get('final',{}).get('state'),'final_test_report':summary.get('final',{}).get('test_report')},ensure_ascii=False))
