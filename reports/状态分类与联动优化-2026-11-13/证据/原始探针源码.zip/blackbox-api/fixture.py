#!/usr/bin/env python3
"""Deterministic local business fixture. Only this process writes its log."""
import argparse
import datetime as dt
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import threading
import time
from urllib.parse import parse_qs, urlsplit

ROOT = Path(__file__).resolve().parent
LOCK = threading.Lock()
HTML = b'''<!doctype html><html><head><meta charset="utf-8"><title>Blackbox state fixture</title></head><body>
<h1>State fixture</h1><p data-testid="status">idle</p>
<button data-testid="ready" onclick="load('/api/value?value=ready')">Ready</button>
<button data-testid="wrong" onclick="load('/api/value?value=wrong')">Wrong</button>
<button data-testid="slow" onclick="load('/api/slow?ms=6000')">Slow</button>
<script>async function load(url){document.querySelector('[data-testid=status]').textContent='loading';let r=await fetch(url);let v=await r.json();document.querySelector('[data-testid=status]').textContent=v.status;}</script>
</body></html>'''

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        start = time.monotonic()
        u = urlsplit(self.path)
        q = parse_qs(u.query)
        if u.path == '/':
            body, ct, status = HTML, 'text/html; charset=utf-8', 200
        elif u.path == '/api/value':
            body, ct, status = json.dumps({'status':q.get('value',['ready'])[0]}).encode(), 'application/json', 200
        elif u.path == '/api/slow':
            time.sleep(int(q.get('ms',['6000'])[0]) / 1000)
            body, ct, status = b'{"status":"ready"}', 'application/json', 200
        else:
            body, ct, status = b'{"error":"not found"}', 'application/json', 404
        self.send_response(status)
        self.send_header('Content-Type',ct)
        self.send_header('Content-Length',str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass
        with LOCK:
            with (ROOT / 'evidence' / 'fixture-requests.jsonl').open('a') as f:
                f.write(json.dumps({'at':dt.datetime.now(dt.timezone.utc).isoformat(),'path':self.path,'status':status,'elapsed_seconds':time.monotonic()-start})+'\n')
    def log_message(self, *_):
        pass

if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--port',type=int,default=18782)
    a=p.parse_args()
    print(json.dumps({'fixture':'ready','port':a.port}),flush=True)
    ThreadingHTTPServer(('127.0.0.1',a.port),Handler).serve_forever()
