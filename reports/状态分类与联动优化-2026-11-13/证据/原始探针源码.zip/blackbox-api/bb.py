#!/usr/bin/env python3
"""Public CLI/HTTP capture helper; imports no product Python modules."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parent

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--round', default='baseline')
    p.add_argument('--label', required=True)
    sub = p.add_subparsers(dest='kind', required=True)
    cp = sub.add_parser('cli')
    cp.add_argument('args', nargs=argparse.REMAINDER)
    hp = sub.add_parser('http')
    hp.add_argument('url')
    hp.add_argument('--method', default='GET')
    hp.add_argument('--body')
    fp = sub.add_parser('files')
    fp.add_argument('paths', nargs='+')
    a = p.parse_args()
    out = ROOT / 'evidence' / a.round
    out.mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    rec = {'label': a.label, 'started_at': dt.datetime.now(dt.timezone.utc).isoformat()}
    if a.kind == 'cli':
        args = a.args[1:] if a.args[:1] == ['--'] else a.args
        workspace = ROOT / ('workspace' if a.round == 'baseline' else 'workspace-' + a.round)
        env = os.environ.copy()
        env.update(PYTHONPATH='/workspace/autoSkill/skills/autoskill/app', AUTOSKILL_WORKSPACE=str(workspace), AUTOSKILL_HEADED='0', AUTOSKILL_SESSION='blackbox-api-' + a.round)
        cmd = [sys.executable, '-m', 'autoskill', '--session', 'blackbox-api-' + a.round] + args
        r = subprocess.run(cmd, env=env, cwd=ROOT, capture_output=True)
        stdout, stderr, rc = r.stdout, r.stderr, r.returncode
        rec.update(command=cmd, workspace=str(workspace), returncode=rc)
    elif a.kind == 'http':
        body = a.body.encode() if a.body is not None else None
        req = urllib.request.Request(a.url, data=body, method=a.method, headers={'Content-Type':'application/json'} if body else {})
        try:
            with urllib.request.urlopen(req, timeout=45) as r:
                stdout, stderr, rc = r.read(), b'', 0
                rec.update(http_status=r.status, headers=dict(r.headers))
        except urllib.error.HTTPError as e:
            stdout, stderr, rc = e.read(), b'', 0
            rec.update(http_status=e.code, headers=dict(e.headers))
        except Exception as e:
            stdout, stderr, rc = b'', str(e).encode(), 2
        rec.update(url=a.url, method=a.method, request_body=a.body, returncode=rc)
    else:
        files = []
        for value in a.paths:
            path = Path(value)
            info = {'path':str(path), 'exists':path.is_file()}
            if path.is_file():
                data = path.read_bytes()
                info.update(size=len(data), sha256=hashlib.sha256(data).hexdigest())
            files.append(info)
        stdout, stderr, rc = json.dumps(files, ensure_ascii=False, indent=2).encode(), b'', 0
    rec['elapsed_seconds'] = time.monotonic() - start
    rec['ended_at'] = dt.datetime.now(dt.timezone.utc).isoformat()
    (out / (a.label + '.stdout')).write_bytes(stdout)
    (out / (a.label + '.stderr')).write_bytes(stderr)
    try:
        rec['response'] = json.loads(stdout)
    except (ValueError, UnicodeError):
        if a.kind == 'http' and 'text/' not in rec.get('headers',{}).get('Content-Type',''):
            rec['response_artifact']={'bytes':len(stdout),'sha256':hashlib.sha256(stdout).hexdigest()}
        else:
            rec['response_text'] = stdout.decode(errors='replace')
    (out / (a.label + '.json')).write_text(json.dumps(rec, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(rec, ensure_ascii=False))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
