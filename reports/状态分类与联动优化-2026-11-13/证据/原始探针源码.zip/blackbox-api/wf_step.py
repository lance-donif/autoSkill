#!/usr/bin/env python3
"""Submit public workflow tasks using only a prior captured task receipt."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('--round',default='baseline')
p.add_argument('--task-label',required=True)
p.add_argument('--label',required=True)
p.add_argument('--payload',required=True)
a=p.parse_args()
task=json.loads((ROOT/'evidence'/a.round/(a.task_label+'.json')).read_text())['response']['task']
cmd=[sys.executable,str(ROOT/'bb.py'),'--round',a.round,'--label',a.label,'cli','--','workflow','submit',task['workflow_id'],task['item_id'],'--lease-token',task['lease_token'],'--attempt-id',task['attempt_id'],'--idempotency-key',a.label,'--file',a.payload]
raise SystemExit(subprocess.run(cmd).returncode)
