#!/usr/bin/env python3
"""Observe documented public revision/run/result APIs without product imports."""
import argparse
import datetime as dt
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import urllib.error
import urllib.request

ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('--round',default='final-retest')
p.add_argument('--port',type=int,default=18884)
p.add_argument('--label',default='044-api-observe')
a=p.parse_args()
out=ROOT/'evidence'/a.round
workspace=ROOT/('workspace-'+a.round)
base='http://127.0.0.1:'+str(a.port)
records=[]
def get(suffix,path):
    label=a.label+'-'+suffix
    started=dt.datetime.now(dt.timezone.utc).isoformat()
    mono=time.monotonic()
    try:
        with urllib.request.urlopen(base+path,timeout=20) as r:
            body=r.read(); status=r.status; headers=dict(r.headers)
    except urllib.error.HTTPError as e:
        body=e.read(); status=e.code; headers=dict(e.headers)
    ended=dt.datetime.now(dt.timezone.utc).isoformat()
    rec={'label':label,'url':base+path,'started_at':started,'ended_at':ended,'elapsed_seconds':time.monotonic()-mono,'http_status':status,'headers':headers,'response':json.loads(body)}
    (out/(label+'.stdout')).write_bytes(body)
    (out/(label+'.json')).write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n')
    records.append({'label':label,'http_status':status,'started_at':started,'ended_at':ended,'elapsed_seconds':rec['elapsed_seconds']})
    return rec
def rows(value,key):
    if isinstance(value,list):
        return value
    return value.get(key,value.get('items',[]))

env=os.environ.copy()
env.update(PYTHONPATH='/workspace/autoSkill/skills/autoskill/app',AUTOSKILL_WORKSPACE=str(workspace),AUTOSKILL_HEADED='0',AUTOSKILL_SESSION='blackbox-api-'+a.round)
log=(out/(a.label+'-dashboard.log')).open('w')
dashboard=subprocess.Popen([sys.executable,'-m','autoskill','dashboard','--port',str(a.port),'--headless'],env=env,stdout=log,stderr=subprocess.STDOUT)
try:
    for i in range(80):
        try:
            initial=get('initial-revision','/api/state-revision')
            break
        except Exception:
            time.sleep(.1)
    else:
        raise RuntimeError('Public dashboard did not become available')
    get('initial-runs','/api/runs?cycle=all')
    get('initial-results','/api/results?cycle=all')
    run_label=a.label+'-native-run'
    proc=subprocess.Popen([sys.executable,str(ROOT/'bb.py'),'--round',a.round,'--label',run_label,'cli','--','native','run','bb-api','bb-slow'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    last_revision=None
    run_id=None
    observed=[]
    terminal=None
    final_row=None
    begin=time.monotonic()
    for i in range(450):
        revision=get('revision-'+str(i).zfill(3),'/api/state-revision')
        value=json.dumps(revision['response'],sort_keys=True)
        newly_identified=False
        if run_id is None and proc.poll() is not None:
            created=json.loads((out/(run_label+'.json')).read_text())
            run_id=created['response']['id']
            newly_identified=True
        if value!=last_revision or newly_identified:
            runrec=get('runs-'+str(i).zfill(3),'/api/runs?cycle=all')
            matches=[r for r in rows(runrec['response'],'runs') if r.get('id')==run_id]
            if matches:
                row=matches[0]
                state=row.get('state',{})
                observed.append({'observed_at':runrec['ended_at'],'http_seconds':runrec['elapsed_seconds'],'status':row.get('status'),'state':state,'started_at':row.get('started_at'),'finished_at':row.get('finished_at')})
                final_row=row
                if row.get('finished_at') or state.get('lifecycle') in ('completed','cancelled'):
                    terminal=runrec['ended_at']
                    break
        last_revision=value
        if time.monotonic()-begin>70:
            break
        time.sleep(.1)
    if proc.poll() is None:
        proc.wait(timeout=20)
    for name,path in [('runs-current','/api/runs?cycle=current'),('runs-all','/api/runs?cycle=all'),('results-current','/api/results?cycle=current'),('results-all','/api/results?cycle=all'),('runs-business-fail','/api/runs?business=fail&cycle=all'),('results-business-fail','/api/results?business=fail&cycle=all')]:
        get(name,path)
    summary={'run_id':run_id,'observations':observed,'final_row':final_row,'requests':records,'metric_scope':'Public HTTP revision + run API observation only; browser paint and frontend focus/scroll are not measured.'}
    if terminal and final_row.get('finished_at'):
        summary['terminal_observation_delay_seconds']=(dt.datetime.fromisoformat(terminal)-dt.datetime.fromisoformat(final_row['finished_at'])).total_seconds()
    if observed and observed[0].get('started_at'):
        summary['first_state_observation_delay_seconds']=(dt.datetime.fromisoformat(observed[0]['observed_at'])-dt.datetime.fromisoformat(observed[0]['started_at'])).total_seconds()
    (out/(a.label+'-summary.json')).write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k not in ('final_row','requests')},ensure_ascii=False))
finally:
    dashboard.terminate()
    dashboard.wait(timeout=20)
    log.close()
