from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request

RETEST=Path(__file__).resolve().parents[1]
ROOT=RETEST.parent
BASE='http://127.0.0.1:18890'
FIXTURE=json.loads((ROOT/'fixtures/address.json').read_text())['url']
ENV=os.environ.copy()
ENV.update({'PYTHONPATH':'/workspace/autoSkill/skills/autoskill/app','AUTOSKILL_WORKSPACE':str(ROOT/'workspace-candidate'),'AUTOSKILL_HEADED':'0','AUTOSKILL_SESSION':'fresh-blind-retest'})

def cli(*args,label=None,timeout=90):
    started=time.time_ns()
    argv=[sys.executable,'-m','autoskill',*map(str,args)]
    result=subprocess.run(argv,env=ENV,capture_output=True,text=True,timeout=timeout)
    record={'argv':argv,'started_ns':started,'finished_ns':time.time_ns(),'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
    path=RETEST/'evidence'/f'cli-{started}-{label or args[0]}.json'
    path.write_text(json.dumps(record,ensure_ascii=False,indent=2))
    try:body=json.loads(result.stdout)
    except ValueError:body={'unparsed':result.stdout}
    return {'body':body,'exit_code':result.returncode,'evidence':str(path.relative_to(RETEST))}

def http(path,method='GET',body=None,origin=BASE,label='http'):
    started=time.time_ns()
    req=urllib.request.Request(origin+path,method=method,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'})
    try:response=urllib.request.urlopen(req,timeout=20)
    except urllib.error.HTTPError as exc:response=exc
    raw=response.read()
    try:content=json.loads(raw)
    except ValueError:content={'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    record={'url':origin+path,'method':method,'request':body,'started_ns':started,'finished_ns':time.time_ns(),'http_status':response.status,'body':content}
    path=RETEST/'evidence'/f'{label}-{started}.json'
    path.write_text(json.dumps(record,ensure_ascii=False,indent=2))
    return record

def control(**values):
    return http('/control',method='POST',body=values,origin=FIXTURE,label='fixture-control')

def load():
    result={'time_ns':time.time_ns(),'loadavg':os.getloadavg(),'cpu_count':os.cpu_count()}
    for name in ['cpu.max','cpu.stat']:
        path=Path('/sys/fs/cgroup')/name
        if path.exists():result[name]=path.read_text()
    return result
