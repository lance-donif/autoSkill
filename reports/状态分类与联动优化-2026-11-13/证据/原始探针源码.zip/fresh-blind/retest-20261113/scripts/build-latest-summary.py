from pathlib import Path
import copy
import datetime
import hashlib
import json
from support import RETEST,ROOT

pointer=json.loads((RETEST/'evidence/latest-attempt.json').read_text())
attempt_path=RETEST/pointer['path']
attempt=json.loads(attempt_path.read_text())
first=json.loads((ROOT/'reports/acceptance-results.json').read_text())
steps={item['name']:item['value'] for item in attempt.get('steps',[])}
items=[]
for original in first['items']:
    item={'id':original['id'],'task':original['task'],'first_round_status':original['status'],'latest_status':original['status'],'verification_scope':'carried_forward','first_round_finding':original['finding'],'latest_finding':'沿用首轮判定，本次定向复验未重跑该整项。','first_round_evidence':[str(ROOT/path) for path in original['evidence']],'latest_evidence':[]}
    if item['id']==4:
        current=steps.get('native_ui_rerun')
        item['verification_scope']='targeted_retest'
        item['latest_status']=current.get('status','Blocked') if current else 'Blocked'
        item['latest_finding']='当前UI原生重跑动作与旧失败保留的实际结果：'+json.dumps(current,ensure_ascii=False)
        item['latest_evidence']=[str(attempt_path),str(attempt_path.parent/'native-rerun-before.json'),str(attempt_path.parent/'native-rerun-after.json')]
    elif item['id']==6 and attempt.get('report_retry_only_export'):
        checks=attempt['report_retry_only_export']
        item['verification_scope']='targeted_retest'
        item['latest_status']='Pass' if all(checks.values()) and attempt.get('report_repaired',{}).get('status')=='ready' else 'Fail'
        item['latest_finding']='再次以真实UI手动重导出：'+json.dumps(checks,ensure_ascii=False)
        item['latest_evidence']=[str(attempt_path),str(attempt_path.parent/'report-failed.json'),str(attempt_path.parent/'report-ready.json')]
    elif item['id']==7:
        statuses={key:attempt.get(key,'Blocked') for key in ['terminal_sample_status','report_failure_sample_status','report_ready_sample_status','restore_sample_status']}
        interaction=attempt.get('offline_interaction_preserved')
        item['verification_scope']='targeted_retest'
        item['latest_status']='Fail' if 'Fail' in statuses.values() or interaction is False else 'Pass' if all(value=='Pass' for value in statuses.values()) and interaction is True else 'Blocked'
        item['latest_finding']='复验样本判定：'+json.dumps(statuses,ensure_ascii=False)+f'；恢复后的交互保留={interaction}。终态以finished_at到double-rAF paint为保守上界，仅<1秒可证明该样本达标；不以ack替代严格提交目标。'
        item['latest_evidence']=[str(attempt_path),str(attempt_path.parent/'offline-visible.json'),str(attempt_path.parent/'offline-restored-fresh-failure.json')]
        item['measurements_ms']={key:attempt.get(key) for key in ['terminal_receipt_finish_to_paint_ms','report_unlink_to_paint_ms','report_last_artifact_write_to_ready_paint_ms','restore_start_to_fresh_result_paint_ms','restore_completed_to_fresh_result_paint_ms']}
        item['sample_statuses']=statuses
    elif item['id']==8:
        item['verification_scope']='carried_forward_with_recorder_recheck'
        item['latest_status']='Blocked'
        item['latest_finding']='真实DSH/完整录制器验收继续Blocked；未模拟。录制器公开入口复查：'+json.dumps(attempt.get('recorder_recheck',{'not_reached':True}),ensure_ascii=False)
        if attempt.get('recorder_recheck'):item['latest_evidence']=[str(RETEST/attempt['recorder_recheck']['evidence'])]
    items.append(item)

result={'schema_version':'fresh-blind-8-items-v2','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'first_round_report':str(ROOT/'reports/独立验收.md'),'first_round_report_unchanged':attempt.get('first_round_report_unchanged'),'candidate_restart':json.loads((RETEST/'final-candidate-restart.json').read_text()),'retest_attempt':str(attempt_path),'latest_counts':{status:sum(x['latest_status']==status for x in items) for status in ['Pass','Fail','Blocked']},'items':items,'strict_latency_boundary':'finished_at precedes commit, so finished_at→paint<1s is a conservative sample upper bound. Values above1s remain unconfirmed for exact commit latency. Response acknowledgement is not substituted for the target.','retained_first_round_observations':{'business_receipt_to_paint_ms':[1238,1190,788],'source':str(ROOT/'evidence/foreground-sync.json')},'errors':attempt.get('errors',[]),'load':attempt.get('load',[])}
(RETEST/'reports/latest-8-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
(attempt_path.parent/'latest-8-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
lines=['# 独立定向复验对照','',f"最新：{result['latest_counts']}。首轮原件保留；未定向重跑的项目明确标为沿用。",'','|任务|首轮|最新|验证范围|','|---|---|---|---|']
for item in items:lines.append(f"|{item['id']}. {item['task']}|{item['first_round_status']}|{item['latest_status']}|{item['verification_scope']}|")
lines+=['','## 定向实测','',f"原生UI重跑：{json.dumps(steps.get('native_ui_rerun'),ensure_ascii=False)}",'',f"终态保守上界：{attempt.get('terminal_receipt_finish_to_paint_ms')}ms。报告unlink→失败绘制：{attempt.get('report_unlink_to_paint_ms')}ms；三件套最后写入→就绪绘制：{attempt.get('report_last_artifact_write_to_ready_paint_ms')}ms。",'',f"断网期间真实CLI执行完新的独立业务失败；恢复开始→新失败DOM绘制：{attempt.get('restore_start_to_fresh_result_paint_ms')}ms，恢复完成→绘制：{attempt.get('restore_completed_to_fresh_result_paint_ms')}ms。输入/焦点/选区/滚动保留：{attempt.get('offline_interaction_preserved')}。",'',result['strict_latency_boundary'],'','首轮1238/1190/788ms观测原样保留，不改写为通过或精确提交违约。','',f"[完整复验原始记录]({attempt_path})",'',f"[机器可读8项汇总]({RETEST/'reports/latest-8-results.json'})"]
(RETEST/'reports/首轮与复验对照.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps({'latest_counts':result['latest_counts'],'summary':str(RETEST/'reports/latest-8-results.json'),'comparison':str(RETEST/'reports/首轮与复验对照.md'),'items':[{'id':x['id'],'first_round_status':x['first_round_status'],'latest_status':x['latest_status'],'verification_scope':x['verification_scope']} for x in items]},ensure_ascii=False))
