from pathlib import Path
from playwright.sync_api import sync_playwright
import datetime
import hashlib
import json
import shutil
import time
import traceback
from support import RETEST,ROOT,BASE,FIXTURE,cli,http,control,load

if not (RETEST/'second-quiet-window.json').exists():
    raise SystemExit('Timing prohibited: waiting for 第二安静窗口开始')

OUT={'started_ns':time.time_ns(),'load':[load()],'steps':[],'errors':[],'browser':'/usr/bin/chromium','no_product_imports':True,'first_round_report_sha256':hashlib.sha256((ROOT/'reports/独立验收.md').read_bytes()).hexdigest()}
ATTEMPT=RETEST/'evidence'/('attempt-'+str(OUT['started_ns']))
ATTEMPT.mkdir()
OUT['attempt_directory']=str(ATTEMPT.relative_to(RETEST))

def save():
    (ATTEMPT/'targeted-retest.json').write_text(json.dumps(OUT,ensure_ascii=False,indent=2))
    (RETEST/'evidence/latest-attempt.json').write_text(json.dumps({'path':str((ATTEMPT/'targeted-retest.json').relative_to(RETEST))},indent=2))

def progress(name,value):
    OUT['steps'].append({'name':name,'time_ns':time.time_ns(),'value':value})
    save()
    print(json.dumps({'step':name,'value':value},ensure_ascii=False),flush=True)

def evidence(page,name):
    result={'url':page.url,'body':page.locator('body').inner_text(),'buttons':page.locator('button').all_text_contents(),'visibility':page.evaluate('document.visibilityState'),'hasFocus':page.evaluate('document.hasFocus()')}
    (ATTEMPT/f'{name}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    page.screenshot(path=str(ATTEMPT/f'{name}.png'),full_page=True)
    return result

def observe(page,name,expression):
    page.evaluate('''([name,expression])=>{window[name]=[];const read=new Function('return ('+expression+')');let previous=JSON.stringify(read());window[name].push({kind:'initial',at:Date.now(),value:JSON.parse(previous)});new MutationObserver(()=>{const value=read();const next=JSON.stringify(value);if(next===previous)return;previous=next;const event={kind:'dom',at:Date.now(),value};window[name].push(event);requestAnimationFrame(()=>requestAnimationFrame(()=>window[name].push({kind:'paint',at:Date.now(),value,domAt:event.at})))}).observe(document.body,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['class','style','hidden','aria-hidden']})}''',[name,expression])

def wait_paint(page,name,predicate,timeout=12000):
    try:
        page.wait_for_function('([name,predicate])=>window[name].some(event=>event.kind==="paint"&&new Function("value","return ("+predicate+")")(event.value))',arg=[name,predicate],timeout=timeout)
        events=page.evaluate('(name)=>window[name]',name)
        matches=page.evaluate('([name,predicate])=>window[name].filter(event=>event.kind==="paint"&&new Function("value","return ("+predicate+")")(event.value))',[name,predicate])
        return {'event':matches[0] if matches else None,'events':events}
    except Exception as exc:
        return {'event':None,'events':page.evaluate('(name)=>window[name]',name),'error':str(exc)}

try:
    control(retry_answer=42,hold=True)
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        context=browser.new_context(viewport={'width':1200,'height':600})
        page=context.new_page()
        posts=[]
        def capture_response(response):
            if response.request.method=='POST':
                record={'url':response.url,'method':'POST','request':response.request.post_data,'status':response.status,'at_ns':time.time_ns()}
                try:record['body']=response.json()
                except Exception:pass
                posts.append(record)
        page.on('response',capture_response)
        page.goto(BASE+'/#/runs/run-84f885b6f65d',wait_until='domcontentloaded')
        page.get_by_text('报告：已就绪',exact=True).first.wait_for(timeout=15000)
        page.bring_to_front()
        before=evidence(page,'native-rerun-before')
        labels=before['buttons']
        if '重跑原生资产' in labels:
            button=page.get_by_role('button',name='重跑原生资产',exact=True)
            OUT['native_rerun_action']='重跑原生资产'
        else:
            button=page.get_by_role('button',name='只重跑未通过的 1 条',exact=True)
            OUT['native_rerun_action']='只重跑未通过的 1 条'
        with page.expect_response(lambda response:response.request.method=='POST' and response.url.endswith('/rerun'),timeout=15000) as response:
            button.click()
        rerun_response=response.value
        rerun_body=rerun_response.json()
        OUT['native_rerun_response']={'status':rerun_response.status,'body':rerun_body,'posts':posts.copy()}
        run_id=rerun_body.get('id') or rerun_body.get('run_id') or rerun_body.get('run',{}).get('id')
        if rerun_response.status>=400 or not run_id:
            progress('native_ui_rerun',{'status':'Fail','response':OUT['native_rerun_response']})
            evidence(page,'native-rerun-failed')
            control(hold=False)
        else:
            OUT['native_rerun_id']=run_id
            page.wait_for_url(lambda url:run_id in url,timeout=15000)
            page.get_by_text('综合：待处理',exact=True).first.wait_for(timeout=15000)
            OUT['terminal_initial_statuses']=page.locator('.status').evaluate_all('(xs)=>xs.map(x=>({text:x.innerText,html:x.outerHTML}))')
            observe(page,'__retestTerminal',"({phase:document.querySelector('.status')?.innerText||'',pass:document.body.innerText.includes('综合：通过')})")
            OUT['native_release']=control(hold=False)
            terminal=wait_paint(page,'__retestTerminal',"value.phase==='已结束'&&value.pass",timeout=20000)
            OUT['terminal_paint']=terminal
            # No independent API or CLI polling occurs until after paint is captured.
            current=cli('native','status',run_id,'--all',label='native-ui-rerun-status')
            old=cli('native','status','run-84f885b6f65d','--all',label='original-failure-still-present')
            OUT['native_current']=current;OUT['native_original']=old
            passed=rerun_response.status<300 and current['body'].get('state',{}).get('checks',{}).get('business')=='pass' and old['body'].get('state',{}).get('checks',{}).get('business')=='fail'
            progress('native_ui_rerun',{'status':'Pass' if passed else 'Fail','new_run_id':run_id,'old_business':old['body'].get('state',{}).get('checks',{}).get('business'),'new_business':current['body'].get('state',{}).get('checks',{}).get('business'),'ui_action':OUT['native_rerun_action']})
            if terminal['event'] and current['body'].get('finished_at'):
                upper=terminal['event']['at']-datetime.datetime.fromisoformat(current['body']['finished_at']).timestamp()*1000
                OUT['terminal_receipt_finish_to_paint_ms']=round(upper,3)
                OUT['terminal_sample_status']='Pass' if upper<=1000 else 'Blocked'
            else:OUT['terminal_sample_status']='Blocked'
            progress('terminal_paint',{'status':OUT['terminal_sample_status'],'receipt_finish_to_paint_ms':OUT.get('terminal_receipt_finish_to_paint_ms'),'boundary':'finished_at precedes commit; less than1s is a conservative upper bound. More than1s cannot establish exact commit violation.'})
            evidence(page,'native-rerun-after')

        # Report timing uses the original owned run report, preserving pre-mutation copies.
        report=http('/api/task-reports/run_run-6d5493ee196e',label='report-before')['body']
        path=Path(report['markdown'])
        if not path.is_relative_to(ROOT):raise RuntimeError('Report outside owned directory')
        shutil.copy2(path,ATTEMPT/'report-markdown-before-unlink.md')
        page.goto(BASE+'/#/runs/run-6d5493ee196e',wait_until='domcontentloaded')
        page.get_by_text('报告：已就绪',exact=True).first.wait_for(timeout=15000)
        observe(page,'__retestReport',"document.body.innerText.includes('报告：失败')?'failed':document.body.innerText.includes('报告：已就绪')?'ready':'other'")
        OUT['report_unlink_started_ns']=time.time_ns();path.unlink();OUT['report_unlink_finished_ns']=time.time_ns()
        failed=wait_paint(page,'__retestReport',"value==='failed'",timeout=5000)
        OUT['report_failed_paint']=failed
        failed_public=http('/api/task-reports/run_run-6d5493ee196e',label='report-failed-after-paint')
        OUT['report_failed_public']=failed_public
        if failed['event']:
            elapsed=failed['event']['at']-OUT['report_unlink_finished_ns']/1e6
            OUT['report_unlink_to_paint_ms']=round(elapsed,3)
            OUT['report_failure_sample_status']='Pass' if elapsed<=1000 else 'Fail'
        else:OUT['report_failure_sample_status']='Fail'
        evidence(page,'report-failed')
        fixture_before=http('/counts',origin=FIXTURE,label='report-count-before')['body']
        run_ids_before={x['id'] for x in http('/api/runs?cycle=all&limit=1000',label='report-runs-before')['body']['items']}
        with page.expect_response(lambda response:response.request.method=='POST' and response.url.endswith('/retry'),timeout=15000) as response:
            page.get_by_role('button',name='重试导出报告',exact=True).click()
        OUT['report_retry_response']={'status':response.value.status,'body':response.value.json()}
        ready=wait_paint(page,'__retestReport',"value==='ready'",timeout=15000)
        OUT['report_ready_paint']=ready
        repaired=http('/api/task-reports/run_run-6d5493ee196e',label='report-repaired-after-paint')['body']
        OUT['report_repaired']=repaired
        if ready['event']:
            artifacts=[Path(repaired[key]) for key in ['excel','markdown','bugs']]
            latest_write=max(item.stat().st_mtime_ns for item in artifacts)
            upper=ready['event']['at']-latest_write/1e6
            OUT['report_last_artifact_write_to_ready_paint_ms']=round(upper,3)
            OUT['report_ready_sample_status']='Pass' if upper<=1000 else 'Blocked'
        else:OUT['report_ready_sample_status']='Blocked'
        fixture_after=http('/counts',origin=FIXTURE,label='report-count-after')['body']
        run_ids_after={x['id'] for x in http('/api/runs?cycle=all&limit=1000',label='report-runs-after')['body']['items']}
        OUT['report_retry_only_export']={'fixture_queries_unchanged':fixture_before['queries']==fixture_after['queries'],'run_ids_unchanged':run_ids_before==run_ids_after,'source_hash_unchanged':report['source_hash']==repaired.get('source_hash')}
        progress('report_failure_and_ready_paint',{'failure_status':OUT['report_failure_sample_status'],'unlink_to_failed_paint_ms':OUT.get('report_unlink_to_paint_ms'),'ready_status':OUT['report_ready_sample_status'],'last_artifact_write_to_ready_paint_ms':OUT.get('report_last_artifact_write_to_ready_paint_ms'),'retry_only_export':OUT['report_retry_only_export']})
        evidence(page,'report-ready')

        # A business result commits while this actual browser is offline; restore must show it.
        page.set_viewport_size({'width':1100,'height':430})
        page.goto(BASE+'/#/cases',wait_until='domcontentloaded')
        search=page.get_by_role('searchbox',name='搜索用例')
        search.wait_for(timeout=15000)
        page.get_by_text('TC-API-FRESH-001',exact=True).wait_for(timeout=15000)
        search.fill('Six');page.wait_for_timeout(650);search.focus();page.bring_to_front()
        page.evaluate("()=>{document.querySelector('input[type=search]').setSelectionRange(1,3);window.scrollTo(0,31)}")
        interaction="(()=>{const input=document.querySelector('input[type=search]');return {value:input?.value,focused:document.activeElement===input,start:input?.selectionStart,end:input?.selectionEnd,scrollY:window.scrollY}})()"
        OUT['offline_before_interaction']=page.evaluate(interaction)
        observe(page,'__retestOffline',"({offline:/连不上|同步.*(异常|失败|中断)|连接.*(异常|失败|中断|断开)|服务不可用|离线|网络已断开/.test(document.body.innerText),caseFailed:[...document.querySelectorAll('tbody tr')].some(x=>x.innerText.includes('TC-API-FRESH-001')&&x.innerText.includes('综合：失败'))})")
        OUT['offline_started_ns']=time.time_ns();context.set_offline(True)
        offline=wait_paint(page,'__retestOffline',"value.offline",timeout=6000)
        OUT['offline_notice']=offline
        evidence(page,'offline-visible')
        control(retry_answer=41)
        offline_run=cli('run','fresh-arithmetic','--case','TC-API-FRESH-001','--headless',label='business-committed-while-browser-offline')
        OUT['offline_committed_run']=offline_run
        OUT['restore_started_ns']=time.time_ns();context.set_offline(False);OUT['restore_completed_ns']=time.time_ns()
        recovered=wait_paint(page,'__retestOffline',"!value.offline&&value.caseFailed",timeout=6000)
        OUT['offline_recovered_paint']=recovered
        OUT['offline_after_interaction']=page.evaluate(interaction)
        if recovered['event']:
            upper=recovered['event']['at']-OUT['restore_started_ns']/1e6
            lower=recovered['event']['at']-OUT['restore_completed_ns']/1e6
            OUT['restore_start_to_fresh_result_paint_ms']=round(upper,3)
            OUT['restore_completed_to_fresh_result_paint_ms']=round(lower,3)
            OUT['restore_sample_status']='Pass' if upper<=1000 else 'Fail' if lower>1000 else 'Blocked'
        else:OUT['restore_sample_status']='Fail'
        OUT['offline_interaction_preserved']=OUT['offline_before_interaction']==OUT['offline_after_interaction']
        progress('offline_restore_fresh_result',{'status':OUT['restore_sample_status'],'restore_start_to_paint_ms':OUT.get('restore_start_to_fresh_result_paint_ms'),'restore_completed_to_paint_ms':OUT.get('restore_completed_to_fresh_result_paint_ms'),'offline_notice_present':offline['event'] is not None,'interaction_preserved':OUT['offline_interaction_preserved']})
        evidence(page,'offline-restored-fresh-failure')
        browser.close()
    OUT['recorder_recheck']=cli('record','start','fresh-arithmetic','--no-login',label='real-recorder-recheck')
    if OUT['recorder_recheck']['exit_code']==0:
        OUT['recorder_cleanup']=cli('record','cancel',label='real-recorder-cleanup')
except Exception:
    OUT['errors'].append(traceback.format_exc())
finally:
    try:control(retry_answer=42,hold=False)
    except Exception as exc:OUT['errors'].append(str(exc))
    OUT['load'].append(load());OUT['finished_ns']=time.time_ns()
    OUT['first_round_report_unchanged']=OUT['first_round_report_sha256']==hashlib.sha256((ROOT/'reports/独立验收.md').read_bytes()).hexdigest()
    save()
    if OUT['errors']:print(json.dumps({'errors':OUT['errors']},ensure_ascii=False),flush=True)
