from pathlib import Path
from playwright.sync_api import sync_playwright
import datetime
import json
import os
import subprocess
import sys
import time
import traceback
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
BASE='http://127.0.0.1:18890'
fixture=json.loads((ROOT/'fixtures/address.json').read_text())['url']
OUT={'started_ns':time.time_ns(),'method':'Actual Chromium visible foreground page; MutationObserver plus double requestAnimationFrame; run.finished_at is the conservative receipt timestamp before the DB commit; API first visible sampled independently. No product imports.','experiments':[],'load':[]}
def get(path):
    with urllib.request.urlopen(BASE+path,timeout=10) as response:return json.load(response)
def control(**values):
    request=urllib.request.Request(fixture+'/control',method='POST',data=json.dumps(values).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(request,timeout=10) as response:return json.load(response)
def load():
    item={'time_ns':time.time_ns(),'loadavg':os.getloadavg(),'cpu_count':os.cpu_count()}
    for name in ['cpu.max','cpu.stat']:
        path=Path('/sys/fs/cgroup')/name
        if path.exists():item[name]=path.read_text()
    OUT['load'].append(item)
def row(page):
    return page.evaluate('''() => {const x=[...document.querySelectorAll('tbody tr')].find(x=>x.innerText.includes('TC-API-FRESH-001'));return x?.innerText||''}''')
def interaction(page):
    return page.evaluate('''() => {const x=document.querySelector('input[type=search]');return {value:x?.value,focused:document.activeElement===x,selectionStart:x?.selectionStart,selectionEnd:x?.selectionEnd,scrollX:window.scrollX,scrollY:window.scrollY,visibility:document.visibilityState,hasFocus:document.hasFocus()}}''')
try:
    load()
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        context=browser.new_context(viewport={'width':1100,'height':430})
        page=context.new_page()
        page.goto(BASE+'/#/cases',wait_until='domcontentloaded')
        page.get_by_role('searchbox',name='搜索用例').wait_for(timeout=15000)
        page.get_by_text('TC-API-FRESH-001',exact=True).wait_for(timeout=15000)
        page.bring_to_front()
        search=page.get_by_role('searchbox',name='搜索用例')
        search.fill('Six')
        search.focus()
        page.evaluate('''() => {const x=document.querySelector('input[type=search]');x.setSelectionRange(1,3);window.scrollTo(0,80);window.__blindEvents=[];let previous='';const read=()=>[...document.querySelectorAll('tbody tr')].find(x=>x.innerText.includes('TC-API-FRESH-001'))?.innerText||'';previous=read();window.__blindEvents.push({at:Date.now(),kind:'initial',text:previous});new MutationObserver(()=>{const text=read();if(text===previous)return;previous=text;const event={at:Date.now(),kind:'dom',text};window.__blindEvents.push(event);requestAnimationFrame(()=>requestAnimationFrame(()=>{window.__blindEvents.push({at:Date.now(),kind:'paint',text,domAt:event.at})}))}).observe(document.body,{subtree:true,childList:true,characterData:true})}''')
        OUT['initial_interaction']=interaction(page)
        OUT['initial_row']=row(page)
        OUT['browser']={'version':browser.version,'executable':'/usr/bin/chromium','viewport':{'width':1100,'height':430}}
        for index,(answer,label,target) in enumerate([(42,'pass','综合：通过'),(41,'fail','综合：失败'),(42,'pass','综合：通过')]):
            exp={'index':index,'expected_answer':42,'fixture_answer':answer,'target':label,'started_ns':time.time_ns(),'before_row':row(page),'before_interaction':interaction(page),'api_observations':[]}
            load()
            ids={x['id'] for x in get('/api/runs?cycle=all&limit=1000')['items']}
            control(retry_answer=answer,hold=True)
            event_count=page.evaluate('window.__blindEvents.length')
            started=time.time_ns()
            proc=subprocess.Popen([sys.executable,str(ROOT/'scripts/cli.py'),'run','fresh-arithmetic','--case','TC-API-FRESH-001','--headless'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            exp['cli_started_ns']=started
            run_id=None;released=False;terminal=None;terminal_visible=None;paint=None
            deadline=time.monotonic()+25
            while time.monotonic()<deadline:
                poll_start=time.time_ns()
                payload=get('/api/runs?cycle=all&limit=1000')
                received=time.time_ns()
                candidates=[x for x in payload['items'] if x['id'] not in ids]
                if candidates:
                    current=candidates[0];run_id=current['id']
                    exp['api_observations'].append({'poll_start_ns':poll_start,'received_ns':received,'run_id':run_id,'status':current['status'],'state':current['state'],'finished_at':current.get('finished_at')})
                    if not released:
                        page.wait_for_timeout(300)
                        control(hold=False)
                        exp['fixture_released_ns']=time.time_ns();released=True
                    if current['status'] in ['Pass','Fail','Blocked','Cancelled'] and terminal is None:
                        terminal=current;terminal_visible=received
                events=page.evaluate('(offset)=>window.__blindEvents.slice(offset)',event_count)
                matches=[event for event in events if event['kind']=='paint' and target in event['text']]
                if terminal is not None and matches:
                    paint=matches[0];break
                page.wait_for_timeout(35)
            control(hold=False)
            try:stdout,stderr=proc.communicate(timeout=15)
            except subprocess.TimeoutExpired:
                proc.kill();stdout,stderr=proc.communicate();exp['cli_timeout']=True
            cli_file=ROOT/'evidence'/f'foreground-cli-{index}.json'
            cli_file.write_text(json.dumps({'argv':proc.args,'exit_code':proc.returncode,'stdout':stdout,'stderr':stderr},ensure_ascii=False,indent=2))
            exp.update({'run_id':run_id,'terminal':terminal,'terminal_first_public_ns':terminal_visible,'paint':paint,'events':page.evaluate('(offset)=>window.__blindEvents.slice(offset)',event_count),'after_row':row(page),'after_interaction':interaction(page),'cli_evidence':str(cli_file),'finished_ns':time.time_ns()})
            if terminal and terminal.get('finished_at') and paint:
                commit_before_ms=datetime.datetime.fromisoformat(terminal['finished_at']).timestamp()*1000
                exp['paint_minus_receipt_finish_ms']=round(paint['at']-commit_before_ms,3)
                exp['paint_minus_first_public_visible_ms']=round(paint['at']-terminal_visible/1e6,3)
                exp['within_one_second']=exp['paint_minus_receipt_finish_ms']<=1000
            else:
                exp['within_one_second']=False
                exp['missing_measurement']='no matching terminal state and painted DOM before deadline'
            before=exp['before_interaction'];after=exp['after_interaction']
            exp['interaction_preserved']=all(before.get(k)==after.get(k) for k in ['value','focused','selectionStart','selectionEnd','scrollX','scrollY'])
            OUT['experiments'].append(exp)
            page.screenshot(path=str(ROOT/'evidence'/f'foreground-sync-{index}.png'),full_page=True)
            print(json.dumps({k:exp.get(k) for k in ['index','run_id','paint_minus_receipt_finish_ms','paint_minus_first_public_visible_ms','within_one_second','interaction_preserved','missing_measurement']},ensure_ascii=False),flush=True)
        OUT['final_events']=page.evaluate('window.__blindEvents')
        OUT['final_body']=page.locator('body').inner_text()
        browser.close()
except Exception:
    OUT['error']=traceback.format_exc()
    try:control(hold=False)
    except Exception:pass
finally:
    load()
    OUT['finished_ns']=time.time_ns()
    (ROOT/'evidence/foreground-sync.json').write_text(json.dumps(OUT,ensure_ascii=False,indent=2))
    if OUT.get('error'):print(OUT['error'],flush=True)
