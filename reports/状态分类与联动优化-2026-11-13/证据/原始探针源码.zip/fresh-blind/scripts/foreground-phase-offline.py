from pathlib import Path
from playwright.sync_api import sync_playwright
import datetime
import json
import os
import subprocess
import sys
import time
import traceback
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
BASE='http://127.0.0.1:18890'
fixture=json.loads((ROOT/'fixtures/address.json').read_text())['url']
OUT={'started_ns':time.time_ns(),'loadavg':os.getloadavg(),'cpu_count':os.cpu_count(),'events':[]}
def get(path):
    with urllib.request.urlopen(BASE+path,timeout=10) as r:return json.load(r)
def control(**values):
    request=urllib.request.Request(fixture+'/control',method='POST',data=json.dumps(values).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(request,timeout=10) as r:return json.load(r)
def view(page):
    return page.evaluate('''()=>({filters:[...document.querySelectorAll('select')].map(x=>x.value),focusedSelect:[...document.querySelectorAll('select')].indexOf(document.activeElement),scrollY:window.scrollY,visibility:document.visibilityState,hasFocus:document.hasFocus(),rows:[...document.querySelectorAll('tbody tr')].map(x=>x.innerText)})''')
try:
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        context=browser.new_context(viewport={'width':1100,'height':430})
        page=context.new_page()
        page.goto(BASE+'/#/runs',wait_until='domcontentloaded')
        page.locator('select').nth(1).wait_for(timeout=15000)
        page.locator('select').nth(0).select_option('all')
        page.locator('select').nth(1).select_option('running')
        page.wait_for_timeout(500)
        page.locator('select').nth(1).focus()
        page.bring_to_front()
        page.evaluate('''()=>{window.scrollTo(0,20);window.__blindPhase=[];const read=()=>[...document.querySelectorAll('tbody tr')].map(x=>x.innerText).join(' | ');let previous=read();new MutationObserver(()=>{const text=read();if(text===previous)return;previous=text;const event={at:Date.now(),kind:'dom',text};window.__blindPhase.push(event);requestAnimationFrame(()=>requestAnimationFrame(()=>window.__blindPhase.push({at:Date.now(),kind:'paint',text,domAt:event.at})))}).observe(document.body,{childList:true,subtree:true,characterData:true})}''')
        OUT['before_view']=view(page)
        ids={x['id'] for x in get('/api/runs?cycle=all&limit=1000')['items']}
        control(hold=True)
        proc=subprocess.Popen([sys.executable,str(ROOT/'scripts/cli.py'),'native','run','fresh-arithmetic','asset-101b7a6ea95d'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        OUT['native_cli_started_ns']=time.time_ns()
        run_id=None;running=None;run_paint=None;terminal=None;end_paint=None;released=False;release_event_count=0
        deadline=time.monotonic()+25
        while time.monotonic()<deadline:
            payload=get('/api/runs?cycle=all&limit=1000')
            received=time.time_ns()
            candidates=[x for x in payload['items'] if x['id'] not in ids]
            if candidates:
                current=candidates[0];run_id=current['id']
                OUT['events'].append({'received_ns':received,'id':run_id,'status':current['status'],'state':current['state'],'started_at':current.get('started_at'),'finished_at':current.get('finished_at')})
                if current['status']=='Running' and running is None:running=current
                if current['status'] in ['Pass','Fail','Blocked','Cancelled'] and terminal is None:terminal=current
            events=page.evaluate('window.__blindPhase')
            matches=[x for x in events if x['kind']=='paint' and '执行中' in x['text']]
            if matches and run_paint is None:
                run_paint=matches[0]
                release_event_count=len(events)
                control(hold=False);released=True;OUT['released_ns']=time.time_ns()
            finished=[x for x in events[release_event_count:] if x['kind']=='paint' and not x['text']]
            if terminal is not None and released and finished:
                end_paint=finished[0];break
            page.wait_for_timeout(35)
        control(hold=False)
        try:stdout,stderr=proc.communicate(timeout=15)
        except subprocess.TimeoutExpired:proc.kill();stdout,stderr=proc.communicate();OUT['cli_timeout']=True
        OUT['native_cli']={'argv':proc.args,'exit_code':proc.returncode,'stdout':stdout,'stderr':stderr}
        OUT.update({'run_id':run_id,'running':running,'run_paint':run_paint,'terminal':terminal,'end_paint':end_paint,'after_view':view(page),'paint_events':page.evaluate('window.__blindPhase')})
        for name,receipt,paint,field in [('running',running,run_paint,'started_at'),('settled',terminal,end_paint,'finished_at')]:
            if receipt and paint and receipt.get(field):
                delta=paint['at']-datetime.datetime.fromisoformat(receipt[field]).timestamp()*1000
                OUT[name+'_paint_ms']=round(delta,3);OUT[name+'_within_one_second']=delta<=1000
        OUT['filters_focus_scroll_preserved']=all(OUT['before_view'][k]==OUT['after_view'][k] for k in ['filters','focusedSelect','scrollY'])
        OUT['offline_before_body']=page.locator('body').inner_text()
        context.set_offline(True)
        OUT['offline_started_ns']=time.time_ns()
        page.wait_for_timeout(1600)
        OUT['offline_body']=page.locator('body').inner_text()
        OUT['offline_view']=view(page)
        page.screenshot(path=str(ROOT/'evidence/foreground-offline.png'),full_page=True)
        context.set_offline(False)
        OUT['online_restored_ns']=time.time_ns()
        page.wait_for_timeout(900)
        OUT['restored_body']=page.locator('body').inner_text()
        OUT['restored_view']=view(page)
        page.screenshot(path=str(ROOT/'evidence/foreground-restored.png'),full_page=True)
        browser.close()
except Exception:OUT['error']=traceback.format_exc()
finally:
    try:control(hold=False)
    except Exception:pass
    OUT['finished_ns']=time.time_ns();OUT['final_loadavg']=os.getloadavg()
    (ROOT/'evidence/foreground-phase-offline.json').write_text(json.dumps(OUT,ensure_ascii=False,indent=2))
    print(json.dumps({k:v for k,v in OUT.items() if k in ['run_id','running_paint_ms','running_within_one_second','settled_paint_ms','settled_within_one_second','filters_focus_scroll_preserved','offline_body','restored_body','error']},ensure_ascii=False))
