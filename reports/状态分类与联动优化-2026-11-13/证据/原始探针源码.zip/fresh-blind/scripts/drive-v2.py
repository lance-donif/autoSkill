from pathlib import Path
import json
from cli import call

ROOT=Path(__file__).resolve().parents[1]
task=json.loads(json.loads((ROOT/'evidence/cli-1794580699348356055-wf-v2-next.json').read_text())['stdout'])['task']
for index in range(8):
    phase=task['phase']
    if phase=='requirements':
        payload={'requirements':[{'id':'req-multiply','text':'Answer six multiplied by seven as numeric42. The original independent expectation remains unchanged after service repair.','source_ids':['arithmetic-contract-v2']}]}
    elif phase in ['design','completion']:
        payload=json.loads((ROOT/'inputs/wf-design-v1.json').read_text())
    elif phase in ['materialize','maintain']:
        payload=json.loads((ROOT/'inputs/wf-materialize-v1.json').read_text())
        payload['cases'][0].update({'revision':2,'source':'arithmetic-contract-v2','source_ref':'arithmetic-contract-v2'})
    elif phase=='knowledge':
        payload={'entries':[{'id':'knowledge-arithmetic-v2','text':'The original multiplication expectation remains42. Verify current execution evidence and retain the prior failed cycle.','evidence_refs':['source:arithmetic-contract-v2']}]}
    else:
        print(json.dumps({'unexpected_task':task},ensure_ascii=False),flush=True)
        break
    file=ROOT/'inputs'/f'wf-{phase}-v2-{index}.json'
    file.write_text(json.dumps(payload,ensure_ascii=False,indent=2))
    result=call('workflow','submit',task['workflow_id'],task['item_id'],'--lease-token',task['lease_token'],'--attempt-id',task['attempt_id'],'--idempotency-key',f'fresh-v2-submit-{phase}-{index}','--file',file,label=f'wf-v2-submit-{phase}')
    print(json.dumps({'phase':phase,'exit_code':result['exit_code'],'cycle_state':result['result'].get('cycle_state'),'conclusion':result['result'].get('conclusion'),'complete':result['result'].get('complete'),'evidence':result['evidence'],'error':result['result'].get('error')},ensure_ascii=False),flush=True)
    if result['exit_code'] or result['result'].get('complete'):break
    next_result=call('workflow','next',task['workflow_id'],'--idempotency-key',f'fresh-v2-next-after-{phase}-{index}','--lease-seconds','1800',label='wf-v2-next')
    task=next_result['result'].get('task')
    if not task:
        print(json.dumps({'no_next_task':next_result},ensure_ascii=False),flush=True)
        break
