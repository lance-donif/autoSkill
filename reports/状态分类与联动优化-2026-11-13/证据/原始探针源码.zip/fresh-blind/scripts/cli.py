"""Public CLI wrapper. Does not import or inspect the product implementation."""
from pathlib import Path
import datetime
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
ENV = os.environ.copy()
ENV.update({"PYTHONPATH": "/workspace/autoSkill/skills/autoskill/app", "AUTOSKILL_WORKSPACE": str(ROOT / "workspace-candidate"), "AUTOSKILL_HEADED": "0", "AUTOSKILL_SESSION": "fresh-blind"})

def call(*args, label=None, timeout=120):
    if not (ROOT / "candidate-frozen.json").exists():
        raise RuntimeError("Product calls are prohibited until candidate freeze is recorded")
    stamp = f"{time.time_ns()}-{label or args[0]}"
    argv = [sys.executable, "-m", "autoskill", *map(str, args)]
    started = time.time_ns()
    try:
        result = subprocess.run(argv, env=ENV, text=True, capture_output=True, timeout=timeout)
        item = {"argv": argv, "started_ns": started, "finished_ns": time.time_ns(), "exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr}
    except subprocess.TimeoutExpired as exc:
        item = {"argv": argv, "started_ns": started, "finished_ns": time.time_ns(), "timeout_seconds": timeout, "stdout": str(exc.stdout), "stderr": str(exc.stderr)}
    (ROOT / "evidence" / f"cli-{stamp}.json").write_text(json.dumps(item, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        parsed = json.loads(item["stdout"])
    except (ValueError, KeyError):
        parsed = item
    return {"exit_code": item.get("exit_code"), "result": parsed, "evidence": f"evidence/cli-{stamp}.json"}

if __name__ == "__main__":
    print(json.dumps(call(*sys.argv[1:]), ensure_ascii=False, indent=2))
