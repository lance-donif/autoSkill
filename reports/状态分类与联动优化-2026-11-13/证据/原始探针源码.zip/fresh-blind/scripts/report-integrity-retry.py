from pathlib import Path
import hashlib
import json
import shutil
import time
import urllib.error
import urllib.request
from openpyxl import load_workbook

ROOT=Path(__file__).resolve().parents[1]
BASE='http://127.0.0.1:18890'
fixture=json.loads((ROOT/'fixtures/address.json').read_text())['url']
report_id='run_run-6d5493ee196e'
records=[]
def request(path,method='GET',origin=BASE):
    started=time.time_ns()
    req=urllib.request.Request(origin+path,method=method,data=b'{}' if method=='POST' else None,headers={'Content-Type':'application/json'})
    try:
        response=urllib.request.urlopen(req,timeout=30)
    except urllib.error.HTTPError as exc:
        response=exc
    raw=response.read()
    try:body=json.loads(raw)
    except ValueError:body={'non_json_sha256':hashlib.sha256(raw).hexdigest(),'size':len(raw)}
    item={'path':path,'method':method,'started_ns':started,'finished_ns':time.time_ns(),'http_status':response.status,'body':body}
    records.append(item)
    return body

before_counts=request('/counts',origin=fixture)
before_runs=request('/api/runs?cycle=all&limit=1000')
before=request('/api/task-reports/'+report_id)
if before.get('status')!='ready':
    raise RuntimeError('expected ready report: '+json.dumps(before))
original_dir=ROOT/'evidence/report-originals'
original_dir.mkdir(exist_ok=True)
files={}
for key in ['excel','markdown','bugs']:
    path=Path(before[key])
    if not path.is_relative_to(ROOT):raise RuntimeError('report path outside owned root')
    raw=path.read_bytes()
    copy=original_dir/(key+path.suffix)
    shutil.copy2(path,copy)
    files[key]={'path':str(path),'copy':str(copy),'sha256':hashlib.sha256(raw).hexdigest(),'declared_sha256':before.get('sha256' if key=='excel' else key+'_sha256'),'size':len(raw)}
    request('/api/task-reports/'+report_id+'/'+key)
book=load_workbook(before['excel'],data_only=True)
workbook={'sheets':book.sheetnames,'main_max_columns':book.worksheets[0].max_column,'main_rows':book.worksheets[0].max_row,'cells':[[str(c) if c is not None else None for c in row] for row in book.worksheets[0].iter_rows(values_only=True)]}
book.close()
missing=Path(before['markdown'])
missing.unlink()
removed_ns=time.time_ns()
failed_first=request('/api/task-reports/'+report_id)
time.sleep(1.2)
failed_second=request('/api/task-reports/'+report_id)
still_missing_before_retry=not missing.exists()
retry=request('/api/task-reports/'+report_id+'/retry',method='POST')
after=retry
for _ in range(30):
    if after.get('status') not in ['pending','generating']:break
    time.sleep(.1)
    after=request('/api/task-reports/'+report_id)
after_counts=request('/counts',origin=fixture)
after_runs=request('/api/runs?cycle=all&limit=1000')
result={'report_id':report_id,'removed_ns':removed_ns,'files':files,'workbook':workbook,'records':records,'checks':{'hashes_match':all(x['sha256']==x['declared_sha256'] for x in files.values()),'three_downloads_succeeded':all(x['http_status']==200 for x in records if x['path'].split('/')[-1] in ['excel','markdown','bugs']),'missing_read_failed':failed_first.get('status')=='failed' and failed_second.get('status')=='failed','no_automatic_repair':still_missing_before_retry,'manual_retry_ready':after.get('status')=='ready','frozen_source_hash_unchanged':before.get('source_hash')==after.get('source_hash'),'fixture_queries_unchanged':before_counts.get('queries')==after_counts.get('queries'),'run_ids_unchanged':set(x['id'] for x in before_runs['items'])==set(x['id'] for x in after_runs['items'])},'before_counts':before_counts,'after_counts':after_counts}
(ROOT/'evidence/report-integrity-retry.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({'report_id':report_id,'checks':result['checks'],'before_counts':before_counts,'after_counts':after_counts,'report_statuses':[x['body'].get('status') for x in records if x['path'].endswith(report_id)]},ensure_ascii=False))
