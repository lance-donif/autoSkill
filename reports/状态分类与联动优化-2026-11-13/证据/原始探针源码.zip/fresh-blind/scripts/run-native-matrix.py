from pathlib import Path
import json
import time
from cli import call

ROOT = Path(__file__).resolve().parents[1]
records = []
for name in ['fast', 'wrong', 'retry', 'probe']:
    asset_result = call('asset', 'import', 'fresh-arithmetic', '--source', ROOT / 'inputs/assets' / name, '--engine', 'ai-eval', '--name', 'fresh-' + name, label='import-' + name)
    asset = asset_result['result']['id']
    run_result = call('native', 'run', 'fresh-arithmetic', asset, label='run-' + name)
    run_id = run_result['result']['id']
    for poll in range(60):
        result = call('native', 'status', run_id, '--all', label='status-' + name)
        if result['result'].get('status') not in ['Queued', 'Running', 'Waiting', 'Pending']:
            break
        time.sleep(.1)
    record = {'scenario':name,'asset_id':asset,'run_id':run_id,'state':result['result'].get('state'),'status':result['result'].get('status'),'report':result['result'].get('test_report'),'final_evidence':result['evidence'],'asset_evidence':asset_result['evidence'],'start_evidence':run_result['evidence']}
    records.append(record)
    print(json.dumps({key:record[key] for key in ['scenario','asset_id','run_id','state','final_evidence']},ensure_ascii=False), flush=True)
(ROOT / 'evidence/native-matrix.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
