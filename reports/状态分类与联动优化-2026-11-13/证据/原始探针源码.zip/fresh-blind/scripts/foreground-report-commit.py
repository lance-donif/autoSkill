from pathlib import Path
from playwright.sync_api import sync_playwright
import json
import os
import shutil
import time
import traceback
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
BASE='http://127.0.0.1:18890'
REPORT='run_run-6d5493ee196e'
OUT={'started_ns':time.time_ns(),'loadavg':os.getloadavg(),'method':'Known local report-file unlink completion plus first public failed-report response; actual Chromium double-rAF paint. Both boundaries are preserved.'}
def request(path,method='GET'):
    started=time.time_ns()
    req=urllib.request.Request(BASE+path,method=method,data=b'{}' if method=='POST' else None,headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=20) as r:body=json.load(r)
    return {'started_ns':started,'finished_ns':time.time_ns(),'body':body}
try:
    report=request('/api/task-reports/'+REPORT)['body']
    if report.get('status')!='ready':raise RuntimeError('Expected original ready report')
    path=Path(report['markdown'])
    if not path.is_relative_to(ROOT):raise RuntimeError('File outside owned root')
    backup=ROOT/'evidence/report-originals/markdown-before-paint.md'
    shutil.copy2(path,backup)
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1440,'height':900})
        page.goto(BASE+'/#/runs/run-6d5493ee196e',wait_until='domcontentloaded')
        page.get_by_text('报告：已就绪',exact=True).first.wait_for(timeout=15000)
        page.bring_to_front()
        OUT['visible']=page.evaluate('({visibility:document.visibilityState,focus:document.hasFocus()})')
        page.evaluate('''()=>{window.__blindReport=[];let previous='ready';new MutationObserver(()=>{const body=document.body.innerText;const status=body.includes('报告：失败')?'failed':body.includes('报告：已就绪')?'ready':'other';if(status===previous)return;previous=status;const event={kind:'dom',at:Date.now(),status};window.__blindReport.push(event);requestAnimationFrame(()=>requestAnimationFrame(()=>window.__blindReport.push({kind:'paint',at:Date.now(),status,domAt:event.at})))}).observe(document.body,{childList:true,subtree:true,characterData:true})}''')
        OUT['before_body']=page.locator('body').inner_text()
        OUT['unlink_started_ns']=time.time_ns();path.unlink();OUT['unlink_finished_ns']=time.time_ns()
        OUT['first_failed_public_response']=request('/api/task-reports/'+REPORT)
        try:page.wait_for_function("window.__blindReport.some(x=>x.kind==='paint'&&x.status==='failed')",timeout=5000)
        except Exception as exc:OUT['failed_paint_timeout']=str(exc)
        OUT['after_failure_body']=page.locator('body').inner_text()
        page.screenshot(path=str(ROOT/'evidence/foreground-report-failed.png'),full_page=True)
        events=page.evaluate('window.__blindReport')
        failure=next((x for x in events if x['kind']=='paint' and x['status']=='failed'),None)
        OUT['failed_paint']=failure
        if failure:
            OUT['unlink_to_failed_paint_ms']=round(failure['at']-OUT['unlink_finished_ns']/1e6,3)
            OUT['public_failed_ack_to_paint_ms']=round(failure['at']-OUT['first_failed_public_response']['finished_ns']/1e6,3)
            OUT['within_one_second_from_unlink']=OUT['unlink_to_failed_paint_ms']<=1000
        else:OUT['within_one_second_from_unlink']=False
        OUT['manual_retry']=request('/api/task-reports/'+REPORT+'/retry','POST')
        after=OUT['manual_retry']
        for _ in range(20):
            if after['body'].get('status') not in ['pending','generating']:break
            page.wait_for_timeout(100);after=request('/api/task-reports/'+REPORT)
        OUT['ready_public_response']=after
        try:page.wait_for_function("window.__blindReport.some(x=>x.kind==='paint'&&x.status==='ready')",timeout=5000)
        except Exception as exc:OUT['ready_paint_timeout']=str(exc)
        OUT['events']=page.evaluate('window.__blindReport')
        OUT['after_repair_body']=page.locator('body').inner_text()
        page.screenshot(path=str(ROOT/'evidence/foreground-report-ready.png'),full_page=True)
        browser.close()
except Exception:OUT['error']=traceback.format_exc()
finally:
    OUT['finished_ns']=time.time_ns();OUT['final_loadavg']=os.getloadavg()
    (ROOT/'evidence/foreground-report-commit.json').write_text(json.dumps(OUT,ensure_ascii=False,indent=2))
    print(json.dumps({k:v for k,v in OUT.items() if k in ['unlink_to_failed_paint_ms','public_failed_ack_to_paint_ms','within_one_second_from_unlink','failed_paint_timeout','ready_paint_timeout','error']},ensure_ascii=False))
