from pathlib import Path
from playwright.sync_api import sync_playwright
import json
import os
import subprocess
import sys
import time
import traceback
import urllib.parse

ROOT=Path(__file__).resolve().parents[1]
OUT={'started_ns':time.time_ns(),'loadavg':os.getloadavg(),'requests':[],'stages':[]}
def snapshot(page):
    return page.evaluate('''()=>({url:location.href,filters:[...document.querySelectorAll('select')].map(x=>x.value),focused:[...document.querySelectorAll('select')].indexOf(document.activeElement),scrollY:window.scrollY,rowCount:document.querySelectorAll('tbody tr').length,body:document.body.innerText})''')
def matches(response,cycle,phase):
    parsed=urllib.parse.urlparse(response.url)
    query=urllib.parse.parse_qs(parsed.query)
    return parsed.path=='/api/runs' and query.get('cycle')==[cycle] and query.get('phase',[''])==[phase] and 'offset' in query
try:
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1100,'height':430})
        page.on('request',lambda r:OUT['requests'].append({'url':r.url,'time_ns':time.time_ns()}) if '/api/runs?' in r.url else None)
        page.goto('http://127.0.0.1:18890/#/runs',wait_until='domcontentloaded')
        page.locator('tbody tr').first.wait_for(timeout=15000)
        page.wait_for_timeout(700)
        OUT['stages'].append({'name':'initial_stable','view':snapshot(page)})
        with page.expect_response(lambda r:matches(r,'all',''),timeout=10000) as response:
            page.locator('select').nth(0).select_option('all')
        OUT['cycle_response']={'url':response.value.url,'status':response.value.status}
        page.wait_for_timeout(800)
        OUT['stages'].append({'name':'cycle_all_after_response_and_wait','view':snapshot(page)})
        with page.expect_response(lambda r:matches(r,'all','settled'),timeout=10000) as response:
            page.locator('select').nth(1).select_option('settled')
        OUT['phase_response']={'url':response.value.url,'status':response.value.status}
        page.wait_for_timeout(800)
        page.locator('select').nth(1).focus()
        page.evaluate('window.scrollTo(0,20)')
        before=snapshot(page)
        OUT['stages'].append({'name':'before_live_update','view':before})
        proc=subprocess.Popen([sys.executable,str(ROOT/'scripts/cli.py'),'native','run','fresh-arithmetic','asset-101b7a6ea95d'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            page.wait_for_function('(count)=>document.querySelectorAll("tbody tr").length>count',arg=before['rowCount'],timeout=15000)
        except Exception as exc:OUT['row_update_timeout']=str(exc)
        page.wait_for_timeout(300)
        after=snapshot(page)
        OUT['stages'].append({'name':'after_live_update','view':after})
        stdout,stderr=proc.communicate(timeout=15)
        OUT['cli']={'exit_code':proc.returncode,'stdout':stdout,'stderr':stderr}
        OUT['checks']={'cycle_and_phase_requested_correctly':before['filters'][:2]==['all','settled'],'filters_preserved':before['filters']==after['filters'],'focus_preserved':before['focused']==after['focused'],'scroll_preserved':before['scrollY']==after['scrollY'],'new_settled_row_visible':after['rowCount']>before['rowCount']}
        page.screenshot(path=str(ROOT/'evidence/filter-preservation-confirmation.png'),full_page=True)
        browser.close()
except Exception:OUT['error']=traceback.format_exc()
finally:
    OUT['finished_ns']=time.time_ns()
    (ROOT/'evidence/filter-preservation-confirmation.json').write_text(json.dumps(OUT,ensure_ascii=False,indent=2))
    print(json.dumps({'checks':OUT.get('checks'),'stages':[{'name':x['name'],'filters':x['view']['filters'],'focused':x['view']['focused'],'scrollY':x['view']['scrollY'],'rowCount':x['view']['rowCount']} for x in OUT['stages']],'error':OUT.get('error')},ensure_ascii=False))
