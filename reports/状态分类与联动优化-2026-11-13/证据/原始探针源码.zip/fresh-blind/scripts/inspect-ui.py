from pathlib import Path
from playwright.sync_api import sync_playwright
import json
import time
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':1000})
    requests=[]
    page.on('request',lambda request:requests.append({'url':request.url,'method':request.method,'time_ns':time.time_ns()}))
    page.goto('http://127.0.0.1:18890',wait_until='networkidle')
    page.screenshot(path=str(ROOT/'evidence/ui-initial.png'),full_page=True)
    result={'url':page.url,'time_ns':time.time_ns(),'body':page.locator('body').inner_text(),'links':page.locator('a').evaluate_all('(xs)=>xs.map(x=>({text:x.innerText,href:x.getAttribute("href")}))'),'selects':page.locator('select').evaluate_all('(xs)=>xs.map(x=>({id:x.id,value:x.value,options:[...x.options].map(o=>({value:o.value,text:o.text}))}))'),'inputs':page.locator('input').evaluate_all('(xs)=>xs.map(x=>({id:x.id,type:x.type,placeholder:x.placeholder}))'),'requests':requests}
    (ROOT/'evidence/ui-initial.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False))
    browser.close()
