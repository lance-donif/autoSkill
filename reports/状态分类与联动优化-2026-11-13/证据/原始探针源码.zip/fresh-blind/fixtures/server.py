from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import argparse
import json
import threading
import time

ROOT = Path(__file__).resolve().parents[1]
LOCK = threading.Lock()
STATE = {"retry_answer": 41, "hold": False}

PAGE = '''<!doctype html><html lang="zh"><meta charset="utf-8"><title>Fresh blind arithmetic desk</title>
<style>body{font:18px sans-serif;max-width:800px;margin:40px auto}label,input,button{margin:12px}#answer{padding:20px;border:1px solid #777} .spacer{height:1200px}</style>
<h1>Arithmetic desk</h1><p>Contract: six multiplied by seven equals 42.</p>
<label for="question">Question</label><input id="question" data-testid="question" value="six times seven"><button id="ask" data-testid="ask">Ask</button>
<p id="status" data-testid="status">Ready</p><pre id="answer" data-testid="answer">No answer yet</pre>
<div class="spacer"></div><p>End of arithmetic desk</p>
<script>document.querySelector('#ask').onclick=async()=>{document.querySelector('#status').textContent='Working';try{const r=await fetch('/query',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({question:document.querySelector('#question').value})});const j=await r.json();document.querySelector('#answer').textContent=String(j.answer);document.querySelector('#status').textContent='Completed'}catch(e){document.querySelector('#status').textContent='Error: '+e.message}};</script></html>'''

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def log_entry(self, entry):
        with LOCK:
            with (ROOT / "evidence/fixture-requests.jsonl").open("a", encoding="utf-8") as out:
                out.write(json.dumps(entry, ensure_ascii=False) + "\n")

    def send(self, status, body, content_type="application/json"):
        raw = body.encode() if isinstance(body, str) else json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        if self.path == "/health":
            self.send(200, {"status": "ready", "time_ns": time.time_ns()})
        elif self.path == "/counts":
            entries = [json.loads(x) for x in (ROOT / "evidence/fixture-requests.jsonl").read_text().splitlines()] if (ROOT / "evidence/fixture-requests.jsonl").exists() else []
            self.send(200, {"queries": len([x for x in entries if x["path"] == "/query"]), "entries": len(entries), "state": STATE.copy()})
        elif self.path == "/blocked":
            self.send(503, {"error": "independently injected fixture outage"})
        elif self.path in ("/", "/index.html"):
            self.send(200, PAGE, "text/html; charset=utf-8")
        else:
            self.send(404, {"error": "not found"})

    def do_POST(self):
        started = time.time_ns()
        raw = self.rfile.read(int(self.headers.get("Content-Length", "0")))
        try:
            body = json.loads(raw or b"{}")
        except ValueError:
            self.send(400, {"error": "invalid JSON"})
            return
        if self.path == "/control":
            for key in ("retry_answer", "hold"):
                if key in body:
                    STATE[key] = body[key]
            self.log_entry({"path": self.path, "request": body, "started_ns": started, "finished_ns": time.time_ns()})
            self.send(200, STATE.copy())
            return
        if self.path != "/query":
            self.send(404, {"error": "not found"})
            return
        question = str(body.get("question", ""))
        if question.startswith("slow"):
            time.sleep(0.2)
        deadline = time.monotonic() + 20
        while STATE["hold"] and time.monotonic() < deadline:
            time.sleep(0.01)
        answer = 41 if question.startswith("wrong") else STATE["retry_answer"] if question.startswith("retry") else 42
        result = {"answer": answer, "question": question, "conversation_id": body.get("conversation_id", "fresh-local-session")}
        self.log_entry({"path": self.path, "request": body, "response": result, "started_ns": started, "finished_ns": time.time_ns()})
        self.send(200, result)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=0)
    args = parser.parse_args()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    (ROOT / "fixtures/address.json").write_text(json.dumps({"url": f"http://127.0.0.1:{server.server_port}", "port": server.server_port}), encoding="utf-8")
    print(f"fixture listening on {server.server_port}", flush=True)
    server.serve_forever()
